#!/bin/sh
#!/bin/bash
rm  aesccm  
rm  aesccm192
rm  aesccm256
rm  aesccm128
rm  aesgcm256
rm  aesgcm128
rm  aesgcm192
rm *.o
