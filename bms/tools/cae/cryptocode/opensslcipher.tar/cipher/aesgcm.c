/*
 * Copyright 2012-2021 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the Apache License 2.0 (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

/*
 * Simple AES GCM authenticated encryption with additional data (AEAD)
 * demonstration program.
 */

#include <stdio.h>
#include <string.h>
#include <openssl/err.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/core_names.h>

/* AES-GCM test data obtained from NIST public test vectors */
uint8_t ASCII_To_Hex(uint8_t number)
{
        if (number >= '0' && number <= '9')
                return (number - 0x30);
 
        else if (number >= 'a' && number <= 'f')
                return ((number - 'a') + 10);
 
        else  if (number >= 'A' && number <= 'F')
                return ((number - 'A') + 10);
        return (0);
}

//command 256 ./aesgcm aesgcmdata.txt eebc1f57487f51921c0465665f8ae6d1658bb26de6f8a069a3520293a572078f 4d23c3cec334b49bdb370c437fec78de 99aa3e68ed8173a0eed06684
//command 192 ./aesgcm aesgcmdata.txt eebc1f57487f51921c0465665f8ae6d1658bb26de6f8a062 4d23c3cec334b49bdb370c437fec78d2 99aa3e68ed8173a0eed06682
//command 128 ./aesgcm aesgcmdata.txt eebc1f57487f51921c0465665f8ae6d1 4d23c3cec334b49bdb370c437fec78d1 99aa3e68ed8173a0eed06681


//gcmkey3   :eebc1f57487f51921c0465665f8ae6d1658bb26de6f8a069a3520293a572078f   32BYTE
//iv3     :  99aa3e68ed8173a0eed06684           12BYTE
//message3:  f56e87055bc32d0eeb31b2eacc2bf2a5   16BYTE
//addtag3:   4d23c3cec334b49bdb370c437fec78de   16BYTE 

//gcmkey2   :eebc1f57487f51921c0465665f8ae6d1658bb26de6f8a062     24BYTE
//iv2     :  99aa3e68ed8173a0eed06682
//message2:  f56e87055bc32d0eeb31b2eacc2bf2a5  16BYTE
//addtag2:   4d23c3cec334b49bdb370c437fec78d2  16BYTE

//gcmkey1   :eebc1f57487f51921c0465665f8ae6d1                     16BYTE
//iv1     :  99aa3e68ed8173a0eed06681
//message1:  f56e87055bc32d0eeb31b2eacc2bf2a5  16BYTE
//addtag1:   4d23c3cec334b49bdb370c437fec78d1  16BYTE


/* AES key */
static const unsigned char gcm_key[] = {
    0xee, 0xbc, 0x1f, 0x57, 0x48, 0x7f, 0x51, 0x92, 0x1c, 0x04, 0x65, 0x66,
    0x5f, 0x8a, 0xe6, 0xd1, 0x65, 0x8b, 0xb2, 0x6d, 0xe6, 0xf8, 0xa0, 0x69,
    0xa3, 0x52, 0x02, 0x93, 0xa5, 0x72, 0x07, 0x8f
};

/* Unique initialisation vector */
static const unsigned char gcm_iv[] = {
    0x99, 0xaa, 0x3e, 0x68, 0xed, 0x81, 0x73, 0xa0, 0xee, 0xd0, 0x66, 0x84
};

/* Example plaintext to encrypt */
static const unsigned char gcm_pt[] = {
    0xf5, 0x6e, 0x87, 0x05, 0x5b, 0xc3, 0x2d, 0x0e, 0xeb, 0x31, 0xb2, 0xea,
    0xcc, 0x2b, 0xf2, 0xa5
};

/*
 * Example of Additional Authenticated Data (AAD), i.e. unencrypted data
 * which can be authenticated using the generated Tag value.
 */
static const unsigned char gcm_aad[] = {
    0x4d, 0x23, 0xc3, 0xce, 0xc3, 0x34, 0xb4, 0x9b, 0xdb, 0x37, 0x0c, 0x43,
    0x7f, 0xec, 0x78, 0xde
};

/* Expected ciphertext value */
static const unsigned char gcm_ct[] = {
    0xf7, 0x26, 0x44, 0x13, 0xa8, 0x4c, 0x0e, 0x7c, 0xd5, 0x36, 0x86, 0x7e,
    0xb9, 0xf2, 0x17, 0x36
};

/* Expected AEAD Tag value */
static const unsigned char gcm_tag[] = {
    0x67, 0xba, 0x05, 0x10, 0x26, 0x2a, 0xe4, 0x87, 0xd7, 0x37, 0xee, 0x62,
    0x98, 0xf7, 0x7e, 0x0c
};

/*
 * A library context and property query can be used to select & filter
 * algorithm implementations. If they are NULL then the default library
 * context and properties are used.
 */
OSSL_LIB_CTX *libctx = NULL;
const char *propq = NULL;

int aes_gcm_encrypt(uint8_t gcm_pt[] ,uint8_t gcm_key[],uint8_t gcm_adata[],uint8_t gcm_iv[],uint8_t gcm_pt_len,uint8_t gcm_key_len,uint8_t gcm_adata_len,uint8_t gcm_iv_len)
{
    int ret = 0;
    EVP_CIPHER_CTX *ctx;
    EVP_CIPHER *cipher = NULL;
    int outlen, tmplen;
    size_t gcm_ivlen = gcm_iv_len;
    unsigned char outbuf[1024];
    unsigned char outtag[16];
    OSSL_PARAM params[2] = {
        OSSL_PARAM_END, OSSL_PARAM_END
    };

    // printf("AES GCM Encrypt:\n");
    // printf("Plaintext:\n");
    // BIO_dump_fp(stdout, gcm_pt, gcm_pt_len);

    /* Create a context for the encrypt operation */
    if ((ctx = EVP_CIPHER_CTX_new()) == NULL)
        goto err;

    /* Fetch the cipher implementation */
    if ((cipher = EVP_CIPHER_fetch(libctx, "AES-256-GCM", propq)) == NULL)
        goto err;

    /* Set IV length if default 96 bits is not appropriate */
    params[0] = OSSL_PARAM_construct_size_t(OSSL_CIPHER_PARAM_AEAD_IVLEN,
                                            &gcm_ivlen);

    /*
     * Initialise an encrypt operation with the cipher/mode, key, IV and
     * IV length parameter.
     * For demonstration purposes the IV is being set here. In a compliant
     * application the IV would be generated internally so the iv passed in
     * would be NULL. 
     */
    if (!EVP_EncryptInit_ex2(ctx, cipher, gcm_key, gcm_iv, params))
        goto err;

    /* Zero or more calls to specify any AAD */
    if (!EVP_EncryptUpdate(ctx, NULL, &outlen, gcm_aad, gcm_adata_len))
        goto err;

    /* Encrypt plaintext */
    if (!EVP_EncryptUpdate(ctx, outbuf, &outlen, gcm_pt, gcm_pt_len))
        goto err;

    // /* Output encrypted block */
    // printf("Ciphertext:\n");
    // BIO_dump_fp(stdout, outbuf, outlen);
    for (int i = 0;i < outlen ;i++)
    {
        printf("%02x", outbuf[i]);
    }
    printf("\n");

    /* Finalise: note get no output for GCM */
    if (!EVP_EncryptFinal_ex(ctx, outbuf, &tmplen))
        goto err;

    /* Get tag */
    params[0] = OSSL_PARAM_construct_octet_string(OSSL_CIPHER_PARAM_AEAD_TAG,
                                                  outtag, 16);

    if (!EVP_CIPHER_CTX_get_params(ctx, params))
        goto err;

    // /* Output tag */
    // printf("Tag:\n");
    // BIO_dump_fp(stdout, outtag, 16);

    ret = 1;
err:
    if (!ret)
        ERR_print_errors_fp(stderr);

    EVP_CIPHER_free(cipher);
    EVP_CIPHER_CTX_free(ctx);

    return ret;
}

// int aes_gcm_decrypt(void)
// {
//     int ret = 0;
//     EVP_CIPHER_CTX *ctx;
//     EVP_CIPHER *cipher = NULL;
//     int outlen, rv;
//     size_t gcm_ivlen = sizeof(gcm_iv);
//     unsigned char outbuf[1024];
//     OSSL_PARAM params[2] = {
//         OSSL_PARAM_END, OSSL_PARAM_END
//     };

//     printf("AES GCM Decrypt:\n");
//     printf("Ciphertext:\n");
//     BIO_dump_fp(stdout, gcm_ct, sizeof(gcm_ct));

//     if ((ctx = EVP_CIPHER_CTX_new()) == NULL)
//         goto err;

//     /* Fetch the cipher implementation */
//     if ((cipher = EVP_CIPHER_fetch(libctx, "AES-256-GCM", propq)) == NULL)
//         goto err;

//     /* Set IV length if default 96 bits is not appropriate */
//     params[0] = OSSL_PARAM_construct_size_t(OSSL_CIPHER_PARAM_AEAD_IVLEN,
//                                             &gcm_iv_len);

//     /*
//      * Initialise an encrypt operation with the cipher/mode, key, IV and
//      * IV length parameter.
//      */
//     if (!EVP_DecryptInit_ex2(ctx, cipher, gcm_key, gcm_iv, params))
//         goto err;

//     /* Zero or more calls to specify any AAD */
//     if (!EVP_DecryptUpdate(ctx, NULL, &outlen, gcm_aad, sizeof(gcm_aad)))
//         goto err;

//     /* Decrypt plaintext */
//     if (!EVP_DecryptUpdate(ctx, outbuf, &outlen, gcm_ct, sizeof(gcm_ct)))
//         goto err;

//     /* Output decrypted block */
//     printf("Plaintext:\n");
//     BIO_dump_fp(stdout, outbuf, outlen);

//     /* Set expected tag value. */
//     params[0] = OSSL_PARAM_construct_octet_string(OSSL_CIPHER_PARAM_AEAD_TAG,
//                                                   (void*)gcm_tag, sizeof(gcm_tag));

//     if (!EVP_CIPHER_CTX_set_params(ctx, params))
//         goto err;

//     /* Finalise: note get no output for GCM */
//     rv = EVP_DecryptFinal_ex(ctx, outbuf, &outlen);
//     /*
//      * Print out return value. If this is not successful authentication
//      * failed and plaintext is not trustworthy.
//      */
//     printf("Tag Verify %s\n", rv > 0 ? "Successful!" : "Failed!");

//     ret = 1;
// err:
//     if (!ret)
//         ERR_print_errors_fp(stderr);

//     EVP_CIPHER_free(cipher);
//     EVP_CIPHER_CTX_free(ctx);

//     return ret;
// }

int main(int argc, char **argv)
{
    uint8_t keybuff[255]={0};
    uint8_t ivbuff[255]={0};
    uint8_t tagbuff[255]={0};
    uint8_t buff[255]={0};

    uint8_t message1[16]={0};
    uint8_t message2[16]={0};
    uint8_t message3[16]={0};
    uint8_t iv1[12]={0};
    uint8_t iv2[12]={0};
    uint8_t iv3[12]={0};
    uint8_t addtag1[16]={0};
    uint8_t addtag2[16]={0};
    uint8_t addtag3[16]={0};
    uint8_t key1[16]={0}; 
    uint8_t key2[24]={0}; 
    uint8_t key3[32]={0};

    uint8_t i;      
    uint8_t ch1;
    uint8_t ch2;
    uint8_t hash[16];

    FILE *fp = NULL;
    fp = fopen(argv[1], "r");
    fgets(buff, 255, (FILE*)fp);
    fseek(fp,0,SEEK_END);       //定位到文件末
    int nFileLen = ftell(fp);   //文件长度
    int msglen =(nFileLen-1)/2;

    int keylen=strlen(argv[2])/2;
    int addtaglen=strlen(argv[3])/2;
    int ivlen=strlen(argv[4])/2;
    
    char *p =buff;
    for (i = 0;i < msglen ;i++)
    { 
        ch1 = *p++;
        ch2 = *p++;
        ch1 = ASCII_To_Hex(ch1);
        ch2 = ASCII_To_Hex(ch2);
        uint8_t temp2= (ch1 << 0x04) | ch2;
        buff[i]= temp2;
    }

    for (i = 0;i < keylen ;i++)
    { 
        ch1 = *argv[2]++;
        ch2 = *argv[2]++;
        ch1 = ASCII_To_Hex(ch1);
        ch2 = ASCII_To_Hex(ch2);
        uint8_t temp2= (ch1 << 0x04) | ch2;
        keybuff[i]= temp2;
    }

    for (i = 0;i < addtaglen ;i++)
    { 
        ch1 = *argv[3]++;
        ch2 = *argv[3]++;
        ch1 = ASCII_To_Hex(ch1);
        ch2 = ASCII_To_Hex(ch2);
        uint8_t temp2= (ch1 << 0x04) | ch2;
        tagbuff[i]= temp2;
    }

    for (i = 0;i < ivlen ;i++)
    { 
        ch1 = *argv[4]++;
        ch2 = *argv[4]++;
        ch1 = ASCII_To_Hex(ch1);
        ch2 = ASCII_To_Hex(ch2);
        uint8_t temp2= (ch1 << 0x04) | ch2;
        ivbuff[i]= temp2;
    }

        memcpy(message3,buff,msglen);
        memcpy(key3,keybuff,keylen);
        memcpy(addtag3,tagbuff,addtaglen);
        memcpy(iv3,ivbuff,ivlen);

    // printf("INPUT MESSAGE:");
    // for (i = 0;i < msglen ;i++)
    // {
    //     printf("%02x", message2[i]);
    // }
    // printf("\n");

    // printf("INPUT KEY:");
    // for (i = 0;i < keylen ;i++)
    // {
    //     printf("%02x", key2[i]);
    // }
    // printf("\n");

    // printf("INPUT AAD TAG:");
    // for (i = 0;i < addtaglen ;i++)
    // {
    //     printf("%02x", addtag2[i]);
    // }
    // printf("\n");

    // printf("INPUT IV:");
    // for (i = 0;i < ivlen ;i++)
    // {
    //     printf("%02x", iv3[i]);
    // }
    int msg3len= sizeof(message3)/sizeof(message3[0]);
    int key3len= sizeof(key3)/sizeof(key3[0]);
    int addtag3len= sizeof(addtag3)/sizeof(addtag3[0]);
    int iv3len= sizeof(iv3)/sizeof(iv3[0]);

    int msg2len= sizeof(message2)/sizeof(message2[0]);
    int key2len= sizeof(key2)/sizeof(key2[0]);
    int addtag2len= sizeof(addtag2)/sizeof(addtag2[0]);
    int iv2len= sizeof(iv2)/sizeof(iv2[0]);

    int msg1len= sizeof(message1)/sizeof(message1[0]);
    int key1len= sizeof(key1)/sizeof(key1[0]);
    int addtag1len= sizeof(addtag1)/sizeof(addtag1[0]);
    int iv1len= sizeof(iv1)/sizeof(iv1[0]);

    // printf("\n");
    // printf("256 mlen:%d,keylen:%d,taglen:%d,ivlen:%d\n",msg3len,key3len,addtag3len,iv3len);
    // printf("192 mlen:%d,keylen:%d,taglen:%d,ivlen:%d\n",msg2len,key2len,addtag2len,iv2len);
    // printf("128 mlen:%d,keylen:%d,taglen:%d,ivlen:%d\n",msg1len,key1len,addtag1len,iv1len);
    // printf("\n");
    if(keylen==32){
        memcpy(message3,buff,msglen);
        memcpy(key3,keybuff,keylen);
        memcpy(addtag3,tagbuff,addtaglen);
        memcpy(iv3,ivbuff,iv3len);
        int msg3len= sizeof(message3)/sizeof(message3[0]);
        int key3len= sizeof(key3)/sizeof(key3[0]);
        int addtag3len= sizeof(addtag3)/sizeof(addtag3[0]);
        int nonce3len= sizeof(iv3)/sizeof(iv3[0]);
        if (!aes_gcm_encrypt(message3 ,key3, addtag3, iv3,msg3len,key3len,addtag3len,iv3len))
        return 1;
    }else if(keylen==24){
        memcpy(message2,buff,msglen);
        memcpy(key2,keybuff,keylen);
        memcpy(addtag2,tagbuff,addtaglen);
        memcpy(iv2,ivbuff,iv2len);
        int msg2len= sizeof(message2)/sizeof(message2[0]);
        int key2len= sizeof(key2)/sizeof(key2[0]);
        int addtag2len= sizeof(addtag2)/sizeof(addtag:::2[0]);
        int iv2len= sizeof(iv2)/sizeof(iv2[0]);
        if (!aes_gcm_encrypt(message2 ,key2, addtag2, iv2,msg2len,key2len,addtag2len,iv2len))
        return 1;
    }else if(keylen==16){
        memcpy(message1,buff,msglen);
        memcpy(key1,keybuff,keylen);
        memcpy(addtag1,tagbuff,addtaglen);
        memcpy(iv1,ivbuff,ivlen);
        int msg1len= sizeof(message1)/sizeof(message1[0]);
        int key1len= sizeof(key1)/sizeof(key1[0]);
        int addtag1len= sizeof(addtag1)/sizeof(addtag1[0]);
        int iv1len= sizeof(iv1)/sizeof(iv1[0]);
        if (!aes_gcm_encrypt(message1 ,key1, addtag1, iv1,msg1len,key1len,addtag1len,iv1len))
        return 1;
    }else {
        return -1;
    }
    




    // if (!aes_gcm_encrypt(message3,key3,addtag3,iv3,msg3len,key3len,addtag3len,iv3len))
    //     return 1;

    // if (!aes_gcm_decrypt())
    //     return 1;

    // return 0;
}