/*
 * Copyright 2013-2021 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the Apache License 2.0 (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

/*
 * Simple AES CCM authenticated encryption with additional data (AEAD)
 * demonstration program.
 */

#include <stdio.h>
#include <string.h>
#include <openssl/err.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/core_names.h>

/* AES-CCM test data obtained from NIST public test vectors */
uint8_t ASCII_To_Hex(uint8_t number)
{
	if (number >= '0' && number <= '9')
		return (number - 0x30);
 
	else if (number >= 'a' && number <= 'f')
		return ((number - 'a') + 10);
 
	else  if (number >= 'A' && number <= 'F')
		return ((number - 'A') + 10);
	return (0);
}

//command192 





//command128 ./aesccm aesccmdata128.txt ceb009aea4454451feadf0e6b36f4555 6e80dd7f1badf3a1c9ab25c75f10bde78c23fa0eb8f9aaa53adefbf4cbf78fe2 764043c49460b2
//command192 ./aesccm aesccmdata192.txt  ceb009aea4454451feadf0e6b36f455555dd04723baa448e80102030405060708 6e80dd7f1badf3a1c9ab25c75f10bde78c23fa0eb8f9aaa53adefbf4cbf78fe3 764043c49460b3

//aeskey-192:   ceb009aea4454451feadf0e6b36f455555dd04723baa448e8                                     24byte
//aeskey-128:   ceb009aea4454451feadf0e6b36f4555                                                      16byte
//aeskey-256:   ceb009aea4454451feadf0e6b36f455555dd04723baa448e80102030405060708                     32byte
//nonce1:    764043c49460b1    7byte
//nonce2:    764043c49460b7    7byte
//nonce3:    764043c49460b3    7byte
//taginput1 :6e80dd7f1badf3a1c9ab25c75f10bde78c23fa0eb8f9aaa53adefbf4cbf78fe1      32byte
//taginput2: 6e80dd7f1badf3a1c9ab25c75f10bde78c23fa0eb8f9aaa53adefbf4cbf78fe4      32byte
//taginput3: 6e80dd7f1badf3a1c9ab25c75f10bde78c23fa0eb8f9aaa53adefbf4cbf78fe3      32byte
             
//plaintext1: c8d275f919e17d7fe69c2a1f58939dfe4d403791b5df1310    24byte
//plaintext2: c8d275f919e17d7fe69c2a1f58939dfe                    16byte
//plaintext3: c8d275f919e17d7fe69c2a1f58939dfe4d403791b5df13101020304050607080    32byte
// static const unsigned char ccm_key[] = {
//     0xce, 0xb0, 0x09, 0xae, 0xa4, 0x45, 0x44, 0x51, 0xfe, 0xad, 0xf0, 0xe6,
//     0xb3, 0x6f, 0x45, 0x55, 0x5d, 0xd0, 0x47, 0x23, 0xba, 0xa4, 0x48, 0xe8
// };

/* Unique nonce to be used for this message */
// static const unsigned char ccm_nonce[] = {
//     0x76, 0x40, 0x43, 0xc4, 0x94, 0x60, 0xb7
// };

/*
 * Example of Additional Authenticated Data (AAD), i.e. unencrypted data
 * which can be authenticated using the generated Tag value.
 */

// static const unsigned char ccm_adata[] = {
//     0x6e, 0x80, 0xdd, 0x7f, 0x1b, 0xad, 0xf3, 0xa1, 0xc9, 0xab, 0x25, 0xc7,
//     0x5f, 0x10, 0xbd, 0xe7, 0x8c, 0x23, 0xfa, 0x0e, 0xb8, 0xf9, 0xaa, 0xa5,
//     0x3a, 0xde, 0xfb, 0xf4, 0xcb, 0xf7, 0x8f, 0xe4
// };


/* Example plaintext to encrypt */
//plaintext:c8d275f919e17d7fe69c2a1f58939dfe4d403791b5df1210

// static const unsigned char ccm_pt[] = {
//     0xc8, 0xd2, 0x75, 0xf9, 0x19, 0xe1, 0x7d, 0x7f, 0xe6, 0x9c, 0x2a, 0x1f,
//     0x58, 0x93, 0x9d, 0xfe, 0x4d, 0x40, 0x37, 0x91, 0xb5, 0xdf, 0x13, 0x10
// };

/* Expected ciphertext value */
// static const unsigned char ccm_ct[] = {
//     0x8a, 0x0f, 0x3d, 0x82, 0x29, 0xe4, 0x8e, 0x74, 0x87, 0xfd, 0x95, 0xa2,
//     0x8a, 0xd3, 0x92, 0xc8, 0x0b, 0x36, 0x81, 0xd4, 0xfb, 0xc7, 0xbb, 0xfd
// };

/* Expected AEAD Tag value */
// static const unsigned char ccm_tag[] = {
//     0x2d, 0xd6, 0xef, 0x1c, 0x45, 0xd4, 0xcc, 0xb7, 0x23, 0xdc, 0x07, 0x44,
//     0x14, 0xdb, 0x50, 0x6d
// };

/*
 * A library context and property query can be used to select & filter
 * algorithm implementations. If they are NULL then the default library
 * context and properties are used.
 */
OSSL_LIB_CTX *libctx = NULL;
const char *propq = NULL;


int aes_ccm_encrypt(uint8_t ccm_pt[] ,uint8_t ccm_key[],uint8_t ccm_adata[],uint8_t ccm_nonce[],uint8_t ccm_pt_len,uint8_t ccm_key_len,uint8_t ccm_adata_len,uint8_t nonce_len)
{
    int ret = 0;
    EVP_CIPHER_CTX *ctx;
    EVP_CIPHER *cipher = NULL;
    int outlen, tmplen;
    size_t ccm_nonce_len = nonce_len;
    size_t ccm_tag_len = 16;
    // printf("left ccm_nonce_len:%ld\n",ccm_nonce_len);
    // printf("left ccm_tag_len:%ld\n",ccm_tag_len);
    unsigned char outbuf[1024];
    unsigned char outtag[16];
    OSSL_PARAM params[3] = {
        OSSL_PARAM_END, OSSL_PARAM_END, OSSL_PARAM_END
    };

    // printf("AES CCM Encrypt:\n");
    // printf("Plaintext:\n");
    // BIO_dump_fp(stdout, ccm_pt, ccm_pt_len);

    /* Create a context for the encrypt operation */
    if ((ctx = EVP_CIPHER_CTX_new()) == NULL)
        goto err;

    /* Fetch the cipher implementation */
    if(ccm_key_len==24){
        //  printf("ENTER INTO KEY 192(24BYTE)\n");
        if ((cipher = EVP_CIPHER_fetch(libctx, "AES-192-CCM", propq)) == NULL)
        goto err;
    }else if(ccm_key_len==16) {
        // printf("ENTER INTO KEY 128(16BYTE)\n");
        if ((cipher = EVP_CIPHER_fetch(libctx, "AES-128-CCM", propq)) == NULL)
        goto err;
    }else if (ccm_key_len=32)
    {
        // printf("ENTER INTO KEY 256(32BYTE)\n");
        if ((cipher = EVP_CIPHER_fetch(libctx, "AES-256-CCM", propq)) == NULL)
        goto err;
    }else{
        goto err;
    }
    

    /* Set nonce length if default 96 bits is not appropriate */
    params[0] = OSSL_PARAM_construct_size_t(OSSL_CIPHER_PARAM_AEAD_IVLEN,
                                            &ccm_nonce_len);
                                       
    /* Set tag length */
    params[1] = OSSL_PARAM_construct_octet_string(OSSL_CIPHER_PARAM_AEAD_TAG,
                                                  NULL, ccm_tag_len);

    /*
     * Initialise encrypt operation with the cipher & mode,
     * nonce length and tag length parameters.
     */
    if (!EVP_EncryptInit_ex2(ctx, cipher, NULL, NULL, params))
        goto err;

    /* Initialise key and nonce */
    if (!EVP_EncryptInit_ex(ctx, NULL, NULL, ccm_key, ccm_nonce))
        goto err;

    /* Set plaintext length: only needed if AAD is used */
    if (!EVP_EncryptUpdate(ctx, NULL, &outlen, NULL, ccm_pt_len))
        goto err;

    /* Zero or one call to specify any AAD */
    if (!EVP_EncryptUpdate(ctx, NULL, &outlen, ccm_adata, ccm_adata_len))
        goto err;

    /* Encrypt plaintext: can only be called once */
    if (!EVP_EncryptUpdate(ctx, outbuf, &outlen, ccm_pt,ccm_pt_len))
        goto err;

    /* Output encrypted block */
    // printf("%s\n",outbuf);

    // printf("CIPHER MESSAGE:");
    for (int i = 0;i < outlen ;i++)
    {
        printf("%02x", outbuf[i]);
    }
    printf("\n");
    // BIO_dump_fp(stdout, outbuf, outlen);

    /* Finalise: note get no output for CCM */
    if (!EVP_EncryptFinal_ex(ctx, NULL, &tmplen))
        goto err;

    /* Get tag */
    params[0] = OSSL_PARAM_construct_octet_string(OSSL_CIPHER_PARAM_AEAD_TAG,
                                                  outtag, ccm_tag_len);
                                          
    params[1] = OSSL_PARAM_construct_end();
    // printf("%ld\n",params[0].data_size);   
    // printf("%ld\n",params[0].return_size); 
    // printf("%s\n",params[0].key);
    // printf("%p\n",params[0].data);

    if (!EVP_CIPHER_CTX_get_params(ctx, params))
        goto err;

    // /* Output tag */
    // printf("Tag:\n");
    // BIO_dump_fp(stdout, outtag, ccm_tag_len);

    ret = 1;
err:
    if (!ret)
        ERR_print_errors_fp(stderr);

    EVP_CIPHER_free(cipher);
    EVP_CIPHER_CTX_free(ctx);

    return ret;
}

int aes_ccm_decrypt(void)
{
//     int ret = 0;
//     EVP_CIPHER_CTX *ctx;
//     EVP_CIPHER *cipher = NULL;
//     int outlen, rv;
//     unsigned char outbuf[1024];
//     size_t ccm_nonce_len = 7;
//     OSSL_PARAM params[3] = {
//         OSSL_PARAM_END, OSSL_PARAM_END, OSSL_PARAM_END
//     };

//     printf("AES CCM Decrypt:\n");
//     printf("Ciphertext:\n");
//     // BIO_dump_fp(stdout, ccm_ct, sizeof(ccm_ct));

//     if ((ctx = EVP_CIPHER_CTX_new()) == NULL)
//         goto err;

//     /* Fetch the cipher implementation */
//     if ((cipher = EVP_CIPHER_fetch(libctx, "AES-192-CCM", propq)) == NULL)
//         goto err;

//     /* Set nonce length if default 96 bits is not appropriate */
//     params[0] = OSSL_PARAM_construct_size_t(OSSL_CIPHER_PARAM_AEAD_IVLEN,
//                                             &ccm_nonce_len);
//     /* Set tag length */
//     params[1] = OSSL_PARAM_construct_octet_string(OSSL_CIPHER_PARAM_AEAD_TAG,
//                                                   (unsigned char *)ccm_tag,
//                                                   sizeof(ccm_tag));
//     /*
//      * Initialise decrypt operation with the cipher & mode,
//      * nonce length and expected tag parameters.
//      */
//     if (!EVP_DecryptInit_ex2(ctx, cipher, NULL, NULL, params))
//         goto err;

//     /* Specify key and IV */
//     if (!EVP_DecryptInit_ex(ctx, NULL, NULL, ccm_key, ccm_nonce))
//         goto err;

//     /* Set ciphertext length: only needed if we have AAD */
//     if (!EVP_DecryptUpdate(ctx, NULL, &outlen, NULL, sizeof(ccm_ct)))
//         goto err;

//     /* Zero or one call to specify any AAD */
//     if (!EVP_DecryptUpdate(ctx, NULL, &outlen, ccm_adata, sizeof(ccm_adata)))
//         goto err;

//     /* Decrypt plaintext, verify tag: can only be called once */
//     rv = EVP_DecryptUpdate(ctx, outbuf, &outlen, ccm_ct, sizeof(ccm_ct));

//     /* Output decrypted block: if tag verify failed we get nothing */
//     if (rv > 0) {
//         printf("Tag verify successful!\nPlaintext:\n");
//         BIO_dump_fp(stdout, outbuf, outlen);
//     } else {
//         printf("Tag verify failed!\nPlaintext not available\n");
//         goto err;
//     }
//     ret = 1;
// err:
//     if (!ret)
//         ERR_print_errors_fp(stderr);

//     EVP_CIPHER_free(cipher);
//     EVP_CIPHER_CTX_free(ctx);

//     return ret;
}

int main(int argc, char **argv)
{ 
    uint8_t keybuff[255]={0};
    uint8_t noncebuff[255]={0};
    uint8_t tagbuff[255]={0};
    uint8_t buff[255]={0};

    uint8_t message1[16]={0};
    uint8_t message2[24]={0};
    uint8_t message3[32]={0};
    uint8_t nonce1[7]={0};
    uint8_t nonce2[7]={0};
    uint8_t nonce3[7]={0};
    uint8_t addtag1[32]={0};
    uint8_t addtag2[32]={0};
    uint8_t addtag3[32]={0};
    uint8_t key1[16]={0}; 
    uint8_t key2[24]={0}; 
    uint8_t key3[32]={0}; 

    uint8_t i;      
    uint8_t ch1;
    uint8_t ch2;
    uint8_t hash[16];

    FILE *fp = NULL;
    fp = fopen(argv[1], "r");
    fgets(buff, 255, (FILE*)fp);
    fseek(fp,0,SEEK_END);       //定位到文件末
    int nFileLen = ftell(fp);   //文件长度
    int msglen =(nFileLen-1)/2;

    // printf("msg len:%d\n",msglen);
    // printf("test read file: %s\n",buff);

    int keylen=strlen(argv[2])/2;
    int addtaglen=strlen(argv[3])/2;
    int noncelen=strlen(argv[4])/2;
    
    char *p =buff;
    for (i = 0;i < msglen ;i++)
    { 
        ch1 = *p++;
        ch2 = *p++;
        ch1 = ASCII_To_Hex(ch1);
        ch2 = ASCII_To_Hex(ch2);
        uint8_t temp2= (ch1 << 0x04) | ch2;
        buff[i]= temp2;
    }

    for (i = 0;i < keylen ;i++)
    { 
        ch1 = *argv[2]++;
        ch2 = *argv[2]++;
        ch1 = ASCII_To_Hex(ch1);
        ch2 = ASCII_To_Hex(ch2);
        uint8_t temp2= (ch1 << 0x04) | ch2;
        keybuff[i]= temp2;
    }

    for (i = 0;i < addtaglen ;i++)
    { 
        ch1 = *argv[3]++;
        ch2 = *argv[3]++;
        ch1 = ASCII_To_Hex(ch1);
        ch2 = ASCII_To_Hex(ch2);
        uint8_t temp2= (ch1 << 0x04) | ch2;
        tagbuff[i]= temp2;
    }

    for (i = 0;i < noncelen ;i++)
    { 
        ch1 = *argv[4]++;
        ch2 = *argv[4]++;
        ch1 = ASCII_To_Hex(ch1);
        ch2 = ASCII_To_Hex(ch2);
        uint8_t temp2= (ch1 << 0x04) | ch2;
        noncebuff[i]= temp2;
    }
    if(keylen==24){
        memcpy(message2,buff,msglen);
        memcpy(key2,keybuff,keylen);
        memcpy(addtag2,tagbuff,addtaglen);
        memcpy(nonce2,noncebuff,noncelen);
        int msg2len= sizeof(message2)/sizeof(message2[0]);
        int key2len= sizeof(key2)/sizeof(key2[0]);
        int addtag2len= sizeof(addtag2)/sizeof(addtag2[0]);
        int nonce2len= sizeof(nonce2)/sizeof(nonce2[0]);
        if (!aes_ccm_encrypt(message2 ,key2, addtag2, nonce2,msg2len,key2len,addtag2len,nonce2len))
        return 1;
    }else if(keylen==16){
        memcpy(message1,buff,msglen);
        memcpy(key1,keybuff,keylen);
        memcpy(addtag1,tagbuff,addtaglen);
        memcpy(nonce1,noncebuff,noncelen);
        int msg1len= sizeof(message1)/sizeof(message1[0]);
        int key1len= sizeof(key1)/sizeof(key1[0]);
        int addtag1len= sizeof(addtag1)/sizeof(addtag1[0]);
        int nonce1len= sizeof(nonce1)/sizeof(nonce1[0]);
        if (!aes_ccm_encrypt(message1 ,key1, addtag1, nonce1,msg1len,key1len,addtag1len,nonce1len))
        return 1;
    }else if(keylen==32){
        memcpy(message3,buff,msglen);
        memcpy(key3,keybuff,keylen);
        memcpy(addtag3,tagbuff,addtaglen);
        memcpy(nonce3,noncebuff,noncelen);
        int msg3len= sizeof(message3)/sizeof(message3[0]);
        int key3len= sizeof(key3)/sizeof(key3[0]);
        int addtag3len= sizeof(addtag3)/sizeof(addtag3[0]);
        int nonce3len= sizeof(nonce3)/sizeof(nonce3[0]);
        if (!aes_ccm_encrypt(message3 ,key3, addtag3, nonce3,msg3len,key3len,addtag3len,nonce3len))
        return 1;
    }else {
        return -1;
    }

    // printf("INPUT MESSAGE:");
    // for (i = 0;i < msglen ;i++)
    // {
    //     printf("%02X", message2[i]);
    // }
    // printf("\n");

    // printf("INPUT KEY:");
    // for (i = 0;i < keylen ;i++)
    // {
    //     printf("%02X", key2[i]);
    // }
    // printf("\n");

    // printf("INPUT AAD TAG:");
    // for (i = 0;i < addtaglen ;i++)
    // {
    //     printf("%02X", addtag2[i]);
    // }
    // printf("\n");

    // printf("INPUT NONCE:");
    // for (i = 0;i < noncelen ;i++)
    // {
    //     printf("%02X", nonce2[i]);
    // }
    // printf("\n");

   

   


    //printf("msg2 len:%d\n",msg2len);
    //printf("key2 len:%d\n",key2len);
    //printf("tag2 len:%d\n",addtag2len);
    //printf("nonce2 len:%d\n",nonce2len);

    // if (!aes_ccm_encrypt(message2 ,key2, addtag2, nonce2,msg2len,key2len,addtag2len,nonce2len))
    //     return 1;
 
}
    

