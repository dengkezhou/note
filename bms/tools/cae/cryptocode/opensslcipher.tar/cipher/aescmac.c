#include <stdio.h>
#include <openssl/cmac.h>
#include <string.h>

void printBytes(unsigned char *buf, size_t len) {
  for(int i=0; i<len; i++) {
    printf("%02x", buf[i]);
  }
  printf("\n");
}
 unsigned char key[] = { 0x2b,0x7e,0x15,0x16, 
                          0x28,0xae,0xd2,0xa6,
                          0xab,0xf7,0x15,0x88,
                          0x09,0xcf,0x4f,0x3c};

  unsigned char message[] = { 0x6b,0xc1,0xbe,0xe2, 
                              0x2e,0x40,0x9f,0x96, 
                              0xe9,0x3d,0x7e,0x11, 
                              0x73,0x93,0x17,0x2a };                       


uint8_t ASCII_To_Hex(uint8_t number)
{
	// if (number >= '0' && number <= '9')
	// 	return (number - 0x30);
 
	// else if (number >= 'a' && number <= 'f')
	// 	return ((number - 'a') + 10);
 
	// else  if (number >= 'A' && number <= 'F')
	// 	return ((number - 'A') + 10);
	// return (0);
}

int main(int argc, char *argv[])
{

    
  // https://tools.ietf.org/html/rfc4493
  // K, M and T from 
  // http://csrc.nist.gov/publications/nistpubs/800-38B/Updated_CMAC_Examples.pdf
  // D.1 AES-128
  // K: 2b7e151628aed2a6abf7158809cf4f3c
  // M: 6bc1bee22e409f96e93d7e117393172a Mlen: 128
  unsigned char message1[16]={0}; 
  unsigned char key1[16]={0}; 
  unsigned char message2[24]={0}; 
  unsigned char key2[24]={0}; 
  unsigned char message3[32]={0}; 
  unsigned char key3[32]={0}; 
  FILE *fp = NULL;
  unsigned char buff[255];
  unsigned char keybuff[32]={0};
  // printf("%s\n",argv[2]);
  fp = fopen(argv[1], "r");
  fgets(buff, 255, (FILE*)fp);
  fseek(fp,0,SEEK_END);       //定位到文件末
  int nFileLen = ftell(fp);   //文件长度
  int truelen =nFileLen-1;
  /* 长度以字节位单位*/ 
  int keylen=strlen(argv[2])/2;
  printf("key length :%d\n",keylen);
  printf("test read file: %s\n",buff);
	uint8_t i;
	uint8_t ch1;
	uint8_t ch2;
	char *p =buff;
	p = buff;
	for (i = 0;i < truelen/2 ;i++)
	{
		ch1 = *p++;
		ch2 = *p++;
		ch1 = ASCII_To_Hex(ch1);
		ch2 = ASCII_To_Hex(ch2);
		buff[i] = (ch1 << 0x04) | ch2;
 	}

  memcpy(message1,buff,truelen);
  printf("ORIGIN MESSAGE:\n");
  for (i = 0;i < truelen/2 ;i++)
	{
     printf("%02X", message[i]);
  }
  printf("\n");

  printf("USER MESSAGE:\n");
  for (i = 0;i < truelen/2 ;i++)
	{
     printf("%02X", message1[i]);
  }
  printf("\n");

  for (i = 0;i < keylen ;i++)
	{ 
    // printf("CH1:%d\n",*argv[1]);
		ch1 = *argv[2]++;
    // printf("CH2:%d\n",*argv[1]);
		ch2 = *argv[2]++;
		ch1 = ASCII_To_Hex(ch1);
    // printf("ch1:%d\n",ch1);
		ch2 = ASCII_To_Hex(ch2);
    // printf("ch2:%d\n",ch2);
    // // uint8_t temp= ch1<< 0x04;
    // printf("ch1 shift 4:%d\n",temp);
    uint8_t temp2= (ch1 << 0x04) | ch2;
    // printf("result2:%x\n",temp2);
    keybuff[i]= temp2;
 	}
  memcpy(key1,keybuff,keylen);
  printf("ORIGIN KEY:\n"); 
  for (i = 0;i < keylen ;i++)
	{
        printf("%02x",key[i]);
  }  
  printf("\n"); 
 
  printf("USER KEY:\n"); 
  for (i = 0;i < keylen ;i++)
	{
     printf("%02x", key1[i]);
  }
  printf("\n");


     
  // printf("--------------\n");                  
  // printf("%02x",key1[0]);
  // printf("%02x",key1[1]);
  // printf("%02x",key1[2]);
 
  // int  ret1= memcmp(message1,message,truelen/2);  
  // printf("compare message %d\n",ret1);                           

  // K: 2b7e1516 28aed2a6 abf71588 09cf4f3c
  // M: 6bc1bee22e409f96e93d7e117393172a Mlen: 128
  unsigned char mact[16] = {0}; 
  size_t mactlen;

  CMAC_CTX *ctx = CMAC_CTX_new();

  if(keylen==16){
     memcpy(key1,keybuff,keylen);
     CMAC_Init(ctx, key1, 16, EVP_aes_128_cbc(), NULL);
     CMAC_Update(ctx, message1, sizeof(message1));
  }else if(keylen ==24)
  {  
     memcpy(key2,keybuff,keylen);
     CMAC_Init(ctx, key2, 24, EVP_aes_192_cbc(), NULL);
     CMAC_Update(ctx, message2, sizeof(message2));
  }else if(keylen ==32){
     memcpy(key3,keybuff,keylen);
     CMAC_Init(ctx, key3, 32, EVP_aes_256_cbc(), NULL);
     CMAC_Update(ctx, message3, sizeof(message3));
  }else{
       return -1;
  }
  // printf("message length = %lu bytes (%lu bits)\n",sizeof(message), sizeof(message)*8);
  // int len1=sizeof(message1);
  // int len2=sizeof(message);
  // CMAC_Update(ctx, message1, sizeof(message1));
  CMAC_Final(ctx, mact, &mactlen);
   
  printf("RESULT :\n");  
  printBytes(mact, mactlen);
  /* expected result T = 070a16b4 6b4d4144 f79bdd9d d04a287c */

  CMAC_CTX_free(ctx);
  return 0;
}