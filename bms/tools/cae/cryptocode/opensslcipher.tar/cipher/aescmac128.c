#include <stdio.h>
#include <openssl/cmac.h>

void printBytes(unsigned char *buf, size_t len) {
  for(int i=0; i<len; i++) {
    printf("%02x ", buf[i]);
  }
  printf("\n");
}

int main(int argc, char *argv[])
{
  // https://tools.ietf.org/html/rfc4493

  // K, M and T from 
  // http://csrc.nist.gov/publications/nistpubs/800-38B/Updated_CMAC_Examples.pdf
  // D.1 AES-128

  // K: 2b7e1516 28aed2a6 abf71588 09cf4f3c
  unsigned char key[] = { 0x11,0x22,0x33,0x44, 
                          0x55,0x66,0x77,0x88,
                          0x88,0x77,0x66,0x55,
                          0x44,0x33,0x22,0x11};

  // M: e2d8b4f9 b8cfbc5b d27c4ddf b8747028 Mlen: 128
  
  unsigned char message[] = {0x28, 0x4b, 0x5e, 0xb3, 0x71, 0xdf, 0x8a, 0x3e, 0x66, 0xb6, 0xae, 0x03,
    0x27, 0xfc, 0xc9, 0xd0};


  unsigned char mact[16] = {0}; 
  size_t mactlen;

  CMAC_CTX *ctx = CMAC_CTX_new();
  CMAC_Init(ctx, key, 16, EVP_aes_128_cbc(), NULL);
  // printf("message length = %lu bytes (%lu bits)\n",sizeof(message), sizeof(message)*8);

  CMAC_Update(ctx, message, sizeof(message));
  CMAC_Final(ctx, mact, &mactlen);

  printf("%s", mact);
  // printBytes(mact, mactlen);

  CMAC_CTX_free(ctx);
  return 0;
}
