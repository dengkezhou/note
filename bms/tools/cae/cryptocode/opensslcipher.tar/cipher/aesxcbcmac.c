#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <tomcrypt.h>
#define STR "Hola guasssso c|mo estais ...012"
//key 000102030405060708090a0b0c0d0e0f
//msg 000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f
u_int8_t ASCII_To_Hex(u_int8_t number)
{
	if (number >= '0' && number <= '9')
		return (number - 0x30);
 
	else if (number >= 'a' && number <= 'f')
		return ((number - 'a') + 10);
 
	else  if (number >= 'A' && number <= 'F')
		return ((number - 'A') + 10);
	return (0);
}

 void print_hash(const u_int8_t *hash) {
    for (int i = 0;i < 16 ;i++)
    {
      printf("%02x",hash[i]);
    }  
     printf("\n");
 }
 int main(int argc, char *argv[]) {
      unsigned char keybuff[255]={0};
      unsigned char buff[255];
      unsigned char message1[32]={0};
      u_int8_t key1[16]={0}; 
      u_int8_t key2[24]={0};
      u_int8_t key3[32]={0};

      u_int8_t key[16]= { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                          0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f }; 
      u_int8_t i;      
      u_int8_t ch1;
      u_int8_t ch2;
      u_int8_t hash[16];
      int idx,err;
    
      FILE *fp = NULL;
      fp = fopen(argv[1], "r");
      fgets(buff, 255, (FILE*)fp);
      fseek(fp,0,SEEK_END);       //定位到文件末
      int nFileLen = ftell(fp);   //文件长度
      int msglen =(nFileLen-1)/2;
      /* 消息的长度*/
      // printf("msg len:%d\n",msglen);
      int keylen=strlen(argv[2])/2;
      /* KEY的长度*/
      // printf("key len:%d\n",keylen);
      char *p =buff;
      // printf("test read file: %s\n",buff);
      for (i = 0;i < msglen ;i++)
      { 
        ch1 = *p++;
        ch2 = *p++;
        ch1 = ASCII_To_Hex(ch1);
        ch2 = ASCII_To_Hex(ch2);
        u_int8_t temp2= (ch1 << 0x04) | ch2;
        buff[i]= temp2;
      }

      for (i = 0;i < keylen ;i++)
      { 
        ch1 = *argv[2]++;
        ch2 = *argv[2]++;
        ch1 = ASCII_To_Hex(ch1);
        ch2 = ASCII_To_Hex(ch2);
        u_int8_t temp2= (ch1 << 0x04) | ch2;
        keybuff[i]= temp2;
      }
      
      // memcpy(message1,buff,msglen);
      // memcpy(key1,keybuff,keylen);

      // printf("INPUT MESSAGE:");
      // for (i = 0;i < msglen ;i++)
      // {
      //   printf("%02X", message1[i]);
      // }
      // printf("\n");

      // printf("INPUT KEY:");
      // for (i = 0;i < keylen ;i++)
      // {
      //   printf("%02X", key1[i]);
      // }
      // printf("\n");

      // printf("ORIGIN KEY:");
      // for (i = 0;i < keylen ;i++)
      // {
      //   printf("%02X", key[i]);
      // }
      // printf("\n");
 
      unsigned long taglen = 16;
      register_cipher( & aes_desc);
      if ((idx = find_cipher("aes")) == -1) {
          if ((idx = find_cipher("rijndael")) == -1) {
            printf("idx:%d\n",idx);
            return CRYPT_NOP;
        }
      }
      if(keylen==16){
        memcpy(message1,buff,msglen);
        memcpy(key1,keybuff,keylen);
        if ((err = xcbc_memory(idx, key1, keylen, message1,msglen,hash, &taglen)) != CRYPT_OK){
          printf("err:%d\n",idx);
          return err; 
        }
      }else if(keylen==24)
      {
        memcpy(message1,buff,msglen);
        memcpy(key2,keybuff,keylen);
        if ((err = xcbc_memory(idx, key2, keylen, message1, msglen,hash, &taglen)) != CRYPT_OK){
          printf("err:%d\n",idx);
          return err;
        }
      }else if(keylen==32)
      {
        memcpy(message1,buff,msglen);
        memcpy(key3,keybuff,keylen);
        if ((err = xcbc_memory(idx, key3, keylen, message1, msglen,hash, &taglen)) != CRYPT_OK){
          printf("err:%d\n",idx);
          return err;
        }
      }
      print_hash(hash);
      return 0;
 }

