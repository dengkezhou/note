#include "adv7513.h"
#include <stdio.h>
#include "main.h"

extern I2C_HandleTypeDef hi2c1;


#define MAIN_ADDR 0x72

uint8_t slaveaddr = 0x72;

uint8_t HPD = 0;
uint8_t INT = 0;


uint8_t readbuf[10];
HAL_StatusTypeDef  sta;

uint8_t test = 1;

uint8_t HAL_I2CReadByte (uint8_t Dev, uint8_t Reg, uint8_t *Data)
{   
	  HAL_I2C_Mem_Read(&hi2c1, Dev,Reg , 1 , Data, 1, 50);
    return 1;
}

/*===========================================================================
 *
 *==========================================================================*/

uint8_t HAL_I2CWriteByte (uint8_t Dev, uint8_t Reg, uint8_t Data)
{   
	  HAL_StatusTypeDef wirtestatus;
	 	uint8_t val;
	  wirtestatus =  HAL_I2C_Mem_Write(&hi2c1, Dev,Reg , 1 , &Data, 1, 50);
	  HAL_I2CReadByte(Dev,Reg,&val); 
    return wirtestatus;
}

void check_adv()
{
  uint8_t val;
	
	do{
	  HAL_I2CReadByte(0x72,0x00,&val);
	}while(val != 0x13);
}

void reg_set_bit(uint8_t reg, uint8_t bit,uint8_t value)
{   
	  uint8_t data;
		HAL_I2CReadByte(0x72,reg,&data);
	  
    if(value == 0) data &= ~(1<<bit);
	  else data |= (1<<bit);
	  
   	HAL_I2CWriteByte (0x72,reg,data);
}


void adv_init()
{
	
	
  HAL_I2CWriteByte (0x72,0x41,0x10);
	HAL_Delay(100);
	
  HAL_I2CWriteByte (0x72,0x98,0x03);
	HAL_I2CWriteByte (0x72,0x9a,0xe0);
	HAL_I2CWriteByte (0x72,0x9c,0x30);
	HAL_I2CWriteByte (0x72,0x9d,0x01);
	HAL_I2CWriteByte (0x72,0xa2,0xa4);
	HAL_I2CWriteByte (0x72,0xa3,0xa4);
	HAL_I2CWriteByte (0x72,0xe0,0xd0);
	HAL_I2CWriteByte (0x72,0xf9,0x00);
	
	//bt656 8bit PD0~PD7
	//HAL_I2CWriteByte (0x72,0x15,0x04); 
	//HAL_I2CWriteByte (0x72,0x16,0xB5);//PD0~PD7
	
	//bt656 8bit PD8~PD15
	//HAL_I2CWriteByte (0x72,0x15,0x04); 
	//HAL_I2CWriteByte (0x72,0x16,0xB9);
	
	//bt656 16bit
	HAL_I2CWriteByte (0x72,0x15,0x02); //embed ID 2
	HAL_I2CWriteByte (0x72,0x16,0xBD); //style 3
	
	
	HAL_I2CWriteByte (0x72,0xd0,0x30);
	HAL_I2CWriteByte (0X72,0x48,0x00);

	
	//HAL_I2CWriteByte (0x72,0x9d,0x61);
	//HAL_I2CWriteByte (0x72,0x3B,0x80);
	//HAL_I2CWriteByte (0x72,0x18,0x06);
	HAL_I2CWriteByte (0x72,0xAF,0x06);
	

	HAL_I2CWriteByte (0X72,0x55,0x20);
  HAL_I2CWriteByte (0X72,0x56,0x08);
		
	HAL_I2CWriteByte(0x72, 0x17, 0x02);
  HAL_I2CWriteByte(0x72, 0x30, 0x1B);   // Register Settings for Embedded Sync Processing  00011011
	HAL_I2CWriteByte(0x72, 0x31, 0x82);   // Register Settings for Embedded Sync Processing  10000010
	HAL_I2CWriteByte(0x72, 0x32, 0x80);   // Register Settings for Embedded Sync Processing  10000000
	HAL_I2CWriteByte(0x72, 0x33, 0x14);   // Register Settings for Embedded Sync Processing  00010100
  HAL_I2CWriteByte(0x72, 0x34, 0x05);   // Register Settings for Embedded Sync Processing  00000101
	

}

	
void adv_thread(void) 
{  
	 STATE_LED_OFF;
   POWER_LED_OFF;
   HAL_Delay(1000);
	 check_adv();
	 adv_init();
	 POWER_LED_ON;

   while(1)
  { 
		

		HAL_I2CReadByte(0x72,0x42,readbuf);
		HAL_I2CReadByte(0x72,0x41,readbuf+1);	
		HAL_I2CReadByte(0x72,0x9e,readbuf+2); // READ PLL STATE
		
		if(readbuf[2] & 0x10)  // 
		{
		  STATE_LED_ON;
		}else 
		{
		  STATE_LED_OFF;
		}

  }

}


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  UNUSED(GPIO_Pin);
   
	if(GPIO_Pin == GPIO_PIN_1)
	{
	  HPD = 1;
	}
	
	if(GPIO_Pin == GPIO_PIN_0)
	{
	  INT = 1;
	}
 
}
