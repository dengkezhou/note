#ifndef _ADV7513_H_
#define _ADV7513_H_

#include "main.h"
#include "stm32f0xx_hal.h"


#define POWER_LED_GPIO    GPIOA
#define POWER_LED_PIN     GPIO_PIN_4


#define STATE_LED_GPIO    GPIOA
#define STATE_LED_PIN     GPIO_PIN_8


#define POWER_LED_ON      HAL_GPIO_WritePin(POWER_LED_GPIO, POWER_LED_PIN,GPIO_PIN_RESET)
#define POWER_LED_OFF      HAL_GPIO_WritePin(POWER_LED_GPIO, POWER_LED_PIN,GPIO_PIN_SET)

#define STATE_LED_ON      HAL_GPIO_WritePin(STATE_LED_GPIO, STATE_LED_PIN,GPIO_PIN_RESET)
#define STATE_LED_OFF      HAL_GPIO_WritePin(STATE_LED_GPIO, STATE_LED_PIN,GPIO_PIN_SET)

void adv_thread(void);

#endif
