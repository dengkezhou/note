/**********************************************************************
* Copyright (C) 2018 Cadence Design Systems, Inc.
* All rights reserved worldwide
* The material contained herein is the proprietary and confidential
* information of Cadence or its licensors, and is supplied subject to, and may
* be used only by Cadence's customer in accordance with a previously executed
* license and maintenance agreement between Cadence and that customer.
**********************************************************************
* Target Interface APIs
**********************************************************************/
#if !defined __INTERFACE_LIB_H__
#define __INTERFACE_LIB_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <SDKDDKVer.h>
#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>


	__declspec(dllexport) INT32 __cdecl OpenConnection(const char * ipAddress, const char * port);

	__declspec(dllexport) INT32  __cdecl  ReadMemory(UINT32 memAddress, INT32* memValuePtr);

	__declspec(dllexport) INT32  __cdecl  WriteMemory(UINT32 memAddress, UINT32 memValue);

	__declspec(dllexport) void  __cdecl CloseConnection();

#ifdef __cplusplus
}
#endif

#endif