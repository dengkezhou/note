//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[17];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(97,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(353,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(609,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(865,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(1389,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(14,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(270,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(526,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(782,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(81,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(337,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(593,true);
    temp_reg[12] = (UInt32)jtag_dll_mc_reg_read(849,true);
    temp_reg[13] = (UInt32)jtag_dll_mc_reg_read(82,true);
    temp_reg[14] = (UInt32)jtag_dll_mc_reg_read(338,true);
    temp_reg[15] = (UInt32)jtag_dll_mc_reg_read(594,true);
    temp_reg[16] = (UInt32)jtag_dll_mc_reg_read(850,true);
}
void Group_read() {
    read_fn();

    PHY_PAD_VREF_CTRL_DQ_0 = (UInt32)GetBitsFromValue(temp_reg[0],16+(12-1),16);
    PHY_PAD_VREF_CTRL_DQ_1 = (UInt32)GetBitsFromValue(temp_reg[1],16+(12-1),16);
    PHY_PAD_VREF_CTRL_DQ_2 = (UInt32)GetBitsFromValue(temp_reg[2],16+(12-1),16);
    PHY_PAD_VREF_CTRL_DQ_3 = (UInt32)GetBitsFromValue(temp_reg[3],16+(12-1),16);
    PHY_PAD_VREF_CTRL_AC = (UInt32)GetBitsFromValue(temp_reg[4],0+(12-1),0);
    PHY_VREF_INITIAL_STEPSIZE_0 = (UInt32)GetBitsFromValue(temp_reg[5],0+(6-1),0);
    PHY_VREF_INITIAL_STEPSIZE_1 = (UInt32)GetBitsFromValue(temp_reg[6],0+(6-1),0);
    PHY_VREF_INITIAL_STEPSIZE_2 = (UInt32)GetBitsFromValue(temp_reg[7],0+(6-1),0);
    PHY_VREF_INITIAL_STEPSIZE_3 = (UInt32)GetBitsFromValue(temp_reg[8],0+(6-1),0);
    PHY_VREF_INITIAL_START_POINT_0 = (UInt32)GetBitsFromValue(temp_reg[9],24+(7-1),24);
    PHY_VREF_INITIAL_START_POINT_1 = (UInt32)GetBitsFromValue(temp_reg[10],24+(7-1),24);
    PHY_VREF_INITIAL_START_POINT_2 = (UInt32)GetBitsFromValue(temp_reg[11],24+(7-1),24);
    PHY_VREF_INITIAL_START_POINT_3 = (UInt32)GetBitsFromValue(temp_reg[12],24+(7-1),24);
    PHY_VREF_INITIAL_STOP_POINT_0 = (UInt32)GetBitsFromValue(temp_reg[13],0+(7-1),0);
    PHY_VREF_INITIAL_STOP_POINT_1 = (UInt32)GetBitsFromValue(temp_reg[14],0+(7-1),0);
    PHY_VREF_INITIAL_STOP_POINT_2 = (UInt32)GetBitsFromValue(temp_reg[15],0+(7-1),0);
    PHY_VREF_INITIAL_STOP_POINT_3 = (UInt32)GetBitsFromValue(temp_reg[16],0+(7-1),0);
    PHY_VREF_TRAINING_CTRL_0 = (UInt32)GetBitsFromValue(temp_reg[13],8+(2-1),8);
    PHY_VREF_TRAINING_CTRL_1 = (UInt32)GetBitsFromValue(temp_reg[14],8+(2-1),8);
    PHY_VREF_TRAINING_CTRL_2 = (UInt32)GetBitsFromValue(temp_reg[15],8+(2-1),8);
    PHY_VREF_TRAINING_CTRL_3 = (UInt32)GetBitsFromValue(temp_reg[16],8+(2-1),8);
    PHY_VREF_SETTING_TIME_0 = (UInt32)GetBitsFromValue(temp_reg[0],0+(16-1),0);
    PHY_VREF_SETTING_TIME_1 = (UInt32)GetBitsFromValue(temp_reg[1],0+(16-1),0);
    PHY_VREF_SETTING_TIME_2 = (UInt32)GetBitsFromValue(temp_reg[2],0+(16-1),0);
    PHY_VREF_SETTING_TIME_3 = (UInt32)GetBitsFromValue(temp_reg[3],0+(16-1),0);
    PHY_VREF_TRAIN_OBS_0 = (UInt32)GetBitsFromValue(temp_reg[5],8+(7-1),8);
    PHY_VREF_TRAIN_OBS_1 = (UInt32)GetBitsFromValue(temp_reg[6],8+(7-1),8);
    PHY_VREF_TRAIN_OBS_2 = (UInt32)GetBitsFromValue(temp_reg[7],8+(7-1),8);
    PHY_VREF_TRAIN_OBS_3 = (UInt32)GetBitsFromValue(temp_reg[8],8+(7-1),8);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_PAD_VREF_CTRL_DQ_0, temp_reg[0] ,16+(12-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_PAD_VREF_CTRL_DQ_1, temp_reg[1] ,16+(12-1),16);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_PAD_VREF_CTRL_DQ_2, temp_reg[2] ,16+(12-1),16);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_PAD_VREF_CTRL_DQ_3, temp_reg[3] ,16+(12-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_PAD_VREF_CTRL_AC, temp_reg[4] ,0+(12-1),0);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_STEPSIZE_0, temp_reg[5] ,0+(6-1),0);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_STEPSIZE_1, temp_reg[6] ,0+(6-1),0);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_STEPSIZE_2, temp_reg[7] ,0+(6-1),0);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_STEPSIZE_3, temp_reg[8] ,0+(6-1),0);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_START_POINT_0, temp_reg[9] ,24+(7-1),24);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_START_POINT_1, temp_reg[10] ,24+(7-1),24);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_START_POINT_2, temp_reg[11] ,24+(7-1),24);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_START_POINT_3, temp_reg[12] ,24+(7-1),24);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_STOP_POINT_0, temp_reg[13] ,0+(7-1),0);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_STOP_POINT_1, temp_reg[14] ,0+(7-1),0);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_STOP_POINT_2, temp_reg[15] ,0+(7-1),0);
    temp_reg[16] = (UInt32)WriteBitsToValue(PHY_VREF_INITIAL_STOP_POINT_3, temp_reg[16] ,0+(7-1),0);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_VREF_TRAINING_CTRL_0, temp_reg[13] ,8+(2-1),8);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_VREF_TRAINING_CTRL_1, temp_reg[14] ,8+(2-1),8);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_VREF_TRAINING_CTRL_2, temp_reg[15] ,8+(2-1),8);
    temp_reg[16] = (UInt32)WriteBitsToValue(PHY_VREF_TRAINING_CTRL_3, temp_reg[16] ,8+(2-1),8);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_VREF_SETTING_TIME_0, temp_reg[0] ,0+(16-1),0);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_VREF_SETTING_TIME_1, temp_reg[1] ,0+(16-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_VREF_SETTING_TIME_2, temp_reg[2] ,0+(16-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_VREF_SETTING_TIME_3, temp_reg[3] ,0+(16-1),0);
    jtag_dll_mc_reg_write(97, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(353, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(609, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(865, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(1389, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(14, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(270, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(526, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(782, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(81, temp_reg[9] ,true);
    jtag_dll_mc_reg_write(337, temp_reg[10] ,true);
    jtag_dll_mc_reg_write(593, temp_reg[11] ,true);
    jtag_dll_mc_reg_write(849, temp_reg[12] ,true);
    jtag_dll_mc_reg_write(82, temp_reg[13] ,true);
    jtag_dll_mc_reg_write(338, temp_reg[14] ,true);
    jtag_dll_mc_reg_write(594, temp_reg[15] ,true);
    jtag_dll_mc_reg_write(850, temp_reg[16] ,true);
}
