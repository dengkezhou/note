﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace TekVisaIf
{
    class TekUpload
    {
        static string uriBase = "http://tickets:8080";

        static string uploadSuite = "/testdb/test.jsp?action=new&cat=1&suite=1";

        WebClient client = new WebClient();

        public TekUpload()
        {
            client.BaseAddress = uriBase;
            client.Proxy = GlobalProxySelection.GetEmptyWebProxy();
        }

        /**
         * Call this with the data from GetSuiteConfigInfo
         * @param data string from GetSuiteConfigInfo
         * @return string used in next call
         */
        public string UploadSuiteRun(string data)
        {
            string result = client.DownloadString(uploadSuite + "&data=" + data);
            return result;
        }

        /**
         * Call this with the result of the relevant UploadSuiteRun, and the data from GetNewTestRunInfoF
         * @param suiteResult string from UploadSuiteRun
         * @param data string from GetNewTestRunInfo
         * @return string used in next call
         */
        public string UploadTestRunInfoF(string suiteResult, string data)
        {
            string result = client.DownloadString(uploadSuite + suiteResult + "&tid=3&data=" + data);
            return result;
        }

        /**
         * Call this with the result of the relevant UploadTestRunInfo, and the data from calls to GetRunIterHeaderF/GetRunIterDataF
         * @param suiteResult string from UploadSuiteRun
         * @param data string from GetRunIterHeader & one or more GetRunIterData
         */
        public void UploadTestRunItersF(string runinfoResult, string data)
        {
            client.DownloadString(uploadSuite + runinfoResult + "&data=" + data);
        }

    }

}
