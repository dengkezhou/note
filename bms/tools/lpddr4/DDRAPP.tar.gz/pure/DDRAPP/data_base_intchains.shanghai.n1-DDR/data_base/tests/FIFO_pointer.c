//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[8];

void SC_PHY_SNAP_OBS_REGS_0() {
    jtag_dll_mc_reg_write(15,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(15, true),8 + 1 -1,8) ,true);
    jtag_dll_mc_reg_write(271,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(271, true),8 + 1 -1,8) ,true);
    jtag_dll_mc_reg_write(527,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(527, true),8 + 1 -1,8) ,true);
    jtag_dll_mc_reg_write(783,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(783, true),8 + 1 -1,8) ,true);
}

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(103,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(359,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(615,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(871,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(29,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(285,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(541,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(797,true);
}
void Group_read() {

    SC_PHY_SNAP_OBS_REGS_0();
    read_fn();

    PHY_RPTR_UPDATE_0 = (UInt32)GetBitsFromValue(temp_reg[0],8+(4-1),8);
    PHY_RPTR_UPDATE_1 = (UInt32)GetBitsFromValue(temp_reg[1],8+(4-1),8);
    PHY_RPTR_UPDATE_2 = (UInt32)GetBitsFromValue(temp_reg[2],8+(4-1),8);
    PHY_RPTR_UPDATE_3 = (UInt32)GetBitsFromValue(temp_reg[3],8+(4-1),8);
    UInt32 temp_obs = 0;

    temp_reg[4] = (UInt32)WriteBitsToValue(0,temp_reg[4],24 + 4 -1,24);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(45,true);
    PHY_0_RDDQ_wptr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[4] = (UInt32)WriteBitsToValue(1,temp_reg[4],24 + 4 -1,24);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(45,true);
    PHY_1_RDDQ_wptr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[4] = (UInt32)WriteBitsToValue(2,temp_reg[4],24 + 4 -1,24);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(45,true);
    PHY_2_RDDQ_wptr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[4] = (UInt32)WriteBitsToValue(3,temp_reg[4],24 + 4 -1,24);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(45,true);
    PHY_3_RDDQ_wptr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[4] = (UInt32)WriteBitsToValue(4,temp_reg[4],24 + 4 -1,24);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(45,true);
    PHY_4_RDDQ_wptr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[4] = (UInt32)WriteBitsToValue(5,temp_reg[4],24 + 4 -1,24);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(45,true);
    PHY_5_RDDQ_wptr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[4] = (UInt32)WriteBitsToValue(6,temp_reg[4],24 + 4 -1,24);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(45,true);
    PHY_6_RDDQ_wptr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[4] = (UInt32)WriteBitsToValue(7,temp_reg[4],24 + 4 -1,24);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(45,true);
    PHY_7_RDDQ_wptr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[5] = (UInt32)WriteBitsToValue(0,temp_reg[5],24 + 4 -1,24);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(301,true);
    PHY_0_RDDQ_wptr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[5] = (UInt32)WriteBitsToValue(1,temp_reg[5],24 + 4 -1,24);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(301,true);
    PHY_1_RDDQ_wptr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[5] = (UInt32)WriteBitsToValue(2,temp_reg[5],24 + 4 -1,24);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(301,true);
    PHY_2_RDDQ_wptr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[5] = (UInt32)WriteBitsToValue(3,temp_reg[5],24 + 4 -1,24);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(301,true);
    PHY_3_RDDQ_wptr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[5] = (UInt32)WriteBitsToValue(4,temp_reg[5],24 + 4 -1,24);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(301,true);
    PHY_4_RDDQ_wptr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[5] = (UInt32)WriteBitsToValue(5,temp_reg[5],24 + 4 -1,24);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(301,true);
    PHY_5_RDDQ_wptr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[5] = (UInt32)WriteBitsToValue(6,temp_reg[5],24 + 4 -1,24);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(301,true);
    PHY_6_RDDQ_wptr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[5] = (UInt32)WriteBitsToValue(7,temp_reg[5],24 + 4 -1,24);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(301,true);
    PHY_7_RDDQ_wptr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[6] = (UInt32)WriteBitsToValue(0,temp_reg[6],24 + 4 -1,24);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(557,true);
    PHY_0_RDDQ_wptr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[6] = (UInt32)WriteBitsToValue(1,temp_reg[6],24 + 4 -1,24);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(557,true);
    PHY_1_RDDQ_wptr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[6] = (UInt32)WriteBitsToValue(2,temp_reg[6],24 + 4 -1,24);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(557,true);
    PHY_2_RDDQ_wptr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[6] = (UInt32)WriteBitsToValue(3,temp_reg[6],24 + 4 -1,24);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(557,true);
    PHY_3_RDDQ_wptr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[6] = (UInt32)WriteBitsToValue(4,temp_reg[6],24 + 4 -1,24);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(557,true);
    PHY_4_RDDQ_wptr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[6] = (UInt32)WriteBitsToValue(5,temp_reg[6],24 + 4 -1,24);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(557,true);
    PHY_5_RDDQ_wptr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[6] = (UInt32)WriteBitsToValue(6,temp_reg[6],24 + 4 -1,24);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(557,true);
    PHY_6_RDDQ_wptr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[6] = (UInt32)WriteBitsToValue(7,temp_reg[6],24 + 4 -1,24);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(557,true);
    PHY_7_RDDQ_wptr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[7] = (UInt32)WriteBitsToValue(0,temp_reg[7],24 + 4 -1,24);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(813,true);
    PHY_0_RDDQ_wptr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[7] = (UInt32)WriteBitsToValue(1,temp_reg[7],24 + 4 -1,24);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(813,true);
    PHY_1_RDDQ_wptr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[7] = (UInt32)WriteBitsToValue(2,temp_reg[7],24 + 4 -1,24);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(813,true);
    PHY_2_RDDQ_wptr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[7] = (UInt32)WriteBitsToValue(3,temp_reg[7],24 + 4 -1,24);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(813,true);
    PHY_3_RDDQ_wptr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[7] = (UInt32)WriteBitsToValue(4,temp_reg[7],24 + 4 -1,24);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(813,true);
    PHY_4_RDDQ_wptr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[7] = (UInt32)WriteBitsToValue(5,temp_reg[7],24 + 4 -1,24);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(813,true);
    PHY_5_RDDQ_wptr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[7] = (UInt32)WriteBitsToValue(6,temp_reg[7],24 + 4 -1,24);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(813,true);
    PHY_6_RDDQ_wptr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[7] = (UInt32)WriteBitsToValue(7,temp_reg[7],24 + 4 -1,24);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(813,true);
    PHY_7_RDDQ_wptr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[4] = (UInt32)WriteBitsToValue(8,temp_reg[4],24 + 4 -1,24);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(45,true);
    PHY_8_RDDM_wptr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[5] = (UInt32)WriteBitsToValue(8,temp_reg[5],24 + 4 -1,24);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(301,true);
    PHY_8_RDDM_wptr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[6] = (UInt32)WriteBitsToValue(8,temp_reg[6],24 + 4 -1,24);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(557,true);
    PHY_8_RDDM_wptr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[7] = (UInt32)WriteBitsToValue(8,temp_reg[7],24 + 4 -1,24);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(813,true);
    PHY_8_RDDM_wptr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[4] = (UInt32)WriteBitsToValue(9,temp_reg[4],24 + 4 -1,24);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(45,true);
    PHY_9_RDDQ_rptr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[5] = (UInt32)WriteBitsToValue(9,temp_reg[5],24 + 4 -1,24);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(301,true);
    PHY_9_RDDQ_rptr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[6] = (UInt32)WriteBitsToValue(9,temp_reg[6],24 + 4 -1,24);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(557,true);
    PHY_9_RDDQ_rptr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

    temp_reg[7] = (UInt32)WriteBitsToValue(9,temp_reg[7],24 + 4 -1,24);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(813,true);
    PHY_9_RDDQ_rptr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 7, 24);

}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_RPTR_UPDATE_0, temp_reg[0] ,8+(4-1),8);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_RPTR_UPDATE_1, temp_reg[1] ,8+(4-1),8);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_RPTR_UPDATE_2, temp_reg[2] ,8+(4-1),8);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_RPTR_UPDATE_3, temp_reg[3] ,8+(4-1),8);
    jtag_dll_mc_reg_write(103, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(359, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(615, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(871, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(29, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(285, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(541, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(797, temp_reg[7] ,true);
}
