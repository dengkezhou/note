//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[16];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(80,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(336,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(592,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(848,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(95,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(351,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(607,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(863,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(81,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(337,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(593,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(849,true);
    temp_reg[12] = (UInt32)jtag_dll_mc_reg_read(96,true);
    temp_reg[13] = (UInt32)jtag_dll_mc_reg_read(352,true);
    temp_reg[14] = (UInt32)jtag_dll_mc_reg_read(608,true);
    temp_reg[15] = (UInt32)jtag_dll_mc_reg_read(864,true);
}
void Group_read() {
    read_fn();

    PHY_DQ_TSEL_SELECT_0 = (UInt32)GetBitsFromValue(temp_reg[0],8+(16-1),8);
    PHY_DQ_TSEL_SELECT_1 = (UInt32)GetBitsFromValue(temp_reg[1],8+(16-1),8);
    PHY_DQ_TSEL_SELECT_2 = (UInt32)GetBitsFromValue(temp_reg[2],8+(16-1),8);
    PHY_DQ_TSEL_SELECT_3 = (UInt32)GetBitsFromValue(temp_reg[3],8+(16-1),8);
    PHY_DQ_TSEL_ENABLE_0 = (UInt32)GetBitsFromValue(temp_reg[0],0+(3-1),0);
    PHY_DQ_TSEL_ENABLE_1 = (UInt32)GetBitsFromValue(temp_reg[1],0+(3-1),0);
    PHY_DQ_TSEL_ENABLE_2 = (UInt32)GetBitsFromValue(temp_reg[2],0+(3-1),0);
    PHY_DQ_TSEL_ENABLE_3 = (UInt32)GetBitsFromValue(temp_reg[3],0+(3-1),0);
    PHY_DQ_TSEL_WR_TIMING_0 = (UInt32)GetBitsFromValue(temp_reg[4],16+(8-1),16);
    PHY_DQ_TSEL_WR_TIMING_1 = (UInt32)GetBitsFromValue(temp_reg[5],16+(8-1),16);
    PHY_DQ_TSEL_WR_TIMING_2 = (UInt32)GetBitsFromValue(temp_reg[6],16+(8-1),16);
    PHY_DQ_TSEL_WR_TIMING_3 = (UInt32)GetBitsFromValue(temp_reg[7],16+(8-1),16);
    PHY_DQ_TSEL_RD_TIMING_0 = (UInt32)GetBitsFromValue(temp_reg[4],8+(8-1),8);
    PHY_DQ_TSEL_RD_TIMING_1 = (UInt32)GetBitsFromValue(temp_reg[5],8+(8-1),8);
    PHY_DQ_TSEL_RD_TIMING_2 = (UInt32)GetBitsFromValue(temp_reg[6],8+(8-1),8);
    PHY_DQ_TSEL_RD_TIMING_3 = (UInt32)GetBitsFromValue(temp_reg[7],8+(8-1),8);
    PHY_DQS_TSEL_SELECT_0 = (UInt32)GetBitsFromValue(temp_reg[8],0+(16-1),0);
    PHY_DQS_TSEL_SELECT_1 = (UInt32)GetBitsFromValue(temp_reg[9],0+(16-1),0);
    PHY_DQS_TSEL_SELECT_2 = (UInt32)GetBitsFromValue(temp_reg[10],0+(16-1),0);
    PHY_DQS_TSEL_SELECT_3 = (UInt32)GetBitsFromValue(temp_reg[11],0+(16-1),0);
    PHY_DQS_TSEL_ENABLE_0 = (UInt32)GetBitsFromValue(temp_reg[0],24+(3-1),24);
    PHY_DQS_TSEL_ENABLE_1 = (UInt32)GetBitsFromValue(temp_reg[1],24+(3-1),24);
    PHY_DQS_TSEL_ENABLE_2 = (UInt32)GetBitsFromValue(temp_reg[2],24+(3-1),24);
    PHY_DQS_TSEL_ENABLE_3 = (UInt32)GetBitsFromValue(temp_reg[3],24+(3-1),24);
    PHY_DQS_TSEL_WR_TIMING_0 = (UInt32)GetBitsFromValue(temp_reg[12],24+(8-1),24);
    PHY_DQS_TSEL_WR_TIMING_1 = (UInt32)GetBitsFromValue(temp_reg[13],24+(8-1),24);
    PHY_DQS_TSEL_WR_TIMING_2 = (UInt32)GetBitsFromValue(temp_reg[14],24+(8-1),24);
    PHY_DQS_TSEL_WR_TIMING_3 = (UInt32)GetBitsFromValue(temp_reg[15],24+(8-1),24);
    PHY_DQS_TSEL_RD_TIMING_0 = (UInt32)GetBitsFromValue(temp_reg[12],8+(8-1),8);
    PHY_DQS_TSEL_RD_TIMING_1 = (UInt32)GetBitsFromValue(temp_reg[13],8+(8-1),8);
    PHY_DQS_TSEL_RD_TIMING_2 = (UInt32)GetBitsFromValue(temp_reg[14],8+(8-1),8);
    PHY_DQS_TSEL_RD_TIMING_3 = (UInt32)GetBitsFromValue(temp_reg[15],8+(8-1),8);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_SELECT_0, temp_reg[0] ,8+(16-1),8);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_SELECT_1, temp_reg[1] ,8+(16-1),8);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_SELECT_2, temp_reg[2] ,8+(16-1),8);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_SELECT_3, temp_reg[3] ,8+(16-1),8);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_ENABLE_0, temp_reg[0] ,0+(3-1),0);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_ENABLE_1, temp_reg[1] ,0+(3-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_ENABLE_2, temp_reg[2] ,0+(3-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_ENABLE_3, temp_reg[3] ,0+(3-1),0);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_WR_TIMING_0, temp_reg[4] ,16+(8-1),16);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_WR_TIMING_1, temp_reg[5] ,16+(8-1),16);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_WR_TIMING_2, temp_reg[6] ,16+(8-1),16);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_WR_TIMING_3, temp_reg[7] ,16+(8-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_RD_TIMING_0, temp_reg[4] ,8+(8-1),8);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_RD_TIMING_1, temp_reg[5] ,8+(8-1),8);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_RD_TIMING_2, temp_reg[6] ,8+(8-1),8);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_DQ_TSEL_RD_TIMING_3, temp_reg[7] ,8+(8-1),8);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_SELECT_0, temp_reg[8] ,0+(16-1),0);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_SELECT_1, temp_reg[9] ,0+(16-1),0);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_SELECT_2, temp_reg[10] ,0+(16-1),0);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_SELECT_3, temp_reg[11] ,0+(16-1),0);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_ENABLE_0, temp_reg[0] ,24+(3-1),24);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_ENABLE_1, temp_reg[1] ,24+(3-1),24);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_ENABLE_2, temp_reg[2] ,24+(3-1),24);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_ENABLE_3, temp_reg[3] ,24+(3-1),24);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_WR_TIMING_0, temp_reg[12] ,24+(8-1),24);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_WR_TIMING_1, temp_reg[13] ,24+(8-1),24);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_WR_TIMING_2, temp_reg[14] ,24+(8-1),24);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_WR_TIMING_3, temp_reg[15] ,24+(8-1),24);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_RD_TIMING_0, temp_reg[12] ,8+(8-1),8);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_RD_TIMING_1, temp_reg[13] ,8+(8-1),8);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_RD_TIMING_2, temp_reg[14] ,8+(8-1),8);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_DQS_TSEL_RD_TIMING_3, temp_reg[15] ,8+(8-1),8);
    jtag_dll_mc_reg_write(80, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(336, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(592, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(848, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(95, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(351, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(607, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(863, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(81, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(337, temp_reg[9] ,true);
    jtag_dll_mc_reg_write(593, temp_reg[10] ,true);
    jtag_dll_mc_reg_write(849, temp_reg[11] ,true);
    jtag_dll_mc_reg_write(96, temp_reg[12] ,true);
    jtag_dll_mc_reg_write(352, temp_reg[13] ,true);
    jtag_dll_mc_reg_write(608, temp_reg[14] ,true);
    jtag_dll_mc_reg_write(864, temp_reg[15] ,true);
}
