//****************************************************************************************
//                       © 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence’s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
struct Margin{
	public int Low;
	public int High;

	public Margin(int low, int high)
	{
		High = high;
		Low = low;
	}
};

////// START -- Code for Read_DQ Margin ///
const Int32 PHY_VREF_VALUE_MAX = 0x7F;
UInt32[,] InitRdRDQS_DQ_RiseFallDelay = new UInt32[10, 2];                // [index, 0] = rise , [index, 1] =  fall



void SaveRdRDQS_DQ_RiseFallDelay(UInt32 sliceNo)
{
	UInt32 index = 0;
	UInt32 startAddress = (UInt32)PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_ADDR + (sliceNo * (UInt32)HS_SLICE_REG_COUNT);
	InitRdRDQS_DQ_RiseFallDelay[index, 0] = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(startAddress, true), (int)(PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_OFFSET + (PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_WIDTH-1)), (int)PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_OFFSET);
	
	for (index = 1; index < 9; index++)
	{
		InitRdRDQS_DQ_RiseFallDelay[index, 0] = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(startAddress + index, true), (int)(PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_0_OFFSET + (PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_0_WIDTH-1) ), (int)PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_0_OFFSET);
		InitRdRDQS_DQ_RiseFallDelay[(index - 1), 1] = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(startAddress + index, true), (int)(PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_OFFSET + (PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_WIDTH-1)), (int)PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_OFFSET);
	}
	
	InitRdRDQS_DQ_RiseFallDelay[(index - 1), 1] = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(startAddress + index, true), (int)(PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_OFFSET + (PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_WIDTH-1)), (int)PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_OFFSET);

}

void SetRdRDQS_DQ_RiseFallDelay(UInt32 sliceNo, UInt32 delay)
{
	UInt32 index = 0;
	UInt32 startAddress = (UInt32)PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_ADDR + (sliceNo * (UInt32)HS_SLICE_REG_COUNT);
	UInt32 riseFallDelay = (delay << 16) | delay;
	
	jtag_dll_mc_reg_write(startAddress, WriteBitsToValue(delay, jtag_dll_mc_reg_read(startAddress, true), (int)(PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_OFFSET + (PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_WIDTH - 1)), (int)PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_OFFSET), true);
	
	for (index = 1; index < 9; index++)
	{
		jtag_dll_mc_reg_write(startAddress + index, riseFallDelay, true);
	}
	jtag_dll_mc_reg_write(startAddress + index, WriteBitsToValue(delay, jtag_dll_mc_reg_read(startAddress + index, true), (int)(PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_OFFSET + (PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_WIDTH - 1)), (int)PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_OFFSET), true);
	
	jtag_dll_mc_reg_write(SC_PHY_MANUAL_UPDATE_ADDR, WriteBitsToValue(1, jtag_dll_mc_reg_read(SC_PHY_MANUAL_UPDATE_ADDR, true), (int)SC_PHY_MANUAL_UPDATE_OFFSET, (int)SC_PHY_MANUAL_UPDATE_OFFSET), true);

}

void RestoreRdRDQS_DQ_RiseFallDelay(UInt32 sliceNo)
{
	UInt32 index = 0;
	UInt32 startAddress = (UInt32)PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_ADDR + (sliceNo * (UInt32)HS_SLICE_REG_COUNT);

	jtag_dll_mc_reg_write(startAddress, WriteBitsToValue(InitRdRDQS_DQ_RiseFallDelay[index, 0], jtag_dll_mc_reg_read(startAddress, true), (int)(PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_OFFSET + (PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_WIDTH - 1)), (int)PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_OFFSET), true);
		
	for (index = 1; index < 9; index++)
	{
		UInt32 riseFallDelay = (InitRdRDQS_DQ_RiseFallDelay[index, 0] << 16) | InitRdRDQS_DQ_RiseFallDelay[(index - 1), 1];
		jtag_dll_mc_reg_write(startAddress + index, riseFallDelay, true);
	}

	jtag_dll_mc_reg_write(startAddress + index, WriteBitsToValue(InitRdRDQS_DQ_RiseFallDelay[(index - 1), 1], jtag_dll_mc_reg_read(startAddress + index, true), (int)(PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_OFFSET + (PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_WIDTH - 1)), (int)PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_OFFSET), true);
	
	jtag_dll_mc_reg_write(SC_PHY_MANUAL_UPDATE_ADDR, WriteBitsToValue(1, jtag_dll_mc_reg_read(SC_PHY_MANUAL_UPDATE_ADDR, true), (int)SC_PHY_MANUAL_UPDATE_OFFSET, (int)SC_PHY_MANUAL_UPDATE_OFFSET), true);

}

int PHY_PAD_VREF_SEL_WIDTH = 7;

void SetPhyVrefLevel(uint vrefLevel,UInt32 sliceNo = 0)
{
	ulong regValue = 0;

	UInt32 vrefRegAddr = (UInt32)(PHY_PAD_VREF_CTRL_DQ_0_ADDR + ((UInt32)HS_SLICE_REG_COUNT * sliceNo));
	regValue = jtag_dll_mc_reg_read(vrefRegAddr, true);
	regValue = WriteBitsToValue(vrefLevel, regValue, ((PHY_PAD_VREF_SEL_WIDTH -  1) + (int)PHY_PAD_VREF_CTRL_DQ_0_OFFSET), (int)PHY_PAD_VREF_CTRL_DQ_0_OFFSET);
	jtag_dll_mc_reg_write(vrefRegAddr, regValue, true);
	
}

UInt32 GetPhyVrefLevel(UInt32 sliceNo)
{
	UInt32 vrefLevel = 0;
	if (sliceNo < 4)
	{
		UInt32 vrefRegAddr = (UInt32)(PHY_PAD_VREF_CTRL_DQ_0_ADDR + ((UInt32)HS_SLICE_REG_COUNT * sliceNo));
		ulong regValue = jtag_dll_mc_reg_read(vrefRegAddr, true);
		vrefLevel = (UInt32)GetBitsFromValue(regValue, ((PHY_PAD_VREF_SEL_WIDTH -  1) + (int)PHY_PAD_VREF_CTRL_DQ_0_OFFSET), (0 + (int)PHY_PAD_VREF_CTRL_DQ_0_OFFSET));
	}
	return vrefLevel;
}

/*
bool ConfigureBISTMaskRise(UInt32 sliceNo, UInt32 bitNo)
{
	UInt32 dqSwizzle;
	UInt32 maskBitNo = 0;
	UInt32 maskInv = 0;
	
	if (bitNo != 8)
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);
	else
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR+1) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);
	
	if (sliceNo < 4)
	{
		maskBitNo = (UInt32)((dqSwizzle & (0xF << (int)(4 * bitNo))) >> ((int)(4 * bitNo)) & 0xF);
		if (maskBitNo == 8)
		{
			print_message("Find Margin not supported for DM bit\n");
			return false;
		}
	
		maskInv = (UInt32)(1 << (Int32)(maskBitNo + (sliceNo * 8)));
		gBistDataMsk0 = ~maskInv;
		gBistDataMsk1 = 0xFFFFFFFF;
		gBistDataMsk2 = 0xFFFFFFFF;
		gBistDataMsk3 = 0xFFFFFFFF;	
	}
	else if (sliceNo < 8)
	{
		sliceNo = sliceNo - 4 ;
		maskBitNo = (UInt32)((dqSwizzle & (0xF << (int)(4 * bitNo))) >> ((int)(4 * bitNo)) & 0xF);
		if (maskBitNo == 8)
		{
			print_message("Find Margin not supported for DM bit\n");
			return false;
		}
		
		maskInv = (UInt32)(1 << (Int32)(maskBitNo + (sliceNo * 8)));
		gBistDataMsk0 = 0xFFFFFFFF;
		gBistDataMsk1 = ~maskInv;
		gBistDataMsk2 = 0xFFFFFFFF;
		gBistDataMsk3 = 0xFFFFFFFF;	
	}			
	else
	{
		print_message("Find margin not supported for ECC slice \n");
	}
	return true;	
}

bool ConfigureBISTMaskFall(UInt32 sliceNo, UInt32 bitNo)
{
	UInt32 dqSwizzle;
	UInt32 maskBitNo = 0;
	UInt32 maskInv = 0;
	
	if (bitNo != 8)
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);
	else
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR+1) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);
	
	if (sliceNo < 4)
	{
		maskBitNo = (UInt32)((dqSwizzle & (0xF << (int)(4 * bitNo))) >> ((int)(4 * bitNo)) & 0xF);
		if (maskBitNo == 8)
		{
			print_message("Find Margin not supported for DM bit\n");
			return false;
		}
		
		maskInv = (UInt32)(1 << (Int32)(maskBitNo + (sliceNo * 8)));
		gBistDataMsk0 = 0xFFFFFFFF;
		gBistDataMsk1 = 0xFFFFFFFF;		
		gBistDataMsk2 = ~maskInv;
		gBistDataMsk3 = 0xFFFFFFFF;	
	}
	else if (sliceNo < 8)
	{
		sliceNo = sliceNo - 4 ;
		maskBitNo = (UInt32)((dqSwizzle & (0xF << (int)(4 * bitNo))) >> ((int)(4 * bitNo)) & 0xF);
		if (maskBitNo == 8)
		{
			print_message("Find Margin not supported for DM bit\n");
			return false;
		}
		
		maskInv = (UInt32)(1 << (Int32)(maskBitNo + (sliceNo * 8)));
		gBistDataMsk0 = 0xFFFFFFFF;
		gBistDataMsk1 = 0xFFFFFFFF;		
		gBistDataMsk2 = 0xFFFFFFFF;
		gBistDataMsk3 = ~maskInv;
	}	
	else
	{
		print_message("Find margin not supported for ECC slice \n");
	}	
	return true;	
}
*/


bool ConfigureBISTMaskRise(UInt32 sliceNo, UInt32 bitNo)
{
	UInt32 dqSwizzle;
	
	if (bitNo != 8)
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);
	else
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR+1) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);

	UInt32 maskBitNo = (UInt32)((dqSwizzle & (0xF << (int)(4 * bitNo))) >> ((int)(4 * bitNo)) & 0xF);
	print_message("bitNo = 0x" + bitNo.ToString("X") + "  Swizzled bit = 0x" + maskBitNo.ToString("X") + "\n");
		
	if (maskBitNo == 8)
	{
		print_message("Find Margin not supported for DM bit\n");
		return false;
	}
	
	UInt32 maskInv = (UInt32)(1 << (Int32)(maskBitNo + (sliceNo * 8)));
	gBistDataMsk0 = ~maskInv;
	gBistDataMsk1 = 0xFFFFFFFF;
//	print_message("Rise: gBistDataMsk0 = 0x" + gBistDataMsk0.ToString("X") + "\n");
	return true;
}

bool ConfigureBISTMaskFall(UInt32 sliceNo, UInt32 bitNo)
{
	UInt32 dqSwizzle;
	
	if (bitNo != 8)
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);
	else
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR+1) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);

	UInt32 maskBitNo = (UInt32)((dqSwizzle & (0xF << (int)(4 * bitNo))) >> ((int)(4 * bitNo)) & 0xF);
	print_message("bitNo = 0x" + bitNo.ToString("X") + "  Swizzled bit = 0x" + maskBitNo.ToString("X") + "\n");
	
	if (maskBitNo == 8)
	{
		print_message("Find Margin not supported for DM bit\n");
		return false;
	}
	
	UInt32 maskInv = (UInt32)(1 << (Int32)(maskBitNo + (sliceNo * 8)));
	gBistDataMsk0 = 0xFFFFFFFF;
	gBistDataMsk1 = ~maskInv;
//	print_message("Fall: gBistDataMsk0 = 0x" + gBistDataMsk0.ToString("X") + "\n");
	return true;
}

void ConfigureBISTMaskSlice(UInt32 sliceNo)
{
	UInt32 maskInv = (UInt32)(0xFF << (Int32)(sliceNo * 8));
	gBistDataMsk0 = ~maskInv;
	gBistDataMsk1 = ~maskInv;
}
		
Margin FindPhyVrefMargin(int vrefValueInit, int vrefValueMin, int vrefValueMax)
{
	int vrefValueCurrent = vrefValueInit;
	int vrefValueLow = -1;
	int vrefValueHigh = -1;
	bool bistSuccess;
	Margin vrefMargin = new Margin(-1, -1);

	// check if BIST is passing
	bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1,  1, gBistAddrSpace, gCS_MAP);

	if (true == bistSuccess)
	{
		print_message("BIST passed with Initial setting\n");
	}
	else
	{
		print_message("BIST failed with initial setting \n");
		goto FindVrefMargin_EXIT;
	}

	// find low limit
	for (vrefValueCurrent = vrefValueInit; vrefValueCurrent > vrefValueMin; vrefValueCurrent -= (int)gVrefStep)
	{
		Application.DoEvents();
		if (exit_loop == 1) return vrefMargin;
		SetPhyVrefLevel((uint)vrefValueCurrent, (UInt32)gSliceNumber);

		bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);

		if (false == bistSuccess)
		{
			break;
		}
	}

	if (vrefValueCurrent <= 0)	vrefValueLow = 0;
	else vrefValueLow = vrefValueCurrent + (int)gVrefStep;

	print_message("vrefValueLow = 0x" + vrefValueLow.ToString("X") + "\n");
	SetPhyVrefLevel((uint)vrefValueInit, (UInt32)gSliceNumber);

	// find high limit
	for (vrefValueCurrent = vrefValueInit; vrefValueCurrent < vrefValueMax; vrefValueCurrent += (int)gVrefStep)
	{
		Application.DoEvents();
		if (exit_loop == 1) return vrefMargin;
		SetPhyVrefLevel((uint)vrefValueCurrent, (UInt32)gSliceNumber);

		bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);

		if (false == bistSuccess)
		{
			break;
		}
	}

	if (vrefValueCurrent >= vrefValueMax) vrefValueHigh = vrefValueMax;
	else vrefValueHigh = vrefValueCurrent - (int)gVrefStep;

	print_message("vrefValueHigh = 0x" + vrefValueHigh.ToString("X") + "\n");

FindVrefMargin_EXIT:
	vrefMargin = new Margin(vrefValueLow, vrefValueHigh);
	return vrefMargin;
}


Margin FindRdDqMargin(UInt32 minDelay, UInt32 maxDelay, UInt32 initDelay, int vrefLv, Margin lastMargin)
{
	Margin rdDqMargin = new Margin(-1, -1);
	bool foundLow = false;
	bool foundHigh = false;
	bool bistSuccess = false;

	// check if BIST is passing
	bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);

	if (!bistSuccess) goto FindRdDqMargin_EXIT;

	// find low margin
	Int32 delay = (Int32)initDelay;

	while (delay >= minDelay)
	{
		Application.DoEvents();
		if (exit_loop == 1) return rdDqMargin;
		SetRdRDQS_DQ_RiseFallDelay(gSliceNumber, (UInt32)delay);

		bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);

		if (true == bistSuccess)
		{
			if (delay == minDelay) { foundLow = true; break; }
			else
			{
				delay -= 0x8;
				if (delay < minDelay) delay = (Int32)minDelay;
				continue;
			}
		}
		else
		{
			while ((!bistSuccess) && (delay < initDelay))
			{
				Application.DoEvents();
				if (exit_loop == 1) return rdDqMargin;
				SetRdRDQS_DQ_RiseFallDelay(gSliceNumber, (UInt32)(++delay));
				bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);
			}
			foundLow = bistSuccess;
			break;
		}
	}
	if (foundLow) rdDqMargin.Low = delay;

	// find high margin
	delay = (Int32)initDelay;

	while (delay <= maxDelay)
	{
		Application.DoEvents();
		if (exit_loop == 1) return rdDqMargin;
		SetRdRDQS_DQ_RiseFallDelay(gSliceNumber, (UInt32)delay);
		bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);

		if (true == bistSuccess)
		{
			if (delay == maxDelay) { foundHigh = true; break; }
			else
			{
				delay += 0x8;
				if (delay > maxDelay) delay = (Int32)maxDelay;
				continue;
			}
		}
		else
		{
			while ((!bistSuccess) && (delay > initDelay))
			{
				Application.DoEvents();
				if (exit_loop == 1) return rdDqMargin;
				SetRdRDQS_DQ_RiseFallDelay(gSliceNumber, (UInt32)(--delay));
				bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);
			}
			foundHigh = bistSuccess;
			break;
		}
	}

	if (foundHigh) rdDqMargin.High = delay;
	else if (delay == maxDelay) rdDqMargin.High = delay;

FindRdDqMargin_EXIT:
	return rdDqMargin;
}

public void FindRdDataValidWindow()
{
	int vrefValueMax = PHY_VREF_VALUE_MAX;
	int vrefValueMin = 0x0;
	int vrefValueInit = (int)GetPhyVrefLevel((UInt32)gSliceNumber);

	SaveRdRDQS_DQ_RiseFallDelay(gSliceNumber);
	
	UInt32 RdRDQS_DQ_RiseFallDelay = 0;
	
	if (gFallingEdge == 1)
		RdRDQS_DQ_RiseFallDelay = InitRdRDQS_DQ_RiseFallDelay[gBitNumber, 1];	// FALL
	else
		RdRDQS_DQ_RiseFallDelay = InitRdRDQS_DQ_RiseFallDelay[gBitNumber, 0];	// RISE

	print_message("Finding VREF Margin ..\n");
	Margin vrefMargin = FindPhyVrefMargin(vrefValueInit, vrefValueMin, vrefValueMax);
	if ((vrefMargin.Low >= vrefValueMin) && (vrefMargin.High >= vrefValueMin) &&
		(vrefMargin.Low <= vrefValueMax) && (vrefMargin.High <= vrefValueMax) && (vrefMargin.High - vrefMargin.Low) > 0)
	{
		Int32 vrefLevel = vrefMargin.Low;
		Int32 numVrefLevels = vrefMargin.High - vrefMargin.Low;
		Margin lastMargin = new Margin(-1, -1);

		print_message("SliceNo,bitNo, VrefLv,MinDelay,MaxDelay,MinDly(ps),MaxDly(ps)\n");
		for (vrefLevel = vrefMargin.High; vrefLevel >= vrefMargin.Low; vrefLevel -= (Int32)gVrefStep)
		{
			Application.DoEvents();
			if (exit_loop == 1) return ;
			SetPhyVrefLevel((UInt32)vrefLevel, (UInt32)gSliceNumber);
			RestoreRdRDQS_DQ_RiseFallDelay(gSliceNumber);
			Margin margin = FindRdDqMargin(0, 0x1FF, RdRDQS_DQ_RiseFallDelay, (int)GetPhyVrefLevel((UInt32)gSliceNumber), lastMargin);
			Double minDlyPs = (margin.Low >= 0) ? (Double)(margin.Low / 512.0) * (1000000.0 / gFreqMHz) : margin.Low;
			Double maxDlyPs = (margin.High >= 0) ? (Double)(margin.High / 512.0) * (1000000.0 / gFreqMHz) : margin.High;
			print_message( gSliceNumber.ToString() + "," + gBitNumber.ToString() + ","+ vrefLevel.ToString() + "," + 
							margin.Low.ToString() + "," + margin.High.ToString() + "," +
						 minDlyPs.ToString("F2") + "," + maxDlyPs.ToString("F2") + "\n");
			lastMargin = margin;
		}
	}
	RestoreRdRDQS_DQ_RiseFallDelay(gSliceNumber);
	SetPhyVrefLevel((UInt32)vrefValueInit, (UInt32)gSliceNumber);
}
////// END -- Code for Read_DQ Margin ///


////// START -- Code for Write_DQ Margin ///

Margin[,] gWrDQMargin = new Margin[8, 8];
UInt32[,] InitWrDQ_Delay = new UInt32[4, 9];

void SetDRAMVref(UInt32 vrefLevel, ulong Chip_select)
{	
	UInt32 vref_range_val ;
	
	if (vref_range2 == 0)
		vref_range_val = 0;
	else
		vref_range_val = 0x40;
	
	ulong mode_reg_data = (ulong)(vrefLevel + vref_range_val) ;
	if (Mode_Reg_Rd_Wr.MRW_write_c(Chip_select, 14, mode_reg_data) == false) print_message("MRW failed\n");
}

/*
public bool MRW_write_c(ulong chip_select, ulong mode_reg_num , ulong mode_reg_data)
{
	bool success = true;
	int time_out = 0;
	uint mrw_op_done = 0;
	uint mrw_op_status = 0;
	
	
	UInt32 write_mode_reg_value = 0;
	
	// MRData single
	jtag_dll_mc_reg_write(MRSINGLE_DATA_0_ADDR, WriteBitsToValue(mode_reg_data,jtag_dll_mc_reg_read(MRSINGLE_DATA_0_ADDR), (int)(MRSINGLE_DATA_0_OFFSET + (MRSINGLE_DATA_0_WIDTH - 1)),(int)MRSINGLE_DATA_0_OFFSET));
	jtag_dll_mc_reg_write(MRSINGLE_DATA_1_ADDR, WriteBitsToValue(mode_reg_data,jtag_dll_mc_reg_read(MRSINGLE_DATA_1_ADDR), (int)(MRSINGLE_DATA_1_OFFSET + (MRSINGLE_DATA_1_WIDTH - 1)),(int)MRSINGLE_DATA_1_OFFSET));

	write_mode_reg_value =	(UInt32)(((int)mode_reg_num << (int)(WRITE_MODEREG_OFFSET + MRW_REGNUM_END)) + 
							((int)chip_select << (int)(WRITE_MODEREG_OFFSET + MRW_CSNUM_END)) + 
							(0x1 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_SINGLE)) + 
							(0x0 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_UPDATEALL)) +
							(0x0 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_START)));
							
	jtag_dll_mc_reg_write(WRITE_MODEREG_ADDR, write_mode_reg_value);

	write_mode_reg_value =	(UInt32)(((int)mode_reg_num << (int)(WRITE_MODEREG_OFFSET + MRW_REGNUM_END)) + 
							((int)chip_select << (int)(WRITE_MODEREG_OFFSET + MRW_CSNUM_END)) + 
							(0x1 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_SINGLE)) + 
							(0x0 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_UPDATEALL)) +
							(0x1 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_START)));
							
	jtag_dll_mc_reg_write(WRITE_MODEREG_ADDR, write_mode_reg_value);	
	//print_message("write_mode_reg_value = 0x" + write_mode_reg_value.ToString("X") + "\n");
	
	// Wait for completion
	do
	{
		Application.DoEvents();
		Thread.Sleep(100);
		time_out = time_out + 1 ;
		if (time_out == 30)
		{
			success =  false;
			break;
		}
		mrw_op_done = (uint)GetBitsFromValue(jtag_dll_mc_reg_read(INT_STATUS_MODE_ADDR), (int)(INT_STATUS_MODE_OFFSET + INT_MODE_WRITE_MODEREG_DONE_BIT_INDEX), (int)(INT_STATUS_MODE_OFFSET + INT_MODE_WRITE_MODEREG_DONE_BIT_INDEX));  //WRITE_MODEREG_DONE_BIT
	}
	while(mrw_op_done == 0);

	if (mrw_op_done ==1) 
	{
		mrw_op_status = (uint)GetBitsFromValue(jtag_dll_mc_reg_read(MRW_STATUS_ADDR), (int)((MRW_STATUS_WIDTH-1)+ MRW_STATUS_OFFSET), (int)MRW_STATUS_OFFSET);	// Check the error status
		if (mrw_op_status !=0) print_message("ERROR: MRW Operation Completed with error \n");
	    jtag_dll_mc_reg_write(INT_ACK_MODE_ADDR, WriteBitsToValue(0x1,jtag_dll_mc_reg_read(INT_ACK_MODE_ADDR), (int)(INT_ACK_MODE_OFFSET + INT_MODE_WRITE_MODEREG_DONE_BIT_INDEX), (int)(INT_ACK_MODE_OFFSET + INT_MODE_WRITE_MODEREG_DONE_BIT_INDEX))); // Ack mode register done bit	
	}
	else
	{
		print_message("ERROR: MRW Operation Failed \n");
		success =  false;
	}

	return success;
}
*/

void SaveWrDQ_Delay(UInt32 sliceNo)
{
	UInt32 index = 0;
	UInt32 startAddress = (UInt32)PHY_CLK_WRDQ0_SLAVE_DELAY_0_ADDR + (sliceNo * (UInt32)HS_SLICE_REG_COUNT);
	for (index = 0; index < 9; index++)
	{
		int bitOffset = ((index & 0x1) == 0x1) ? 16 : 0;
		InitWrDQ_Delay[sliceNo, index] = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(startAddress + (index >> 1), true), bitOffset + 10, bitOffset);
	}
}

void SetWrDQ_Delay(UInt32 sliceNo, UInt32 delay)
{
	UInt32 index = 0;
	UInt32 startAddress = (UInt32)PHY_CLK_WRDQ0_SLAVE_DELAY_0_ADDR + (sliceNo * (UInt32)HS_SLICE_REG_COUNT);
	ulong regValue;
	for (index = 0; index < 4; index++)
	{
		jtag_dll_mc_reg_write(startAddress + index, (delay << 16) | delay, true);
	}
	regValue = WriteBitsToValue(delay, jtag_dll_mc_reg_read(startAddress + 4, true), 10, 0);
	jtag_dll_mc_reg_write(startAddress + 4, regValue, true);

	jtag_dll_mc_reg_write(SC_PHY_MANUAL_UPDATE_ADDR, WriteBitsToValue(1, jtag_dll_mc_reg_read(SC_PHY_MANUAL_UPDATE_ADDR, true), (int)SC_PHY_MANUAL_UPDATE_OFFSET, (int)SC_PHY_MANUAL_UPDATE_OFFSET), true);

}

void RestoreWrDQ_Delay(UInt32 sliceNo)
{
	UInt32 index = 0;
	UInt32 startAddress = (UInt32)PHY_CLK_WRDQ0_SLAVE_DELAY_0_ADDR + (sliceNo * (UInt32)HS_SLICE_REG_COUNT);
	for (index = 0; index < 9; index++)
	{
		int bitOffset = ((index & 0x1) == 0x1) ? 16 : 0;
		ulong regValue = WriteBitsToValue(InitWrDQ_Delay[sliceNo, index], jtag_dll_mc_reg_read(startAddress + (index >> 1), true), bitOffset + 10, bitOffset);
		jtag_dll_mc_reg_write(startAddress + (index >> 1), regValue, true);
	}
	jtag_dll_mc_reg_write(SC_PHY_MANUAL_UPDATE_ADDR, WriteBitsToValue(1, jtag_dll_mc_reg_read(SC_PHY_MANUAL_UPDATE_ADDR, true), (int)SC_PHY_MANUAL_UPDATE_OFFSET, (int)SC_PHY_MANUAL_UPDATE_OFFSET), true);
}
/*
bool ConfigureBISTMaskWrite(UInt32 sliceNo, UInt32 bitNo)
{
	UInt32 dqSwizzle;
	UInt32 maskBitNo = 0;
	UInt32 maskInv = 0;
	
	if (bitNo != 8)
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);
	else
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR+1) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);

	if (sliceNo < 4)
	{
		maskBitNo = (UInt32)((dqSwizzle & (0xF << (int)(4 * bitNo))) >> ((int)(4 * bitNo)) & 0xF);
		if (maskBitNo == 8)
		{
			print_message("Find Margin not supported for DM bit\n");
			return false;
		}
	
		maskInv = (UInt32)(1 << (Int32)(maskBitNo + (sliceNo * 8)));
		gBistDataMsk0 = ~maskInv;
		gBistDataMsk1 = 0xFFFFFFFF;
		gBistDataMsk2 = ~maskInv;
		gBistDataMsk3 = 0xFFFFFFFF;
	}
	else if (sliceNo < 8)
	{
		sliceNo = sliceNo - 4 ;
		maskBitNo = (UInt32)((dqSwizzle & (0xF << (int)(4 * bitNo))) >> ((int)(4 * bitNo)) & 0xF);
		if (maskBitNo == 8)
		{
			print_message("Find Margin not supported for DM bit\n");
			return false;
		}
		
		maskInv = (UInt32)(1 << (Int32)(maskBitNo + (sliceNo * 8)));
		gBistDataMsk0 = 0xFFFFFFFF;
		gBistDataMsk1 = ~maskInv;
		gBistDataMsk2 = 0xFFFFFFFF;
		gBistDataMsk3 = ~maskInv;
	}	
	else
	{
		print_message("Find margin not supported for ECC slice \n");
	}		
	return true;
}
*/

bool ConfigureBISTMaskWrite(UInt32 sliceNo, UInt32 bitNo)
{
	UInt32 dqSwizzle;
	
	if (bitNo != 8)
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);
	else
		dqSwizzle = (UInt32)jtag_dll_mc_reg_read((UInt32)(PHY_DQ_DM_SWIZZLE0_0_ADDR+1) + ((UInt32)HS_SLICE_REG_COUNT * sliceNo), true);

	
	UInt32 maskBitNo = (UInt32)((dqSwizzle & (0xF << (int)(4 * bitNo))) >> ((int)(4 * bitNo)) & 0xF);
	print_message("bitNo = 0x" + bitNo.ToString("X") + "  Swizzled bit = 0x" + maskBitNo.ToString("X") + "\n");
	
	if (maskBitNo == 8)
	{
		print_message("Find Margin not supported for DM bit\n");
		return false;
	}
	
	UInt32 maskInv = (UInt32)(1 << (Int32)(maskBitNo + (sliceNo * 8)));
	gBistDataMsk0 = ~maskInv;
	gBistDataMsk1 = ~maskInv;
	return true;
}

Margin FindDRAMVrefMargin(int vrefValueInit, int vrefValueMin, int vrefValueMax)
{
	int vrefValueCurrent = vrefValueInit;
	int vrefValueLow = -1;
	int vrefValueHigh = -1;
	Margin vrefMargin = new Margin(-1, -1);
	// check if BIST is passing
	bool bistSuccess;

	bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1,  1, gBistAddrSpace, gCS_MAP);
	if (true == bistSuccess)
	{
		print_message("BIST passed with Initial setting\n");
	}
	else
	{
		print_message("BIST failed with initial setting \n");
		goto FindVrefMargin_EXIT;
	}

	// find low limit
	for (vrefValueCurrent = vrefValueInit; vrefValueCurrent > vrefValueMin; vrefValueCurrent -= (Int32)gVrefStep)
	{
		Application.DoEvents();
		if (exit_loop == 1) return vrefMargin;
		SetDRAMVref((uint)vrefValueCurrent, gChip_select);
		bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);
		if (show_debug_message == 1) print_message("vrefValueCurrent = 0x" + vrefValueCurrent.ToString("X") + "\n");
		if (false == bistSuccess)
		{
			break;
		}
	}

	if (vrefValueCurrent <= 0)
		vrefValueLow = 0;
	else
		vrefValueLow = vrefValueCurrent + (Int32)gVrefStep;

	print_message("vrefValueLow = 0x" + vrefValueLow.ToString("X") + "\n");
	SetDRAMVref((uint)vrefValueInit, gChip_select);
	
	// find high limit
	for (vrefValueCurrent = vrefValueInit; vrefValueCurrent < vrefValueMax; vrefValueCurrent += (Int32)gVrefStep)
	{
		Application.DoEvents();
		if (exit_loop == 1) return vrefMargin;
		SetDRAMVref((uint)vrefValueCurrent, gChip_select);
		bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);
		if (show_debug_message == 1) print_message("vrefValueCurrent = 0x" + vrefValueCurrent.ToString("X") + "\n");
		if (false == bistSuccess)
		{
			break;
		}
	}

	if (vrefValueCurrent >= vrefValueMax)
		vrefValueHigh = vrefValueMax;
	else
		vrefValueHigh = vrefValueCurrent - (Int32)gVrefStep;

	print_message("vrefValueHigh = 0x" + vrefValueHigh.ToString("X") + "\n");

FindVrefMargin_EXIT:
	vrefMargin = new Margin(vrefValueLow, vrefValueHigh);
	return vrefMargin;
}

Margin FindWrDqMargin(UInt32 minDelay, UInt32 maxDelay, UInt32 initDelay)
{
	Margin rdDqMargin = new Margin(-1, -1);
	bool foundLow = false;
	bool foundHigh = false;

	// check if BIST is passing
	bool bistSuccess;
	bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);

	if (!bistSuccess) goto FindWrDqMargin_EXIT;

	// find low margin
	Int32 delay = (Int32)initDelay;

	while (delay >= minDelay)
	{
		if (show_debug_message == 1) print_message("delay = 0x" + delay.ToString("X") + "\n");
		Application.DoEvents();
		if (exit_loop == 1) return rdDqMargin;
		SetWrDQ_Delay(gSliceNumber, (UInt32)delay);
		bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);
		
		if (true == bistSuccess)
		{
			if (delay == minDelay) { foundLow = true; break; }
			else
			{
				delay -= 0x8;
				if (delay < minDelay) delay = (Int32)minDelay;
				continue;
			}
		}
		else
		{
			while ((!bistSuccess) && (delay < initDelay))
			{
				Application.DoEvents();
				if (exit_loop == 1) return rdDqMargin;
				SetWrDQ_Delay(gSliceNumber, (UInt32)(++delay));
				bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);
			}
			foundLow = bistSuccess;
			break;
		}
	}

	if (foundLow) 
	{
		rdDqMargin.Low = delay;
		if (show_debug_message == 1) print_message("rdDqMargin.Low = 0x" + rdDqMargin.Low.ToString("X") + "\n");
	}

	// find high margin
	delay = (Int32)initDelay;

	while (delay <= maxDelay)
	{
		Application.DoEvents();
		if (show_debug_message == 1) print_message("delay = 0x" + delay.ToString("X") + "\n");
		if (exit_loop == 1) return rdDqMargin;
		SetWrDQ_Delay(gSliceNumber, (UInt32)delay);
		bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1,  1, gBistAddrSpace, gCS_MAP);

		if (true == bistSuccess)
		{
			if (delay == maxDelay) { foundHigh = true; break; }
			else
			{
				delay += 0x8;
				if (delay > maxDelay) delay = (Int32)maxDelay;
				continue;
			}
		}
		else
		{
			while ((!bistSuccess) && (delay > initDelay))
			{
				Application.DoEvents();
				if (exit_loop == 1) return rdDqMargin;
				SetWrDQ_Delay(gSliceNumber, (UInt32)(--delay));
				bistSuccess = BIST.pi_mbist(gBistStAddr, gBistDataMsk0, gBistDataMsk1, 1, gBistAddrSpace, gCS_MAP);
			}
			foundHigh = bistSuccess;
			break;
		}
	}

	if (foundHigh) 
	{
		rdDqMargin.High = delay;
		if (show_debug_message == 1) print_message("rdDqMargin.High = 0x" + rdDqMargin.High.ToString("X") + "\n");
	}
	else if (delay == maxDelay) rdDqMargin.High = delay;

FindWrDqMargin_EXIT:
	return rdDqMargin;
}

/*
UInt32 gRead_Data_0=0;
UInt32 gRead_Data_1=0;
UInt32 gRead_Data_2=0;
UInt32 gRead_Data_3=0;
UInt32 gRead_CS = 0;

// Mode Register Read
public bool MRR_read_c(ulong chip_select,ulong mode_reg_num)
{
	int time_out =0;
	bool success = true ;
	uint mrr_op_done =0;			
	uint mrr_err_bit = 0;		
	uint mrr_err_status = 0;
	
	UInt32 read_mode_reg_value = 0;
	
	read_mode_reg_value = (UInt32)(((int)chip_select << (int)(READ_MODEREG_OFFSET + MRR_CSNUM_END)) + 
						  ((int)mode_reg_num << (int)(READ_MODEREG_OFFSET + MRR_REGNUM_END)) + 
						  (1 << (int)(READ_MODEREG_OFFSET + (READ_MODEREG_WIDTH - 1))));
	
	jtag_dll_mc_reg_write(READ_MODEREG_ADDR, read_mode_reg_value);

	// Wait for MRR operation to complete
	do
	{
		Thread.Sleep(100);
		mrr_op_done = (UInt32)(GetBitsFromValue(jtag_dll_mc_reg_read(INT_STATUS_ADDR),(int)(INT_STATUS_OFFSET + PERIPHERAL_MRR_DONE_BIT),(int)(INT_STATUS_OFFSET + PERIPHERAL_MRR_DONE_BIT)));
		time_out =time_out +1;
		if (time_out==30)
		{
			success = false;
			break;
		}
    }while(mrr_op_done ==0) ;
	
	// Check the error status
	mrr_err_bit = (UInt32)(GetBitsFromValue(jtag_dll_mc_reg_read(INT_STATUS_ADDR),(int)(INT_STATUS_OFFSET + MRR_ERROR_BIT),(int)(INT_STATUS_OFFSET + MRR_ERROR_BIT)));
	if (mrr_err_bit == 1)
	{
		print_message("ERROR: MRR error bit is set \n");
		mrr_err_status = (uint)GetBitsFromValue(jtag_dll_mc_reg_read(MRR_ERROR_STATUS_ADDR), (int)((MRR_ERROR_STATUS_WIDTH -1) + MRR_ERROR_STATUS_OFFSET), (int)MRR_ERROR_STATUS_OFFSET);	
		success = false;
	}

	if (mrr_op_done == 1)
	{
		// ACK PERIPHERAL_MRR_DONE_BIT
		jtag_dll_mc_reg_write(INT_ACK_ADDR, WriteBitsToValue(0x1,jtag_dll_mc_reg_read(INT_ACK_ADDR), (int)(INT_ACK_OFFSET + PERIPHERAL_MRR_DONE_BIT),(int)(INT_ACK_OFFSET + PERIPHERAL_MRR_DONE_BIT)));
	}
	else
	{
		print_message("ERROR: MRR Operation Failed \n");	
		success = false;
	}
	
    gRead_Data_0   =      (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(PERIPHERAL_MRR_DATA_ADDR),7,0); 	// MRR data for device 0
	gRead_Data_1   =      (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(PERIPHERAL_MRR_DATA_ADDR),15,8); 	// MRR data for device 1
    gRead_Data_2   =      (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(PERIPHERAL_MRR_DATA_ADDR),23,16); 	// MRR data for device 2
	gRead_Data_3   =      (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(PERIPHERAL_MRR_DATA_ADDR),31,24); 	// MRR data for device 3

	gRead_CS       =      (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(PERIPHERAL_MRR_DATA_ADDR+1),7,0);			// MRR chip information
	
	return success;
}
*/

void FindWrDataValidWindow(UInt32 sliceNumber, UInt32 bitNumber)
{
	// Start from the current VREF setting
	int vrefValueMax = 0x32;
	int vrefValueMin = 0x0;
	
	Mode_Reg_Rd_Wr.MRR_read_c(gChip_select, 14);
	int vrefValueInit = (int)Mode_Reg_Rd_Wr.gRead_Data_0;//This should be mapped to correct device 
	
/*	MRR_read_c(gChip_select, 14);
	int vrefValueInit = 0;
	vrefValueInit = (int)gRead_Data_0;  // update if required. This should be mapped to correct device 
*/

//	int vrefValueInit = (int)gvrefValueInit;// Can read working value from DRAM too or supplied from GUI. The Initial DRAM VREF value should be a working value. 

	print_message("Initial VREF = 0x" + vrefValueInit.ToString("X") + "\n");
	SaveWrDQ_Delay(sliceNumber); 
	
	Margin vrefMargin = FindDRAMVrefMargin(vrefValueInit, vrefValueMin, vrefValueMax);
	print_message("vrefMargin.low = 0x" + vrefMargin.Low.ToString("X") + "\n");
	print_message("vrefMargin.High = 0x" + vrefMargin.High.ToString("X") + "\n");
	
	if ((vrefMargin.Low >= vrefValueMin) && (vrefMargin.High >= vrefValueMin) &&
		(vrefMargin.Low <= vrefValueMax) && (vrefMargin.High <= vrefValueMax) && (vrefMargin.High - vrefMargin.Low) > 0)
	{
		Int32 vrefLevel;

		print_message("SliceNo,bitNo, VrefLv,MinDelay,MaxDelay,MinDly(ps),MaxDly(ps)\n");

		for (vrefLevel = vrefMargin.High; vrefLevel >= vrefMargin.Low; vrefLevel-=(Int32)gVrefStep)
		{
			Application.DoEvents();
			if (exit_loop == 1) return;
			SetDRAMVref((UInt32)vrefLevel, gChip_select);
			RestoreWrDQ_Delay(sliceNumber);

			Margin margin = FindWrDqMargin(0, 0x7FF, InitWrDQ_Delay[sliceNumber, bitNumber]);
			Double minDlyPs = (margin.Low >= 0) ? (Double)(margin.Low / 512.0) * (1000000.0 / gFreqMHz) : margin.Low;
			Double maxDlyPs = (margin.High >= 0) ? (Double)(margin.High / 512.0) * (1000000.0 / gFreqMHz) : margin.High;
			print_message( sliceNumber.ToString() + "," + bitNumber.ToString() + ","+ vrefLevel.ToString() + "," + 
							margin.Low.ToString() + "," + margin.High.ToString() + "," +
						 minDlyPs.ToString("F2") + "," + maxDlyPs.ToString("F2") + "\n");

		}
	}
	RestoreWrDQ_Delay(sliceNumber);
	SetDRAMVref((UInt32)vrefValueInit, gChip_select);
}
////// END -- Code for Write_DQ Margin ///

void pat_num_write()
{
	jtag_dll_pi_reg_write(PI_BIST_PAT_NUM_ADDR,WriteBitsToValue(pi_pat_num,jtag_dll_pi_reg_read(PI_BIST_PAT_NUM_ADDR),(int)(PI_BIST_PAT_NUM_OFFSET+(PI_BIST_PAT_NUM_WIDTH-1)),(int)(PI_BIST_PAT_NUM_OFFSET)));
}

void pat_num_read()
{
	pi_pat_num     = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_PAT_NUM_ADDR),(int)(PI_BIST_PAT_NUM_OFFSET+(PI_BIST_PAT_NUM_WIDTH-1)),(int)(PI_BIST_PAT_NUM_OFFSET));
}