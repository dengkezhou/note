//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[4];

void SC_PHY_SNAP_OBS_REGS_0() {
    jtag_dll_mc_reg_write(15,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(15, true),8 + 1 -1,8) ,true);
    jtag_dll_mc_reg_write(271,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(271, true),8 + 1 -1,8) ,true);
    jtag_dll_mc_reg_write(527,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(527, true),8 + 1 -1,8) ,true);
    jtag_dll_mc_reg_write(783,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(783, true),8 + 1 -1,8) ,true);
}

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(28,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(284,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(540,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(796,true);
}
void Group_read() {

    SC_PHY_SNAP_OBS_REGS_0();
    read_fn();

    UInt32 temp_obs = 0;

    temp_reg[0] = (UInt32)WriteBitsToValue(0,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_0_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_0_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(1,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_1_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_1_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(2,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_2_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_2_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(3,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_3_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_3_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(4,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_4_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_4_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(5,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_5_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_5_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(6,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_6_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_6_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(0,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_0_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_0_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(1,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_1_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_1_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(2,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_2_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_2_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(3,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_3_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_3_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(4,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_4_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_4_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(5,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_5_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_5_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(6,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_6_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_6_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(0,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_0_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_0_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(1,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_1_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_1_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(2,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_2_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_2_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(3,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_3_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_3_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(4,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_4_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_4_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(5,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_5_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_5_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(6,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_6_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_6_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(0,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_0_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_0_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(1,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_1_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_1_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(2,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_2_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_2_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(3,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_3_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_3_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(4,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_4_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_4_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(5,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_5_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_5_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(6,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_6_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_6_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(7,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_7_master_dly_lock_bypass_obs_0 = (UInt32)GetBitsFromValue(temp_obs, 25 + -9, 25);
    PHY_7_master_dly_lock_half_clock_mode_obs_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + -8, 24);
    PHY_7_master_dly_lock_cal_dly_enc_obs_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 5, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(7,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_7_master_dly_lock_bypass_obs_1 = (UInt32)GetBitsFromValue(temp_obs, 25 + -9, 25);
    PHY_7_master_dly_lock_half_clock_mode_obs_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + -8, 24);
    PHY_7_master_dly_lock_cal_dly_enc_obs_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 5, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(7,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_7_master_dly_lock_bypass_obs_2 = (UInt32)GetBitsFromValue(temp_obs, 25 + -9, 25);
    PHY_7_master_dly_lock_half_clock_mode_obs_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + -8, 24);
    PHY_7_master_dly_lock_cal_dly_enc_obs_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 5, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(7,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_7_master_dly_lock_bypass_obs_3 = (UInt32)GetBitsFromValue(temp_obs, 25 + -9, 25);
    PHY_7_master_dly_lock_half_clock_mode_obs_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + -8, 24);
    PHY_7_master_dly_lock_cal_dly_enc_obs_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 5, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(8,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_8_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_8_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(9,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_9_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_9_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(10,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_10_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_10_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(11,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_11_full_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_11_cust_delay_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(8,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_8_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_8_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(9,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_9_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_9_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(10,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_10_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_10_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(11,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_11_full_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_11_cust_delay_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(8,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_8_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_8_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(9,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_9_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_9_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(10,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_10_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_10_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(11,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_11_full_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_11_cust_delay_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(8,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_8_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_8_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(9,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_9_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_9_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(10,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_10_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_10_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(11,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_11_full_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 19 + 7, 19);
    PHY_11_cust_delay_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 2, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(12,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_12_mstr_dly_init_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 4, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(12,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_12_mstr_dly_init_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 4, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(12,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_12_mstr_dly_init_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 4, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(12,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_12_mstr_dly_init_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 4, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(13,temp_reg[0],16 + 4 -1,16);
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(47,true);
    PHY_13_cal_clk_sm_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 1, 16);
    PHY_13_mstr_lock_sm_0 = (UInt32)GetBitsFromValue(temp_obs, 18 + 3, 18);

    temp_reg[1] = (UInt32)WriteBitsToValue(13,temp_reg[1],16 + 4 -1,16);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(303,true);
    PHY_13_cal_clk_sm_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 1, 16);
    PHY_13_mstr_lock_sm_1 = (UInt32)GetBitsFromValue(temp_obs, 18 + 3, 18);

    temp_reg[2] = (UInt32)WriteBitsToValue(13,temp_reg[2],16 + 4 -1,16);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(559,true);
    PHY_13_cal_clk_sm_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 1, 16);
    PHY_13_mstr_lock_sm_2 = (UInt32)GetBitsFromValue(temp_obs, 18 + 3, 18);

    temp_reg[3] = (UInt32)WriteBitsToValue(13,temp_reg[3],16 + 4 -1,16);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(815,true);
    PHY_13_cal_clk_sm_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 1, 16);
    PHY_13_mstr_lock_sm_3 = (UInt32)GetBitsFromValue(temp_obs, 18 + 3, 18);

}
void Group_write() {
    jtag_dll_mc_reg_write(28, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(284, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(540, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(796, temp_reg[3] ,true);
}
