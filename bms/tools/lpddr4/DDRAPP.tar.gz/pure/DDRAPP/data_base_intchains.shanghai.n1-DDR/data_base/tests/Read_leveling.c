//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[8];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(32,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(288,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(544,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(800,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(59,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(315,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(571,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(827,true);
}
void Group_read() {
    read_fn();

    UInt32 temp_obs = 0;

    temp_reg[0] = (UInt32)WriteBitsToValue(0,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_0_rise_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(1,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_1_rise_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(2,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_2_rise_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(3,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_3_rise_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(4,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_4_rise_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(5,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_5_rise_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(6,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_6_rise_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(7,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_7_rise_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(0,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_0_rise_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(1,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_1_rise_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(2,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_2_rise_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(3,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_3_rise_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(4,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_4_rise_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(5,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_5_rise_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(6,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_6_rise_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(7,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_7_rise_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(0,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_0_rise_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(1,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_1_rise_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(2,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_2_rise_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(3,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_3_rise_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(4,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_4_rise_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(5,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_5_rise_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(6,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_6_rise_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(7,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_7_rise_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(0,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_0_rise_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(1,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_1_rise_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(2,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_2_rise_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(3,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_3_rise_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(4,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_4_rise_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(5,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_5_rise_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(6,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_6_rise_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(7,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_7_rise_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(8,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_8_fall_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(9,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_9_fall_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(10,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_10_fall_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(11,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_11_fall_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(12,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_12_fall_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(13,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_13_fall_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(14,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_14_fall_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(15,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_15_fall_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(8,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_8_fall_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(9,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_9_fall_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(10,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_10_fall_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(11,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_11_fall_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(12,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_12_fall_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(13,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_13_fall_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(14,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_14_fall_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(15,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_15_fall_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(8,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_8_fall_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(9,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_9_fall_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(10,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_10_fall_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(11,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_11_fall_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(12,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_12_fall_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(13,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_13_fall_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(14,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_14_fall_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(15,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_15_fall_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(8,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_8_fall_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(9,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_9_fall_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(10,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_10_fall_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(11,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_11_fall_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(12,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_12_fall_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(13,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_13_fall_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(14,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_14_fall_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(15,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_15_fall_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(16,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_16_dm_rise_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(16,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_16_dm_rise_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(16,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_16_dm_rise_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(16,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_16_dm_rise_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(24,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_24_dm_fall_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(24,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_24_dm_fall_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(24,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_24_dm_fall_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(24,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_24_dm_fall_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 9, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(0,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_0_rise_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(1,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_1_rise_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(2,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_2_rise_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(3,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_3_rise_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(4,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_4_rise_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(5,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_5_rise_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(6,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_6_rise_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(7,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_7_rise_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(0,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_0_rise_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(1,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_1_rise_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(2,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_2_rise_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(3,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_3_rise_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(4,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_4_rise_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(5,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_5_rise_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(6,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_6_rise_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(7,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_7_rise_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(0,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_0_rise_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(1,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_1_rise_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(2,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_2_rise_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(3,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_3_rise_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(4,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_4_rise_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(5,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_5_rise_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(6,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_6_rise_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(7,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_7_rise_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(0,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_0_rise_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(1,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_1_rise_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(2,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_2_rise_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(3,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_3_rise_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(4,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_4_rise_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(5,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_5_rise_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(6,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_6_rise_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(7,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_7_rise_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(8,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_8_fall_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(9,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_9_fall_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(10,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_10_fall_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(11,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_11_fall_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(12,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_12_fall_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(13,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_13_fall_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(14,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_14_fall_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(15,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_15_fall_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(8,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_8_fall_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(9,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_9_fall_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(10,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_10_fall_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(11,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_11_fall_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(12,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_12_fall_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(13,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_13_fall_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(14,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_14_fall_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(15,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_15_fall_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(8,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_8_fall_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(9,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_9_fall_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(10,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_10_fall_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(11,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_11_fall_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(12,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_12_fall_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(13,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_13_fall_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(14,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_14_fall_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(15,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_15_fall_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(8,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_8_fall_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(9,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_9_fall_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(10,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_10_fall_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(11,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_11_fall_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(12,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_12_fall_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(13,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_13_fall_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(14,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_14_fall_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(15,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_15_fall_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(16,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_16_dm_rise_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(16,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_16_dm_rise_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(16,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_16_dm_rise_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(16,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_16_dm_rise_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(24,temp_reg[0],24 + 5 -1,24);
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(57,true);
    PHY_24_dm_fall_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(24,temp_reg[1],24 + 5 -1,24);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(313,true);
    PHY_24_dm_fall_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(24,temp_reg[2],24 + 5 -1,24);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(569,true);
    PHY_24_dm_fall_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(24,temp_reg[3],24 + 5 -1,24);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(825,true);
    PHY_24_dm_fall_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 9, 0);

    rdlvl_dq_le_found_0 = (UInt32)GetBitsFromValue(temp_reg[4],0+(8-1),0);
    rdlvl_dq_te_found_0 = (UInt32)GetBitsFromValue(temp_reg[4],8+(8-1),8);
    rdlvl_dq_fail_0 = (UInt32)GetBitsFromValue(temp_reg[4],16+(8-1),16);
    rdlvl_fall_edge_0 = (UInt32)GetBitsFromValue(temp_reg[4],24+(1-1),24);
    rdlvl_rise_edge_0 = (UInt32)GetBitsFromValue(temp_reg[4],25+(1-1),25);
    rdlvl_dq8_le_found_0 = (UInt32)GetBitsFromValue(temp_reg[4],26+(1-1),26);
    rdlvl_dq8_te_found_0 = (UInt32)GetBitsFromValue(temp_reg[4],27+(1-1),27);
    rdlvl_state_0 = (UInt32)GetBitsFromValue(temp_reg[4],28+(4-1),28);
    rdlvl_dq_le_found_1 = (UInt32)GetBitsFromValue(temp_reg[5],0+(8-1),0);
    rdlvl_dq_te_found_1 = (UInt32)GetBitsFromValue(temp_reg[5],8+(8-1),8);
    rdlvl_dq_fail_1 = (UInt32)GetBitsFromValue(temp_reg[5],16+(8-1),16);
    rdlvl_fall_edge_1 = (UInt32)GetBitsFromValue(temp_reg[5],24+(1-1),24);
    rdlvl_rise_edge_1 = (UInt32)GetBitsFromValue(temp_reg[5],25+(1-1),25);
    rdlvl_dq8_le_found_1 = (UInt32)GetBitsFromValue(temp_reg[5],26+(1-1),26);
    rdlvl_dq8_te_found_1 = (UInt32)GetBitsFromValue(temp_reg[5],27+(1-1),27);
    rdlvl_state_1 = (UInt32)GetBitsFromValue(temp_reg[5],28+(4-1),28);
    rdlvl_dq_le_found_2 = (UInt32)GetBitsFromValue(temp_reg[6],0+(8-1),0);
    rdlvl_dq_te_found_2 = (UInt32)GetBitsFromValue(temp_reg[6],8+(8-1),8);
    rdlvl_dq_fail_2 = (UInt32)GetBitsFromValue(temp_reg[6],16+(8-1),16);
    rdlvl_fall_edge_2 = (UInt32)GetBitsFromValue(temp_reg[6],24+(1-1),24);
    rdlvl_rise_edge_2 = (UInt32)GetBitsFromValue(temp_reg[6],25+(1-1),25);
    rdlvl_dq8_le_found_2 = (UInt32)GetBitsFromValue(temp_reg[6],26+(1-1),26);
    rdlvl_dq8_te_found_2 = (UInt32)GetBitsFromValue(temp_reg[6],27+(1-1),27);
    rdlvl_state_2 = (UInt32)GetBitsFromValue(temp_reg[6],28+(4-1),28);
    rdlvl_dq_le_found_3 = (UInt32)GetBitsFromValue(temp_reg[7],0+(8-1),0);
    rdlvl_dq_te_found_3 = (UInt32)GetBitsFromValue(temp_reg[7],8+(8-1),8);
    rdlvl_dq_fail_3 = (UInt32)GetBitsFromValue(temp_reg[7],16+(8-1),16);
    rdlvl_fall_edge_3 = (UInt32)GetBitsFromValue(temp_reg[7],24+(1-1),24);
    rdlvl_rise_edge_3 = (UInt32)GetBitsFromValue(temp_reg[7],25+(1-1),25);
    rdlvl_dq8_le_found_3 = (UInt32)GetBitsFromValue(temp_reg[7],26+(1-1),26);
    rdlvl_dq8_te_found_3 = (UInt32)GetBitsFromValue(temp_reg[7],27+(1-1),27);
    rdlvl_state_3 = (UInt32)GetBitsFromValue(temp_reg[7],28+(4-1),28);
}
void Group_write() {
    jtag_dll_mc_reg_write(32, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(288, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(544, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(800, temp_reg[3] ,true);
}
ulong regaddr;
UInt32 sample_count = 0;

void pi_int_status_read()
{
	LVL_DONE    =  (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR),(int)(PI_INT_STATUS_OFFSET + PI_LVL_DONE_BIT),(int)(PI_INT_STATUS_OFFSET + PI_LVL_DONE_BIT));
	RDLVL_REQ   =  (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR),(int)(PI_INT_STATUS_OFFSET + PI_RDLVL_REQ_BIT),(int)(PI_INT_STATUS_OFFSET + PI_RDLVL_REQ_BIT));
	RDLVL_ERROR =  (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR),(int)(PI_INT_STATUS_OFFSET + PI_RDLVL_ERROR_BIT),(int)(PI_INT_STATUS_OFFSET + PI_RDLVL_ERROR_BIT));
}

void pi_int_ack()
{
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_INT_ACK_ADDR),(int)(PI_INT_ACK_OFFSET + PI_LVL_DONE_BIT),(int)(PI_INT_ACK_OFFSET + PI_LVL_DONE_BIT))); // LVL_DONE
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_INT_ACK_ADDR),(int)(PI_INT_ACK_OFFSET + PI_RDLVL_REQ_BIT),(int)(PI_INT_ACK_OFFSET + PI_RDLVL_REQ_BIT))); // PI_RDLVL_REQ
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_INT_ACK_ADDR),(int)(PI_INT_ACK_OFFSET + PI_RDLVL_ERROR_BIT),(int)(PI_INT_ACK_OFFSET + PI_RDLVL_ERROR_BIT))); // PI_RDLVL_ERROR
}

void rdlvl_en_top()
{
	print_message ("PI-Initiated Read Leveling in progress \n");
	rdlvl_en();
	if (LVL_DONE== 1) print_message ("PI-Initiated Read Leveling Completed \n");
	else print_message ("PI-Initiated Read Leveling Failed \n");
	pi_int_ack();
}

public void rdlvl_en()
{
	jtag_dll_pi_reg_write(PI_RDLVL_EN_F0_ADDR,WriteBitsToValue(2,jtag_dll_pi_reg_read(PI_RDLVL_EN_F0_ADDR),(int)(PI_RDLVL_EN_F0_OFFSET + (PI_RDLVL_EN_F0_WIDTH -1)),(int)PI_RDLVL_EN_F0_OFFSET));
	jtag_dll_pi_reg_write(PI_RDLVL_EN_F1_ADDR,WriteBitsToValue(2,jtag_dll_pi_reg_read(PI_RDLVL_EN_F1_ADDR),(int)(PI_RDLVL_EN_F1_OFFSET + (PI_RDLVL_EN_F1_WIDTH -1)),(int)PI_RDLVL_EN_F1_OFFSET));
	jtag_dll_pi_reg_write(PI_RDLVL_EN_F2_ADDR,WriteBitsToValue(2,jtag_dll_pi_reg_read(PI_RDLVL_EN_F2_ADDR),(int)(PI_RDLVL_EN_F2_OFFSET + (PI_RDLVL_EN_F2_WIDTH -1)),(int)PI_RDLVL_EN_F2_OFFSET));

	jtag_dll_pi_reg_write(PI_RDLVL_CS_SW_ADDR,WriteBitsToValue(lvl_cs,jtag_dll_pi_reg_read(PI_RDLVL_CS_SW_ADDR),(int)(PI_RDLVL_CS_SW_OFFSET + (PI_RDLVL_CS_SW_WIDTH-1)),(int)PI_RDLVL_CS_SW_OFFSET));
	jtag_dll_pi_reg_write(PI_RDLVL_REQ_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_RDLVL_REQ_ADDR),(int)(PI_RDLVL_REQ_OFFSET + (PI_RDLVL_REQ_WIDTH-1)),(int)PI_RDLVL_REQ_OFFSET));

	Thread.Sleep(500);
	pi_int_status_read();
}

void start_debug()
{
	pi_int_ack();
	LVL_DONE=0;
	sample_count = 1;

	for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr=(PHY_LVL_DEBUG_MODE_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(1, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_LVL_DEBUG_MODE_0_OFFSET ), (int)PHY_LVL_DEBUG_MODE_0_OFFSET), true);
	}

	rdlvl_en();
	Thread.Sleep(200);
	print_message ("\n Running Read leveling in debug mode. \n Analysed result for sample_count = 1 \n");
}

void stop_debug()
{
	for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr=(PHY_LVL_DEBUG_MODE_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(0, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_LVL_DEBUG_MODE_0_OFFSET ), (int)PHY_LVL_DEBUG_MODE_0_OFFSET), true);
	}
	print_message("Debug mode Disabled \n");
}

void debug_cont()
{
	if (LVL_DONE == 0)
	{
		for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
		{
			regaddr=(SC_PHY_LVL_DEBUG_CONT_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
			jtag_dll_mc_reg_write(regaddr,WriteBitsToValue(1,jtag_dll_mc_reg_read(regaddr,true),(int)SC_PHY_LVL_DEBUG_CONT_0_OFFSET,(int)SC_PHY_LVL_DEBUG_CONT_0_OFFSET),true);
		}

	pi_int_status_read();
	sample_count = sample_count + 1;
	print_message("Analysed result for sample_count = " +sample_count.ToString() + "\n");
	}
	else
	{
		pi_int_ack();
		print_message("Read leveling Completed \n");
	}
}
