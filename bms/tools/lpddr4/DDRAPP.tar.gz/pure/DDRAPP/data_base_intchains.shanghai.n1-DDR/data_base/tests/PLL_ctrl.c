//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[10];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(1388,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(1318,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(1320,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(1323,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(1308,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(1310,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(1311,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(1387,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(1319,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(1326,true);
}
void Group_read() {
    read_fn();

    PHY_bypass_0 = (UInt32)GetBitsFromValue(temp_reg[0],0+(1-1),0);
    PHY_pd_0 = (UInt32)GetBitsFromValue(temp_reg[0],1+(1-1),1);
    PHY_testsel_0 = (UInt32)GetBitsFromValue(temp_reg[0],2+(1-1),2);
    PHY_testen_0 = (UInt32)GetBitsFromValue(temp_reg[0],3+(1-1),3);
    PHY_pdcal_0 = (UInt32)GetBitsFromValue(temp_reg[0],4+(1-1),4);
    PHY_fbdiv_0 = (UInt32)GetBitsFromValue(temp_reg[0],5+(2-1),5);
    PHY_refdiv_0 = (UInt32)GetBitsFromValue(temp_reg[0],7+(2-1),7);
    PHY_postdiv_0 = (UInt32)GetBitsFromValue(temp_reg[0],9+(3-1),9);
    PHY_vcosel_0 = (UInt32)GetBitsFromValue(temp_reg[0],12+(1-1),12);
    PHY_lp4_bypass_0 = (UInt32)GetBitsFromValue(temp_reg[1],0+(1-1),0);
    PHY_lp4_pd_0 = (UInt32)GetBitsFromValue(temp_reg[1],1+(1-1),1);
    PHY_lp4_testsel_0 = (UInt32)GetBitsFromValue(temp_reg[1],2+(1-1),2);
    PHY_lp4_testen_0 = (UInt32)GetBitsFromValue(temp_reg[1],3+(1-1),3);
    PHY_lp4_pdcal_0 = (UInt32)GetBitsFromValue(temp_reg[1],4+(1-1),4);
    PHY_lp4_fbdiv_0 = (UInt32)GetBitsFromValue(temp_reg[1],5+(2-1),5);
    PHY_lp4_refdiv_0 = (UInt32)GetBitsFromValue(temp_reg[1],7+(2-1),7);
    PHY_lp4_postdiv_0 = (UInt32)GetBitsFromValue(temp_reg[1],9+(3-1),9);
    PHY_lp4_vcosel_0 = (UInt32)GetBitsFromValue(temp_reg[1],12+(1-1),12);
    PHY_pll_lock_deassert_cnt_0 = (UInt32)GetBitsFromValue(temp_reg[2],3+(8-1),3);
    PHY_pll_lock_deassert_0 = (UInt32)GetBitsFromValue(temp_reg[2],2+(1-1),2);
    PHY_pll_ready_0 = (UInt32)GetBitsFromValue(temp_reg[2],1+(1-1),1);
    PHY_pll_lock_0 = (UInt32)GetBitsFromValue(temp_reg[2],0+(1-1),0);
    PHY_pll_lock_deassert_cnt_1 = (UInt32)GetBitsFromValue(temp_reg[3],3+(8-1),3);
    PHY_pll_lock_deassert_1 = (UInt32)GetBitsFromValue(temp_reg[3],2+(1-1),2);
    PHY_pll_ready_1 = (UInt32)GetBitsFromValue(temp_reg[3],1+(1-1),1);
    PHY_pll_lock_1 = (UInt32)GetBitsFromValue(temp_reg[3],0+(1-1),0);
    PHY_PLL_CTRL_OVERRIDE = (UInt32)GetBitsFromValue(temp_reg[1],16+(16-1),16);
    PHY_LP4_BOOT_PLL_BYPASS = (UInt32)GetBitsFromValue(temp_reg[4],16+(1-1),16);
    PHY_PLL_WAIT = (UInt32)GetBitsFromValue(temp_reg[5],0+(16-1),0);
    PHY_SW_PLL_BYPASS = (UInt32)GetBitsFromValue(temp_reg[6],0+(1-1),0);
    PHY_PLL_BYPASS = (UInt32)GetBitsFromValue(temp_reg[7],0+(1-1),0);
    PHY_LOW_FREQ_SEL = (UInt32)GetBitsFromValue(temp_reg[0],16+(1-1),16);
    PHY_USE_PLL_DSKEWCALLOCK = (UInt32)GetBitsFromValue(temp_reg[8],0+(1-1),0);
    PHY_PLL_TESTOUT_SEL = (UInt32)GetBitsFromValue(temp_reg[9],0+(1-1),0);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_bypass_0, temp_reg[0] ,0+(1-1),0);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_pd_0, temp_reg[0] ,1+(1-1),1);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_testsel_0, temp_reg[0] ,2+(1-1),2);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_testen_0, temp_reg[0] ,3+(1-1),3);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_pdcal_0, temp_reg[0] ,4+(1-1),4);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_fbdiv_0, temp_reg[0] ,5+(2-1),5);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_refdiv_0, temp_reg[0] ,7+(2-1),7);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_postdiv_0, temp_reg[0] ,9+(3-1),9);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_vcosel_0, temp_reg[0] ,12+(1-1),12);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_lp4_bypass_0, temp_reg[1] ,0+(1-1),0);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_lp4_pd_0, temp_reg[1] ,1+(1-1),1);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_lp4_testsel_0, temp_reg[1] ,2+(1-1),2);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_lp4_testen_0, temp_reg[1] ,3+(1-1),3);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_lp4_pdcal_0, temp_reg[1] ,4+(1-1),4);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_lp4_fbdiv_0, temp_reg[1] ,5+(2-1),5);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_lp4_refdiv_0, temp_reg[1] ,7+(2-1),7);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_lp4_postdiv_0, temp_reg[1] ,9+(3-1),9);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_lp4_vcosel_0, temp_reg[1] ,12+(1-1),12);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_PLL_CTRL_OVERRIDE, temp_reg[1] ,16+(16-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_LP4_BOOT_PLL_BYPASS, temp_reg[4] ,16+(1-1),16);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_PLL_WAIT, temp_reg[5] ,0+(16-1),0);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_SW_PLL_BYPASS, temp_reg[6] ,0+(1-1),0);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_PLL_BYPASS, temp_reg[7] ,0+(1-1),0);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_LOW_FREQ_SEL, temp_reg[0] ,16+(1-1),16);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_USE_PLL_DSKEWCALLOCK, temp_reg[8] ,0+(1-1),0);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_PLL_TESTOUT_SEL, temp_reg[9] ,0+(1-1),0);
    jtag_dll_mc_reg_write(1388, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(1318, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(1308, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(1310, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(1311, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(1387, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(1319, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(1326, temp_reg[9] ,true);
}
