//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
void UpdatePhyPerCSTrainingIdx(UInt32 csNum)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=(PHY_PER_CS_TRAINING_INDEX_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(csNum, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_PER_CS_TRAINING_INDEX_OFFSET + (PHY_PER_CS_TRAINING_INDEX_WIDTH-1)), (int)PHY_PER_CS_TRAINING_INDEX_OFFSET), true);
    }
}

void updateMulticast (UInt32 multicast_en)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=( PHY_PER_CS_TRAINING_MULTICAST_EN_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(multicast_en, jtag_dll_mc_reg_read(regaddr, true), (int)( PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET + (PHY_PER_CS_TRAINING_MULTICAST_EN_WIDTH -1)), (int) PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET), true);
    }
}
public UInt32[] temp_reg = new UInt32[60];

void SC_PHY_MANUAL_UPDATE() {
    jtag_dll_mc_reg_write(1287,(UInt32)WriteBitsToValue(0x1,jtag_dll_mc_reg_read(1287, true),0 + 1 -1,0) ,true);
}

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(120,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(121,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(122,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(123,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(124,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(125,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(126,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(127,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(128,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(376,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(377,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(378,true);
    temp_reg[12] = (UInt32)jtag_dll_mc_reg_read(379,true);
    temp_reg[13] = (UInt32)jtag_dll_mc_reg_read(380,true);
    temp_reg[14] = (UInt32)jtag_dll_mc_reg_read(381,true);
    temp_reg[15] = (UInt32)jtag_dll_mc_reg_read(382,true);
    temp_reg[16] = (UInt32)jtag_dll_mc_reg_read(383,true);
    temp_reg[17] = (UInt32)jtag_dll_mc_reg_read(384,true);
    temp_reg[18] = (UInt32)jtag_dll_mc_reg_read(632,true);
    temp_reg[19] = (UInt32)jtag_dll_mc_reg_read(633,true);
    temp_reg[20] = (UInt32)jtag_dll_mc_reg_read(634,true);
    temp_reg[21] = (UInt32)jtag_dll_mc_reg_read(635,true);
    temp_reg[22] = (UInt32)jtag_dll_mc_reg_read(636,true);
    temp_reg[23] = (UInt32)jtag_dll_mc_reg_read(637,true);
    temp_reg[24] = (UInt32)jtag_dll_mc_reg_read(638,true);
    temp_reg[25] = (UInt32)jtag_dll_mc_reg_read(639,true);
    temp_reg[26] = (UInt32)jtag_dll_mc_reg_read(640,true);
    temp_reg[27] = (UInt32)jtag_dll_mc_reg_read(888,true);
    temp_reg[28] = (UInt32)jtag_dll_mc_reg_read(889,true);
    temp_reg[29] = (UInt32)jtag_dll_mc_reg_read(890,true);
    temp_reg[30] = (UInt32)jtag_dll_mc_reg_read(891,true);
    temp_reg[31] = (UInt32)jtag_dll_mc_reg_read(892,true);
    temp_reg[32] = (UInt32)jtag_dll_mc_reg_read(893,true);
    temp_reg[33] = (UInt32)jtag_dll_mc_reg_read(894,true);
    temp_reg[34] = (UInt32)jtag_dll_mc_reg_read(895,true);
    temp_reg[35] = (UInt32)jtag_dll_mc_reg_read(896,true);
    temp_reg[36] = (UInt32)jtag_dll_mc_reg_read(129,true);
    temp_reg[37] = (UInt32)jtag_dll_mc_reg_read(385,true);
    temp_reg[38] = (UInt32)jtag_dll_mc_reg_read(641,true);
    temp_reg[39] = (UInt32)jtag_dll_mc_reg_read(897,true);
    temp_reg[40] = (UInt32)jtag_dll_mc_reg_read(89,true);
    temp_reg[41] = (UInt32)jtag_dll_mc_reg_read(90,true);
    temp_reg[42] = (UInt32)jtag_dll_mc_reg_read(91,true);
    temp_reg[43] = (UInt32)jtag_dll_mc_reg_read(92,true);
    temp_reg[44] = (UInt32)jtag_dll_mc_reg_read(93,true);
    temp_reg[45] = (UInt32)jtag_dll_mc_reg_read(345,true);
    temp_reg[46] = (UInt32)jtag_dll_mc_reg_read(346,true);
    temp_reg[47] = (UInt32)jtag_dll_mc_reg_read(347,true);
    temp_reg[48] = (UInt32)jtag_dll_mc_reg_read(348,true);
    temp_reg[49] = (UInt32)jtag_dll_mc_reg_read(349,true);
    temp_reg[50] = (UInt32)jtag_dll_mc_reg_read(601,true);
    temp_reg[51] = (UInt32)jtag_dll_mc_reg_read(602,true);
    temp_reg[52] = (UInt32)jtag_dll_mc_reg_read(603,true);
    temp_reg[53] = (UInt32)jtag_dll_mc_reg_read(604,true);
    temp_reg[54] = (UInt32)jtag_dll_mc_reg_read(605,true);
    temp_reg[55] = (UInt32)jtag_dll_mc_reg_read(857,true);
    temp_reg[56] = (UInt32)jtag_dll_mc_reg_read(858,true);
    temp_reg[57] = (UInt32)jtag_dll_mc_reg_read(859,true);
    temp_reg[58] = (UInt32)jtag_dll_mc_reg_read(860,true);
    temp_reg[59] = (UInt32)jtag_dll_mc_reg_read(861,true);
}
void Group_read() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    read_fn();

    PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[0],8+(10-1),8);
    PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[1],16+(10-1),16);
    PHY_RDDQS_DQ2_RISE_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[2],16+(10-1),16);
    PHY_RDDQS_DQ3_RISE_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[3],16+(10-1),16);
    PHY_RDDQS_DQ4_RISE_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[4],16+(10-1),16);
    PHY_RDDQS_DQ5_RISE_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[5],16+(10-1),16);
    PHY_RDDQS_DQ6_RISE_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[6],16+(10-1),16);
    PHY_RDDQS_DQ7_RISE_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[7],16+(10-1),16);
    PHY_RDDQS_DM_RISE_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[8],16+(10-1),16);
    PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[9],8+(10-1),8);
    PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[10],16+(10-1),16);
    PHY_RDDQS_DQ2_RISE_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[11],16+(10-1),16);
    PHY_RDDQS_DQ3_RISE_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[12],16+(10-1),16);
    PHY_RDDQS_DQ4_RISE_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[13],16+(10-1),16);
    PHY_RDDQS_DQ5_RISE_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[14],16+(10-1),16);
    PHY_RDDQS_DQ6_RISE_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[15],16+(10-1),16);
    PHY_RDDQS_DQ7_RISE_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[16],16+(10-1),16);
    PHY_RDDQS_DM_RISE_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[17],16+(10-1),16);
    PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[18],8+(10-1),8);
    PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[19],16+(10-1),16);
    PHY_RDDQS_DQ2_RISE_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[20],16+(10-1),16);
    PHY_RDDQS_DQ3_RISE_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[21],16+(10-1),16);
    PHY_RDDQS_DQ4_RISE_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[22],16+(10-1),16);
    PHY_RDDQS_DQ5_RISE_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[23],16+(10-1),16);
    PHY_RDDQS_DQ6_RISE_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[24],16+(10-1),16);
    PHY_RDDQS_DQ7_RISE_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[25],16+(10-1),16);
    PHY_RDDQS_DM_RISE_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[26],16+(10-1),16);
    PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[27],8+(10-1),8);
    PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[28],16+(10-1),16);
    PHY_RDDQS_DQ2_RISE_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[29],16+(10-1),16);
    PHY_RDDQS_DQ3_RISE_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[30],16+(10-1),16);
    PHY_RDDQS_DQ4_RISE_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[31],16+(10-1),16);
    PHY_RDDQS_DQ5_RISE_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[32],16+(10-1),16);
    PHY_RDDQS_DQ6_RISE_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[33],16+(10-1),16);
    PHY_RDDQS_DQ7_RISE_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[34],16+(10-1),16);
    PHY_RDDQS_DM_RISE_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[35],16+(10-1),16);
    PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[1],0+(10-1),0);
    PHY_RDDQS_DQ1_FALL_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[2],0+(10-1),0);
    PHY_RDDQS_DQ2_FALL_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[3],0+(10-1),0);
    PHY_RDDQS_DQ3_FALL_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[4],0+(10-1),0);
    PHY_RDDQS_DQ4_FALL_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[5],0+(10-1),0);
    PHY_RDDQS_DQ5_FALL_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[6],0+(10-1),0);
    PHY_RDDQS_DQ6_FALL_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[7],0+(10-1),0);
    PHY_RDDQS_DQ7_FALL_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[8],0+(10-1),0);
    PHY_RDDQS_DM_FALL_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[36],0+(10-1),0);
    PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[10],0+(10-1),0);
    PHY_RDDQS_DQ1_FALL_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[11],0+(10-1),0);
    PHY_RDDQS_DQ2_FALL_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[12],0+(10-1),0);
    PHY_RDDQS_DQ3_FALL_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[13],0+(10-1),0);
    PHY_RDDQS_DQ4_FALL_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[14],0+(10-1),0);
    PHY_RDDQS_DQ5_FALL_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[15],0+(10-1),0);
    PHY_RDDQS_DQ6_FALL_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[16],0+(10-1),0);
    PHY_RDDQS_DQ7_FALL_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[17],0+(10-1),0);
    PHY_RDDQS_DM_FALL_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[37],0+(10-1),0);
    PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[19],0+(10-1),0);
    PHY_RDDQS_DQ1_FALL_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[20],0+(10-1),0);
    PHY_RDDQS_DQ2_FALL_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[21],0+(10-1),0);
    PHY_RDDQS_DQ3_FALL_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[22],0+(10-1),0);
    PHY_RDDQS_DQ4_FALL_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[23],0+(10-1),0);
    PHY_RDDQS_DQ5_FALL_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[24],0+(10-1),0);
    PHY_RDDQS_DQ6_FALL_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[25],0+(10-1),0);
    PHY_RDDQS_DQ7_FALL_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[26],0+(10-1),0);
    PHY_RDDQS_DM_FALL_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[38],0+(10-1),0);
    PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[28],0+(10-1),0);
    PHY_RDDQS_DQ1_FALL_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[29],0+(10-1),0);
    PHY_RDDQS_DQ2_FALL_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[30],0+(10-1),0);
    PHY_RDDQS_DQ3_FALL_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[31],0+(10-1),0);
    PHY_RDDQS_DQ4_FALL_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[32],0+(10-1),0);
    PHY_RDDQS_DQ5_FALL_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[33],0+(10-1),0);
    PHY_RDDQS_DQ6_FALL_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[34],0+(10-1),0);
    PHY_RDDQS_DQ7_FALL_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[35],0+(10-1),0);
    PHY_RDDQS_DM_FALL_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[39],0+(10-1),0);
    PHY_RDDQ0_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[40],0+(10-1),0);
    PHY_RDDQ1_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[40],16+(10-1),16);
    PHY_RDDQ2_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[41],0+(10-1),0);
    PHY_RDDQ3_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[41],16+(10-1),16);
    PHY_RDDQ4_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[42],0+(10-1),0);
    PHY_RDDQ5_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[42],16+(10-1),16);
    PHY_RDDQ6_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[43],0+(10-1),0);
    PHY_RDDQ7_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[43],16+(10-1),16);
    PHY_RDDM_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[44],0+(10-1),0);
    PHY_RDDQ0_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[45],0+(10-1),0);
    PHY_RDDQ1_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[45],16+(10-1),16);
    PHY_RDDQ2_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[46],0+(10-1),0);
    PHY_RDDQ3_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[46],16+(10-1),16);
    PHY_RDDQ4_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[47],0+(10-1),0);
    PHY_RDDQ5_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[47],16+(10-1),16);
    PHY_RDDQ6_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[48],0+(10-1),0);
    PHY_RDDQ7_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[48],16+(10-1),16);
    PHY_RDDM_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[49],0+(10-1),0);
    PHY_RDDQ0_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[50],0+(10-1),0);
    PHY_RDDQ1_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[50],16+(10-1),16);
    PHY_RDDQ2_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[51],0+(10-1),0);
    PHY_RDDQ3_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[51],16+(10-1),16);
    PHY_RDDQ4_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[52],0+(10-1),0);
    PHY_RDDQ5_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[52],16+(10-1),16);
    PHY_RDDQ6_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[53],0+(10-1),0);
    PHY_RDDQ7_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[53],16+(10-1),16);
    PHY_RDDM_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[54],0+(10-1),0);
    PHY_RDDQ0_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[55],0+(10-1),0);
    PHY_RDDQ1_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[55],16+(10-1),16);
    PHY_RDDQ2_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[56],0+(10-1),0);
    PHY_RDDQ3_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[56],16+(10-1),16);
    PHY_RDDQ4_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[57],0+(10-1),0);
    PHY_RDDQ5_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[57],16+(10-1),16);
    PHY_RDDQ6_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[58],0+(10-1),0);
    PHY_RDDQ7_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[58],16+(10-1),16);
    PHY_RDDM_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[59],0+(10-1),0);

    updateMulticast(1);
}
void Group_write() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0, temp_reg[0] ,8+(10-1),8);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_0, temp_reg[1] ,16+(10-1),16);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ2_RISE_SLAVE_DELAY_0, temp_reg[2] ,16+(10-1),16);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ3_RISE_SLAVE_DELAY_0, temp_reg[3] ,16+(10-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ4_RISE_SLAVE_DELAY_0, temp_reg[4] ,16+(10-1),16);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ5_RISE_SLAVE_DELAY_0, temp_reg[5] ,16+(10-1),16);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ6_RISE_SLAVE_DELAY_0, temp_reg[6] ,16+(10-1),16);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ7_RISE_SLAVE_DELAY_0, temp_reg[7] ,16+(10-1),16);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_RDDQS_DM_RISE_SLAVE_DELAY_0, temp_reg[8] ,16+(10-1),16);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_1, temp_reg[9] ,8+(10-1),8);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_1, temp_reg[10] ,16+(10-1),16);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ2_RISE_SLAVE_DELAY_1, temp_reg[11] ,16+(10-1),16);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ3_RISE_SLAVE_DELAY_1, temp_reg[12] ,16+(10-1),16);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ4_RISE_SLAVE_DELAY_1, temp_reg[13] ,16+(10-1),16);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ5_RISE_SLAVE_DELAY_1, temp_reg[14] ,16+(10-1),16);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ6_RISE_SLAVE_DELAY_1, temp_reg[15] ,16+(10-1),16);
    temp_reg[16] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ7_RISE_SLAVE_DELAY_1, temp_reg[16] ,16+(10-1),16);
    temp_reg[17] = (UInt32)WriteBitsToValue(PHY_RDDQS_DM_RISE_SLAVE_DELAY_1, temp_reg[17] ,16+(10-1),16);
    temp_reg[18] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_2, temp_reg[18] ,8+(10-1),8);
    temp_reg[19] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_2, temp_reg[19] ,16+(10-1),16);
    temp_reg[20] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ2_RISE_SLAVE_DELAY_2, temp_reg[20] ,16+(10-1),16);
    temp_reg[21] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ3_RISE_SLAVE_DELAY_2, temp_reg[21] ,16+(10-1),16);
    temp_reg[22] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ4_RISE_SLAVE_DELAY_2, temp_reg[22] ,16+(10-1),16);
    temp_reg[23] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ5_RISE_SLAVE_DELAY_2, temp_reg[23] ,16+(10-1),16);
    temp_reg[24] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ6_RISE_SLAVE_DELAY_2, temp_reg[24] ,16+(10-1),16);
    temp_reg[25] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ7_RISE_SLAVE_DELAY_2, temp_reg[25] ,16+(10-1),16);
    temp_reg[26] = (UInt32)WriteBitsToValue(PHY_RDDQS_DM_RISE_SLAVE_DELAY_2, temp_reg[26] ,16+(10-1),16);
    temp_reg[27] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_3, temp_reg[27] ,8+(10-1),8);
    temp_reg[28] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ1_RISE_SLAVE_DELAY_3, temp_reg[28] ,16+(10-1),16);
    temp_reg[29] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ2_RISE_SLAVE_DELAY_3, temp_reg[29] ,16+(10-1),16);
    temp_reg[30] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ3_RISE_SLAVE_DELAY_3, temp_reg[30] ,16+(10-1),16);
    temp_reg[31] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ4_RISE_SLAVE_DELAY_3, temp_reg[31] ,16+(10-1),16);
    temp_reg[32] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ5_RISE_SLAVE_DELAY_3, temp_reg[32] ,16+(10-1),16);
    temp_reg[33] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ6_RISE_SLAVE_DELAY_3, temp_reg[33] ,16+(10-1),16);
    temp_reg[34] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ7_RISE_SLAVE_DELAY_3, temp_reg[34] ,16+(10-1),16);
    temp_reg[35] = (UInt32)WriteBitsToValue(PHY_RDDQS_DM_RISE_SLAVE_DELAY_3, temp_reg[35] ,16+(10-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0, temp_reg[1] ,0+(10-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ1_FALL_SLAVE_DELAY_0, temp_reg[2] ,0+(10-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ2_FALL_SLAVE_DELAY_0, temp_reg[3] ,0+(10-1),0);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ3_FALL_SLAVE_DELAY_0, temp_reg[4] ,0+(10-1),0);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ4_FALL_SLAVE_DELAY_0, temp_reg[5] ,0+(10-1),0);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ5_FALL_SLAVE_DELAY_0, temp_reg[6] ,0+(10-1),0);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ6_FALL_SLAVE_DELAY_0, temp_reg[7] ,0+(10-1),0);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ7_FALL_SLAVE_DELAY_0, temp_reg[8] ,0+(10-1),0);
    temp_reg[36] = (UInt32)WriteBitsToValue(PHY_RDDQS_DM_FALL_SLAVE_DELAY_0, temp_reg[36] ,0+(10-1),0);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_1, temp_reg[10] ,0+(10-1),0);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ1_FALL_SLAVE_DELAY_1, temp_reg[11] ,0+(10-1),0);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ2_FALL_SLAVE_DELAY_1, temp_reg[12] ,0+(10-1),0);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ3_FALL_SLAVE_DELAY_1, temp_reg[13] ,0+(10-1),0);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ4_FALL_SLAVE_DELAY_1, temp_reg[14] ,0+(10-1),0);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ5_FALL_SLAVE_DELAY_1, temp_reg[15] ,0+(10-1),0);
    temp_reg[16] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ6_FALL_SLAVE_DELAY_1, temp_reg[16] ,0+(10-1),0);
    temp_reg[17] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ7_FALL_SLAVE_DELAY_1, temp_reg[17] ,0+(10-1),0);
    temp_reg[37] = (UInt32)WriteBitsToValue(PHY_RDDQS_DM_FALL_SLAVE_DELAY_1, temp_reg[37] ,0+(10-1),0);
    temp_reg[19] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_2, temp_reg[19] ,0+(10-1),0);
    temp_reg[20] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ1_FALL_SLAVE_DELAY_2, temp_reg[20] ,0+(10-1),0);
    temp_reg[21] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ2_FALL_SLAVE_DELAY_2, temp_reg[21] ,0+(10-1),0);
    temp_reg[22] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ3_FALL_SLAVE_DELAY_2, temp_reg[22] ,0+(10-1),0);
    temp_reg[23] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ4_FALL_SLAVE_DELAY_2, temp_reg[23] ,0+(10-1),0);
    temp_reg[24] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ5_FALL_SLAVE_DELAY_2, temp_reg[24] ,0+(10-1),0);
    temp_reg[25] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ6_FALL_SLAVE_DELAY_2, temp_reg[25] ,0+(10-1),0);
    temp_reg[26] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ7_FALL_SLAVE_DELAY_2, temp_reg[26] ,0+(10-1),0);
    temp_reg[38] = (UInt32)WriteBitsToValue(PHY_RDDQS_DM_FALL_SLAVE_DELAY_2, temp_reg[38] ,0+(10-1),0);
    temp_reg[28] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_3, temp_reg[28] ,0+(10-1),0);
    temp_reg[29] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ1_FALL_SLAVE_DELAY_3, temp_reg[29] ,0+(10-1),0);
    temp_reg[30] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ2_FALL_SLAVE_DELAY_3, temp_reg[30] ,0+(10-1),0);
    temp_reg[31] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ3_FALL_SLAVE_DELAY_3, temp_reg[31] ,0+(10-1),0);
    temp_reg[32] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ4_FALL_SLAVE_DELAY_3, temp_reg[32] ,0+(10-1),0);
    temp_reg[33] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ5_FALL_SLAVE_DELAY_3, temp_reg[33] ,0+(10-1),0);
    temp_reg[34] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ6_FALL_SLAVE_DELAY_3, temp_reg[34] ,0+(10-1),0);
    temp_reg[35] = (UInt32)WriteBitsToValue(PHY_RDDQS_DQ7_FALL_SLAVE_DELAY_3, temp_reg[35] ,0+(10-1),0);
    temp_reg[39] = (UInt32)WriteBitsToValue(PHY_RDDQS_DM_FALL_SLAVE_DELAY_3, temp_reg[39] ,0+(10-1),0);
    temp_reg[40] = (UInt32)WriteBitsToValue(PHY_RDDQ0_SLAVE_DELAY_0, temp_reg[40] ,0+(10-1),0);
    temp_reg[40] = (UInt32)WriteBitsToValue(PHY_RDDQ1_SLAVE_DELAY_0, temp_reg[40] ,16+(10-1),16);
    temp_reg[41] = (UInt32)WriteBitsToValue(PHY_RDDQ2_SLAVE_DELAY_0, temp_reg[41] ,0+(10-1),0);
    temp_reg[41] = (UInt32)WriteBitsToValue(PHY_RDDQ3_SLAVE_DELAY_0, temp_reg[41] ,16+(10-1),16);
    temp_reg[42] = (UInt32)WriteBitsToValue(PHY_RDDQ4_SLAVE_DELAY_0, temp_reg[42] ,0+(10-1),0);
    temp_reg[42] = (UInt32)WriteBitsToValue(PHY_RDDQ5_SLAVE_DELAY_0, temp_reg[42] ,16+(10-1),16);
    temp_reg[43] = (UInt32)WriteBitsToValue(PHY_RDDQ6_SLAVE_DELAY_0, temp_reg[43] ,0+(10-1),0);
    temp_reg[43] = (UInt32)WriteBitsToValue(PHY_RDDQ7_SLAVE_DELAY_0, temp_reg[43] ,16+(10-1),16);
    temp_reg[44] = (UInt32)WriteBitsToValue(PHY_RDDM_SLAVE_DELAY_0, temp_reg[44] ,0+(10-1),0);
    temp_reg[45] = (UInt32)WriteBitsToValue(PHY_RDDQ0_SLAVE_DELAY_1, temp_reg[45] ,0+(10-1),0);
    temp_reg[45] = (UInt32)WriteBitsToValue(PHY_RDDQ1_SLAVE_DELAY_1, temp_reg[45] ,16+(10-1),16);
    temp_reg[46] = (UInt32)WriteBitsToValue(PHY_RDDQ2_SLAVE_DELAY_1, temp_reg[46] ,0+(10-1),0);
    temp_reg[46] = (UInt32)WriteBitsToValue(PHY_RDDQ3_SLAVE_DELAY_1, temp_reg[46] ,16+(10-1),16);
    temp_reg[47] = (UInt32)WriteBitsToValue(PHY_RDDQ4_SLAVE_DELAY_1, temp_reg[47] ,0+(10-1),0);
    temp_reg[47] = (UInt32)WriteBitsToValue(PHY_RDDQ5_SLAVE_DELAY_1, temp_reg[47] ,16+(10-1),16);
    temp_reg[48] = (UInt32)WriteBitsToValue(PHY_RDDQ6_SLAVE_DELAY_1, temp_reg[48] ,0+(10-1),0);
    temp_reg[48] = (UInt32)WriteBitsToValue(PHY_RDDQ7_SLAVE_DELAY_1, temp_reg[48] ,16+(10-1),16);
    temp_reg[49] = (UInt32)WriteBitsToValue(PHY_RDDM_SLAVE_DELAY_1, temp_reg[49] ,0+(10-1),0);
    temp_reg[50] = (UInt32)WriteBitsToValue(PHY_RDDQ0_SLAVE_DELAY_2, temp_reg[50] ,0+(10-1),0);
    temp_reg[50] = (UInt32)WriteBitsToValue(PHY_RDDQ1_SLAVE_DELAY_2, temp_reg[50] ,16+(10-1),16);
    temp_reg[51] = (UInt32)WriteBitsToValue(PHY_RDDQ2_SLAVE_DELAY_2, temp_reg[51] ,0+(10-1),0);
    temp_reg[51] = (UInt32)WriteBitsToValue(PHY_RDDQ3_SLAVE_DELAY_2, temp_reg[51] ,16+(10-1),16);
    temp_reg[52] = (UInt32)WriteBitsToValue(PHY_RDDQ4_SLAVE_DELAY_2, temp_reg[52] ,0+(10-1),0);
    temp_reg[52] = (UInt32)WriteBitsToValue(PHY_RDDQ5_SLAVE_DELAY_2, temp_reg[52] ,16+(10-1),16);
    temp_reg[53] = (UInt32)WriteBitsToValue(PHY_RDDQ6_SLAVE_DELAY_2, temp_reg[53] ,0+(10-1),0);
    temp_reg[53] = (UInt32)WriteBitsToValue(PHY_RDDQ7_SLAVE_DELAY_2, temp_reg[53] ,16+(10-1),16);
    temp_reg[54] = (UInt32)WriteBitsToValue(PHY_RDDM_SLAVE_DELAY_2, temp_reg[54] ,0+(10-1),0);
    temp_reg[55] = (UInt32)WriteBitsToValue(PHY_RDDQ0_SLAVE_DELAY_3, temp_reg[55] ,0+(10-1),0);
    temp_reg[55] = (UInt32)WriteBitsToValue(PHY_RDDQ1_SLAVE_DELAY_3, temp_reg[55] ,16+(10-1),16);
    temp_reg[56] = (UInt32)WriteBitsToValue(PHY_RDDQ2_SLAVE_DELAY_3, temp_reg[56] ,0+(10-1),0);
    temp_reg[56] = (UInt32)WriteBitsToValue(PHY_RDDQ3_SLAVE_DELAY_3, temp_reg[56] ,16+(10-1),16);
    temp_reg[57] = (UInt32)WriteBitsToValue(PHY_RDDQ4_SLAVE_DELAY_3, temp_reg[57] ,0+(10-1),0);
    temp_reg[57] = (UInt32)WriteBitsToValue(PHY_RDDQ5_SLAVE_DELAY_3, temp_reg[57] ,16+(10-1),16);
    temp_reg[58] = (UInt32)WriteBitsToValue(PHY_RDDQ6_SLAVE_DELAY_3, temp_reg[58] ,0+(10-1),0);
    temp_reg[58] = (UInt32)WriteBitsToValue(PHY_RDDQ7_SLAVE_DELAY_3, temp_reg[58] ,16+(10-1),16);
    temp_reg[59] = (UInt32)WriteBitsToValue(PHY_RDDM_SLAVE_DELAY_3, temp_reg[59] ,0+(10-1),0);
    jtag_dll_mc_reg_write(120, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(121, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(122, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(123, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(124, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(125, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(126, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(127, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(128, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(376, temp_reg[9] ,true);
    jtag_dll_mc_reg_write(377, temp_reg[10] ,true);
    jtag_dll_mc_reg_write(378, temp_reg[11] ,true);
    jtag_dll_mc_reg_write(379, temp_reg[12] ,true);
    jtag_dll_mc_reg_write(380, temp_reg[13] ,true);
    jtag_dll_mc_reg_write(381, temp_reg[14] ,true);
    jtag_dll_mc_reg_write(382, temp_reg[15] ,true);
    jtag_dll_mc_reg_write(383, temp_reg[16] ,true);
    jtag_dll_mc_reg_write(384, temp_reg[17] ,true);
    jtag_dll_mc_reg_write(632, temp_reg[18] ,true);
    jtag_dll_mc_reg_write(633, temp_reg[19] ,true);
    jtag_dll_mc_reg_write(634, temp_reg[20] ,true);
    jtag_dll_mc_reg_write(635, temp_reg[21] ,true);
    jtag_dll_mc_reg_write(636, temp_reg[22] ,true);
    jtag_dll_mc_reg_write(637, temp_reg[23] ,true);
    jtag_dll_mc_reg_write(638, temp_reg[24] ,true);
    jtag_dll_mc_reg_write(639, temp_reg[25] ,true);
    jtag_dll_mc_reg_write(640, temp_reg[26] ,true);
    jtag_dll_mc_reg_write(888, temp_reg[27] ,true);
    jtag_dll_mc_reg_write(889, temp_reg[28] ,true);
    jtag_dll_mc_reg_write(890, temp_reg[29] ,true);
    jtag_dll_mc_reg_write(891, temp_reg[30] ,true);
    jtag_dll_mc_reg_write(892, temp_reg[31] ,true);
    jtag_dll_mc_reg_write(893, temp_reg[32] ,true);
    jtag_dll_mc_reg_write(894, temp_reg[33] ,true);
    jtag_dll_mc_reg_write(895, temp_reg[34] ,true);
    jtag_dll_mc_reg_write(896, temp_reg[35] ,true);
    jtag_dll_mc_reg_write(129, temp_reg[36] ,true);
    jtag_dll_mc_reg_write(385, temp_reg[37] ,true);
    jtag_dll_mc_reg_write(641, temp_reg[38] ,true);
    jtag_dll_mc_reg_write(897, temp_reg[39] ,true);
    jtag_dll_mc_reg_write(89, temp_reg[40] ,true);
    jtag_dll_mc_reg_write(90, temp_reg[41] ,true);
    jtag_dll_mc_reg_write(91, temp_reg[42] ,true);
    jtag_dll_mc_reg_write(92, temp_reg[43] ,true);
    jtag_dll_mc_reg_write(93, temp_reg[44] ,true);
    jtag_dll_mc_reg_write(345, temp_reg[45] ,true);
    jtag_dll_mc_reg_write(346, temp_reg[46] ,true);
    jtag_dll_mc_reg_write(347, temp_reg[47] ,true);
    jtag_dll_mc_reg_write(348, temp_reg[48] ,true);
    jtag_dll_mc_reg_write(349, temp_reg[49] ,true);
    jtag_dll_mc_reg_write(601, temp_reg[50] ,true);
    jtag_dll_mc_reg_write(602, temp_reg[51] ,true);
    jtag_dll_mc_reg_write(603, temp_reg[52] ,true);
    jtag_dll_mc_reg_write(604, temp_reg[53] ,true);
    jtag_dll_mc_reg_write(605, temp_reg[54] ,true);
    jtag_dll_mc_reg_write(857, temp_reg[55] ,true);
    jtag_dll_mc_reg_write(858, temp_reg[56] ,true);
    jtag_dll_mc_reg_write(859, temp_reg[57] ,true);
    jtag_dll_mc_reg_write(860, temp_reg[58] ,true);
    jtag_dll_mc_reg_write(861, temp_reg[59] ,true);

    SC_PHY_MANUAL_UPDATE();


    updateMulticast(1);
}
