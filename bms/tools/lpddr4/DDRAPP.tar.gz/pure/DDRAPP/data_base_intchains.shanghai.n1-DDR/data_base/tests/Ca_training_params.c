//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[12];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(1036,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(1037,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(1039,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(1040,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(1074,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(1058,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(1073,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(1030,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(1287,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(1288,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(1293,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(1389,true);
}
void Group_read() {
    read_fn();

    PHY_ADR_CALVL_COARSE_DLY_0 = (UInt32)GetBitsFromValue(temp_reg[0],16+(11-1),16);
    PHY_ADR_CALVL_START_0 = (UInt32)GetBitsFromValue(temp_reg[0],0+(11-1),0);
    PHY_ADR_CALVL_QTR_0 = (UInt32)GetBitsFromValue(temp_reg[1],0+(11-1),0);
    PHY_ADR_CALVL_RANK_CTRL_0 = (UInt32)GetBitsFromValue(temp_reg[2],24+(2-1),24);
    PHY_ADR_CALVL_NUM_PATTERNS_0 = (UInt32)GetBitsFromValue(temp_reg[3],0+(2-1),0);
    PHY_ADR_CALVL_RESP_WAIT_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[3],8+(4-1),8);
    PHY_ADR_CALVL_CAPTURE_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[4],0+(4-1),0);
    PHY_ADR_CALVL_TRAIN_MASK_0 = (UInt32)GetBitsFromValue(temp_reg[5],0+(6-1),0);
    PHY_ADR_CSLVL_TRAIN_MASK_0 = (UInt32)GetBitsFromValue(temp_reg[5],8+(6-1),8);
    PHY_ADR_CALVL_DLY_STEP_0 = (UInt32)GetBitsFromValue(temp_reg[6],24+(4-1),24);
    PHY_ADR_CA_TRAIN_MODE1_0 = (UInt32)GetBitsFromValue(temp_reg[7],24+(1-1),24);
    PHY_CSLVL_START = (UInt32)GetBitsFromValue(temp_reg[8],16+(11-1),16);
    PHY_CSLVL_COARSE_DLY = (UInt32)GetBitsFromValue(temp_reg[9],0+(11-1),0);
    PHY_CSLVL_ENABLE = (UInt32)GetBitsFromValue(temp_reg[10],0+(1-1),0);
    PHY_CSLVL_CAPTURE_CNT = (UInt32)GetBitsFromValue(temp_reg[11],16+(4-1),16);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_ADR_CALVL_COARSE_DLY_0, temp_reg[0] ,16+(11-1),16);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_ADR_CALVL_START_0, temp_reg[0] ,0+(11-1),0);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_ADR_CALVL_QTR_0, temp_reg[1] ,0+(11-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_ADR_CALVL_RANK_CTRL_0, temp_reg[2] ,24+(2-1),24);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_ADR_CALVL_NUM_PATTERNS_0, temp_reg[3] ,0+(2-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_ADR_CALVL_RESP_WAIT_CNT_0, temp_reg[3] ,8+(4-1),8);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_ADR_CALVL_CAPTURE_CNT_0, temp_reg[4] ,0+(4-1),0);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_ADR_CALVL_TRAIN_MASK_0, temp_reg[5] ,0+(6-1),0);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_ADR_CSLVL_TRAIN_MASK_0, temp_reg[5] ,8+(6-1),8);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_ADR_CALVL_DLY_STEP_0, temp_reg[6] ,24+(4-1),24);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_ADR_CA_TRAIN_MODE1_0, temp_reg[7] ,24+(1-1),24);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_CSLVL_START, temp_reg[8] ,16+(11-1),16);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_CSLVL_COARSE_DLY, temp_reg[9] ,0+(11-1),0);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_CSLVL_ENABLE, temp_reg[10] ,0+(1-1),0);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_CSLVL_CAPTURE_CNT, temp_reg[11] ,16+(4-1),16);
    jtag_dll_mc_reg_write(1036, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(1037, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(1039, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(1040, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(1074, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(1058, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(1073, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(1030, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(1287, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(1288, temp_reg[9] ,true);
    jtag_dll_mc_reg_write(1293, temp_reg[10] ,true);
    jtag_dll_mc_reg_write(1389, temp_reg[11] ,true);
}
