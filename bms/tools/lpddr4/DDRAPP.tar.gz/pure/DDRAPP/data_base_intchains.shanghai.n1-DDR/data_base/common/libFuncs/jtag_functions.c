// base functions
// These will be called by individual tests and will become part of the execute engine

void SleepIn_10_MiliSecounds(int milisecounds)
{
	int counter = milisecounds/10;
	while (counter > 0)
	{
	  Application.DoEvents();
	  Thread.Sleep(10);
	  counter--;
	}
}
