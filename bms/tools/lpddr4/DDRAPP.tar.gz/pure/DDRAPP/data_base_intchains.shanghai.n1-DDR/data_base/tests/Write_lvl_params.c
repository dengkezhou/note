//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[28];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(30,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(286,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(542,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(798,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(31,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(287,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(543,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(799,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(104,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(360,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(616,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(872,true);
    temp_reg[12] = (UInt32)jtag_dll_mc_reg_read(103,true);
    temp_reg[13] = (UInt32)jtag_dll_mc_reg_read(359,true);
    temp_reg[14] = (UInt32)jtag_dll_mc_reg_read(615,true);
    temp_reg[15] = (UInt32)jtag_dll_mc_reg_read(871,true);
    temp_reg[16] = (UInt32)jtag_dll_mc_reg_read(111,true);
    temp_reg[17] = (UInt32)jtag_dll_mc_reg_read(367,true);
    temp_reg[18] = (UInt32)jtag_dll_mc_reg_read(623,true);
    temp_reg[19] = (UInt32)jtag_dll_mc_reg_read(879,true);
    temp_reg[20] = (UInt32)jtag_dll_mc_reg_read(131,true);
    temp_reg[21] = (UInt32)jtag_dll_mc_reg_read(387,true);
    temp_reg[22] = (UInt32)jtag_dll_mc_reg_read(643,true);
    temp_reg[23] = (UInt32)jtag_dll_mc_reg_read(899,true);
    temp_reg[24] = (UInt32)jtag_dll_mc_reg_read(130,true);
    temp_reg[25] = (UInt32)jtag_dll_mc_reg_read(386,true);
    temp_reg[26] = (UInt32)jtag_dll_mc_reg_read(642,true);
    temp_reg[27] = (UInt32)jtag_dll_mc_reg_read(898,true);
}
void Group_read() {
    read_fn();

    PHY_WRLVL_ALGO_0 = (UInt32)GetBitsFromValue(temp_reg[0],16+(2-1),16);
    PHY_WRLVL_ALGO_1 = (UInt32)GetBitsFromValue(temp_reg[1],16+(2-1),16);
    PHY_WRLVL_ALGO_2 = (UInt32)GetBitsFromValue(temp_reg[2],16+(2-1),16);
    PHY_WRLVL_ALGO_3 = (UInt32)GetBitsFromValue(temp_reg[3],16+(2-1),16);
    PHY_WRLVL_UPDT_WAIT_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[4],0+(4-1),0);
    PHY_WRLVL_UPDT_WAIT_CNT_1 = (UInt32)GetBitsFromValue(temp_reg[5],0+(4-1),0);
    PHY_WRLVL_UPDT_WAIT_CNT_2 = (UInt32)GetBitsFromValue(temp_reg[6],0+(4-1),0);
    PHY_WRLVL_UPDT_WAIT_CNT_3 = (UInt32)GetBitsFromValue(temp_reg[7],0+(4-1),0);
    PHY_WRLVL_CAPTURE_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[0],24+(6-1),24);
    PHY_WRLVL_CAPTURE_CNT_1 = (UInt32)GetBitsFromValue(temp_reg[1],24+(6-1),24);
    PHY_WRLVL_CAPTURE_CNT_2 = (UInt32)GetBitsFromValue(temp_reg[2],24+(6-1),24);
    PHY_WRLVL_CAPTURE_CNT_3 = (UInt32)GetBitsFromValue(temp_reg[3],24+(6-1),24);
    PHY_WRLVL_RESP_WAIT_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[8],0+(6-1),0);
    PHY_WRLVL_RESP_WAIT_CNT_1 = (UInt32)GetBitsFromValue(temp_reg[9],0+(6-1),0);
    PHY_WRLVL_RESP_WAIT_CNT_2 = (UInt32)GetBitsFromValue(temp_reg[10],0+(6-1),0);
    PHY_WRLVL_RESP_WAIT_CNT_3 = (UInt32)GetBitsFromValue(temp_reg[11],0+(6-1),0);
    PHY_WRLVL_DLY_FINE_STEP_0 = (UInt32)GetBitsFromValue(temp_reg[12],24+(4-1),24);
    PHY_WRLVL_DLY_FINE_STEP_1 = (UInt32)GetBitsFromValue(temp_reg[13],24+(4-1),24);
    PHY_WRLVL_DLY_FINE_STEP_2 = (UInt32)GetBitsFromValue(temp_reg[14],24+(4-1),24);
    PHY_WRLVL_DLY_FINE_STEP_3 = (UInt32)GetBitsFromValue(temp_reg[15],24+(4-1),24);
    PHY_WRLVL_DLY_STEP_0 = (UInt32)GetBitsFromValue(temp_reg[12],16+(8-1),16);
    PHY_WRLVL_DLY_STEP_1 = (UInt32)GetBitsFromValue(temp_reg[13],16+(8-1),16);
    PHY_WRLVL_DLY_STEP_2 = (UInt32)GetBitsFromValue(temp_reg[14],16+(8-1),16);
    PHY_WRLVL_DLY_STEP_3 = (UInt32)GetBitsFromValue(temp_reg[15],16+(8-1),16);
    PHY_DATA_DC_WRLVL_ENABLE_0 = (UInt32)GetBitsFromValue(temp_reg[16],0+(1-1),0);
    PHY_DATA_DC_WRLVL_ENABLE_1 = (UInt32)GetBitsFromValue(temp_reg[17],0+(1-1),0);
    PHY_DATA_DC_WRLVL_ENABLE_2 = (UInt32)GetBitsFromValue(temp_reg[18],0+(1-1),0);
    PHY_DATA_DC_WRLVL_ENABLE_3 = (UInt32)GetBitsFromValue(temp_reg[19],0+(1-1),0);
    PHY_DQ_MASK_0 = (UInt32)GetBitsFromValue(temp_reg[4],8+(8-1),8);
    PHY_DQ_MASK_1 = (UInt32)GetBitsFromValue(temp_reg[5],8+(8-1),8);
    PHY_DQ_MASK_2 = (UInt32)GetBitsFromValue(temp_reg[6],8+(8-1),8);
    PHY_DQ_MASK_3 = (UInt32)GetBitsFromValue(temp_reg[7],8+(8-1),8);
    PHY_WRLVL_EARLY_FORCE_ZERO_0 = (UInt32)GetBitsFromValue(temp_reg[20],16+(1-1),16);
    PHY_WRLVL_EARLY_FORCE_ZERO_1 = (UInt32)GetBitsFromValue(temp_reg[21],16+(1-1),16);
    PHY_WRLVL_EARLY_FORCE_ZERO_2 = (UInt32)GetBitsFromValue(temp_reg[22],16+(1-1),16);
    PHY_WRLVL_EARLY_FORCE_ZERO_3 = (UInt32)GetBitsFromValue(temp_reg[23],16+(1-1),16);
    PHY_WRLVL_DELAY_EARLY_THRESHOLD_0 = (UInt32)GetBitsFromValue(temp_reg[24],16+(10-1),16);
    PHY_WRLVL_DELAY_EARLY_THRESHOLD_1 = (UInt32)GetBitsFromValue(temp_reg[25],16+(10-1),16);
    PHY_WRLVL_DELAY_EARLY_THRESHOLD_2 = (UInt32)GetBitsFromValue(temp_reg[26],16+(10-1),16);
    PHY_WRLVL_DELAY_EARLY_THRESHOLD_3 = (UInt32)GetBitsFromValue(temp_reg[27],16+(10-1),16);
    PHY_WRLVL_DELAY_PERIOD_THRESHOLD_0 = (UInt32)GetBitsFromValue(temp_reg[20],0+(10-1),0);
    PHY_WRLVL_DELAY_PERIOD_THRESHOLD_1 = (UInt32)GetBitsFromValue(temp_reg[21],0+(10-1),0);
    PHY_WRLVL_DELAY_PERIOD_THRESHOLD_2 = (UInt32)GetBitsFromValue(temp_reg[22],0+(10-1),0);
    PHY_WRLVL_DELAY_PERIOD_THRESHOLD_3 = (UInt32)GetBitsFromValue(temp_reg[23],0+(10-1),0);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_WRLVL_ALGO_0, temp_reg[0] ,16+(2-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_WRLVL_ALGO_1, temp_reg[1] ,16+(2-1),16);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_WRLVL_ALGO_2, temp_reg[2] ,16+(2-1),16);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_WRLVL_ALGO_3, temp_reg[3] ,16+(2-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_WRLVL_UPDT_WAIT_CNT_0, temp_reg[4] ,0+(4-1),0);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_WRLVL_UPDT_WAIT_CNT_1, temp_reg[5] ,0+(4-1),0);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_WRLVL_UPDT_WAIT_CNT_2, temp_reg[6] ,0+(4-1),0);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_WRLVL_UPDT_WAIT_CNT_3, temp_reg[7] ,0+(4-1),0);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_WRLVL_CAPTURE_CNT_0, temp_reg[0] ,24+(6-1),24);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_WRLVL_CAPTURE_CNT_1, temp_reg[1] ,24+(6-1),24);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_WRLVL_CAPTURE_CNT_2, temp_reg[2] ,24+(6-1),24);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_WRLVL_CAPTURE_CNT_3, temp_reg[3] ,24+(6-1),24);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_WRLVL_RESP_WAIT_CNT_0, temp_reg[8] ,0+(6-1),0);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_WRLVL_RESP_WAIT_CNT_1, temp_reg[9] ,0+(6-1),0);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_WRLVL_RESP_WAIT_CNT_2, temp_reg[10] ,0+(6-1),0);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_WRLVL_RESP_WAIT_CNT_3, temp_reg[11] ,0+(6-1),0);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_WRLVL_DLY_FINE_STEP_0, temp_reg[12] ,24+(4-1),24);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_WRLVL_DLY_FINE_STEP_1, temp_reg[13] ,24+(4-1),24);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_WRLVL_DLY_FINE_STEP_2, temp_reg[14] ,24+(4-1),24);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_WRLVL_DLY_FINE_STEP_3, temp_reg[15] ,24+(4-1),24);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_WRLVL_DLY_STEP_0, temp_reg[12] ,16+(8-1),16);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_WRLVL_DLY_STEP_1, temp_reg[13] ,16+(8-1),16);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_WRLVL_DLY_STEP_2, temp_reg[14] ,16+(8-1),16);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_WRLVL_DLY_STEP_3, temp_reg[15] ,16+(8-1),16);
    temp_reg[16] = (UInt32)WriteBitsToValue(PHY_DATA_DC_WRLVL_ENABLE_0, temp_reg[16] ,0+(1-1),0);
    temp_reg[17] = (UInt32)WriteBitsToValue(PHY_DATA_DC_WRLVL_ENABLE_1, temp_reg[17] ,0+(1-1),0);
    temp_reg[18] = (UInt32)WriteBitsToValue(PHY_DATA_DC_WRLVL_ENABLE_2, temp_reg[18] ,0+(1-1),0);
    temp_reg[19] = (UInt32)WriteBitsToValue(PHY_DATA_DC_WRLVL_ENABLE_3, temp_reg[19] ,0+(1-1),0);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_DQ_MASK_0, temp_reg[4] ,8+(8-1),8);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_DQ_MASK_1, temp_reg[5] ,8+(8-1),8);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_DQ_MASK_2, temp_reg[6] ,8+(8-1),8);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_DQ_MASK_3, temp_reg[7] ,8+(8-1),8);
    temp_reg[20] = (UInt32)WriteBitsToValue(PHY_WRLVL_EARLY_FORCE_ZERO_0, temp_reg[20] ,16+(1-1),16);
    temp_reg[21] = (UInt32)WriteBitsToValue(PHY_WRLVL_EARLY_FORCE_ZERO_1, temp_reg[21] ,16+(1-1),16);
    temp_reg[22] = (UInt32)WriteBitsToValue(PHY_WRLVL_EARLY_FORCE_ZERO_2, temp_reg[22] ,16+(1-1),16);
    temp_reg[23] = (UInt32)WriteBitsToValue(PHY_WRLVL_EARLY_FORCE_ZERO_3, temp_reg[23] ,16+(1-1),16);
    temp_reg[24] = (UInt32)WriteBitsToValue(PHY_WRLVL_DELAY_EARLY_THRESHOLD_0, temp_reg[24] ,16+(10-1),16);
    temp_reg[25] = (UInt32)WriteBitsToValue(PHY_WRLVL_DELAY_EARLY_THRESHOLD_1, temp_reg[25] ,16+(10-1),16);
    temp_reg[26] = (UInt32)WriteBitsToValue(PHY_WRLVL_DELAY_EARLY_THRESHOLD_2, temp_reg[26] ,16+(10-1),16);
    temp_reg[27] = (UInt32)WriteBitsToValue(PHY_WRLVL_DELAY_EARLY_THRESHOLD_3, temp_reg[27] ,16+(10-1),16);
    temp_reg[20] = (UInt32)WriteBitsToValue(PHY_WRLVL_DELAY_PERIOD_THRESHOLD_0, temp_reg[20] ,0+(10-1),0);
    temp_reg[21] = (UInt32)WriteBitsToValue(PHY_WRLVL_DELAY_PERIOD_THRESHOLD_1, temp_reg[21] ,0+(10-1),0);
    temp_reg[22] = (UInt32)WriteBitsToValue(PHY_WRLVL_DELAY_PERIOD_THRESHOLD_2, temp_reg[22] ,0+(10-1),0);
    temp_reg[23] = (UInt32)WriteBitsToValue(PHY_WRLVL_DELAY_PERIOD_THRESHOLD_3, temp_reg[23] ,0+(10-1),0);
    jtag_dll_mc_reg_write(30, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(286, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(542, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(798, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(31, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(287, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(543, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(799, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(104, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(360, temp_reg[9] ,true);
    jtag_dll_mc_reg_write(616, temp_reg[10] ,true);
    jtag_dll_mc_reg_write(872, temp_reg[11] ,true);
    jtag_dll_mc_reg_write(103, temp_reg[12] ,true);
    jtag_dll_mc_reg_write(359, temp_reg[13] ,true);
    jtag_dll_mc_reg_write(615, temp_reg[14] ,true);
    jtag_dll_mc_reg_write(871, temp_reg[15] ,true);
    jtag_dll_mc_reg_write(111, temp_reg[16] ,true);
    jtag_dll_mc_reg_write(367, temp_reg[17] ,true);
    jtag_dll_mc_reg_write(623, temp_reg[18] ,true);
    jtag_dll_mc_reg_write(879, temp_reg[19] ,true);
    jtag_dll_mc_reg_write(131, temp_reg[20] ,true);
    jtag_dll_mc_reg_write(387, temp_reg[21] ,true);
    jtag_dll_mc_reg_write(643, temp_reg[22] ,true);
    jtag_dll_mc_reg_write(899, temp_reg[23] ,true);
    jtag_dll_mc_reg_write(130, temp_reg[24] ,true);
    jtag_dll_mc_reg_write(386, temp_reg[25] ,true);
    jtag_dll_mc_reg_write(642, temp_reg[26] ,true);
    jtag_dll_mc_reg_write(898, temp_reg[27] ,true);
}
