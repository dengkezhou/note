//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
ulong lpbkSetupCode;


// Set grp_slv_dly of all address_control slices
void phy_grp_slave_delay_write(ulong delay)
{
	UInt32[] temp_reg = new UInt32[12];
	
	Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(2089,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(2090,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(2091,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(2092,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(2093,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(2094,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(2345,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(2346,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(2347,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(2348,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(2349,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(2350,true);
	
	temp_reg[0] = (UInt32)WriteBitsToValue(delay, temp_reg[0] ,16+(11-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(delay, temp_reg[1] ,8+(11-1),8);
    temp_reg[2] = (UInt32)WriteBitsToValue(delay, temp_reg[2] ,0+(11-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(delay, temp_reg[3] ,0+(11-1),0);
    temp_reg[4] = (UInt32)WriteBitsToValue(delay, temp_reg[4] ,0+(11-1),0);
    temp_reg[5] = (UInt32)WriteBitsToValue(delay, temp_reg[5] ,0+(11-1),0);
    temp_reg[6] = (UInt32)WriteBitsToValue(delay, temp_reg[6] ,16+(11-1),16);
    temp_reg[7] = (UInt32)WriteBitsToValue(delay, temp_reg[7] ,8+(11-1),8);
    temp_reg[8] = (UInt32)WriteBitsToValue(delay, temp_reg[8] ,0+(11-1),0);
    temp_reg[9] = (UInt32)WriteBitsToValue(delay, temp_reg[9] ,0+(11-1),0);
    temp_reg[10] = (UInt32)WriteBitsToValue(delay, temp_reg[10] ,0+(11-1),0);
    temp_reg[11] = (UInt32)WriteBitsToValue(delay, temp_reg[11] ,0+(11-1),0);
    jtag_dll_mc_reg_write(2089, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(2090, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(2091, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(2092, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(2093, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(2094, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(2345, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(2346, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(2347, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(2348, temp_reg[9] ,true);
    jtag_dll_mc_reg_write(2349, temp_reg[10] ,true);
    jtag_dll_mc_reg_write(2350, temp_reg[11] ,true);
	
	jtag_dll_mc_reg_write(2566,(UInt32)WriteBitsToValue(0x1,jtag_dll_mc_reg_read(2566, true),0 + 1 -1,0) ,true);
}


void Lpbk_Setup()
{
/*
     ac_lpbk_enable = phy_ac_lpbk_enable;
     ac_lpbk_ext_int = phy_ac_lpbk_control[0];
     ac_lpbk_freq = phy_ac_lpbk_control[2:1];
     ac_lpbk_err_clr = phy_ac_lpbk_err_clear;
     ac_lpbk_cycle = phy_ac_lpbk_control[4:3];
     ac_lpbk_go = phy_ac_lpbk_control[5] && ac_lpbk_enable;
     ac_lpbk_sel_obs1 = phy_ac_lpbk_control[7:6];
     ac_lpbk_obs_sel = phy_ac_lpbk_control[8];
*/

	ulong ac_lpbk_ext_int = 0;
	ulong ac_lpbk_freq = 0;
	ulong ac_lpbk_cycle = 0;
	lpbkSetupCode = 0 ;
	
	if (Lpbk_int_mux == 1 )
		ac_lpbk_ext_int = 0;
	else
		ac_lpbk_ext_int = 1;

// Address slice supports PRBS, LFSR and half frequency. AC slice supports PRBS_r, Half and Quarter frequency pattern
	if ((Lpbk_PRBS7 == 1))
		ac_lpbk_freq = 3;
	else if (Lpbk_LFSR == 1)
		ac_lpbk_freq = 0;
	else if (half_clk == 1)
		ac_lpbk_freq = 2;	// half frequency
	else
		ac_lpbk_freq = 1;  // Quarter frequency

	if (free_running == 1)
		ac_lpbk_cycle = 0;
	else if (DQS_toggles_1024 == 1)
		ac_lpbk_cycle = 1;
	else if (DQS_toggles_8192 == 1)
		ac_lpbk_cycle = 2;
	else if (DQS_toggles_64k == 1)
		ac_lpbk_cycle = 3;

	lpbkSetupCode 	=  (((ulong)ac_lpbk_cycle << 3) +
						((ulong)ac_lpbk_freq << 1)  	+
						(ac_lpbk_ext_int));

	phy_ac_lpbk_control_write(lpbkSetupCode);
//	print_message ("set up lpbkSetupCode " +lpbkSetupCode.ToString() + "\n");

}


void phy_ac_lpbk_control_write(ulong phy_lpbk_control)
{
    jtag_dll_mc_reg_write((ulong)PHY_AC_LPBK_CONTROL_ADDR,WriteBitsToValue(phy_lpbk_control, jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_CONTROL_ADDR,true),(int)(PHY_AC_LPBK_CONTROL_OFFSET+(PHY_AC_LPBK_CONTROL_WIDTH-1)),(int)PHY_AC_LPBK_CONTROL_OFFSET),true);
}

void Lpbk_Start()
{    //  ac_lpbk_go = phy_ac_lpbk_control[5] && ac_lpbk_enable;
	lpbkSetupCode = lpbkSetupCode + 0x20; // asserting the 5th bit
	phy_ac_lpbk_control_write(lpbkSetupCode);
	print_message ("Loopback Started for slice " +slice_num.ToString() + "\n");
//	print_message ("start up lpbkSetupCode " +lpbkSetupCode.ToString() + "\n");
}

/*
  else if (ddl_active)
    phy_ac_lpbk_result_obs_out <= `PD phy_ddl_ac_test_obs_out;
  else if (ac_lpbk_obs_sel)
    phy_ac_lpbk_result_obs_out <= `PD phy_ac_lpbk_result_obs1;   ac_lpbk_obs_sel == 1
  else
    phy_ac_lpbk_result_obs_out <= `PD {22'b0,phy_ac_lpbk_result_obs0}; ac_lpbk_obs_sel == 0



  phy_ac_lpbk_result_obs0[7:0] <= `PD adr_slice ? ((lpbk_freq ==2'b11) ? 
  {4'b0,prbs_lpbk_error_2, prbs_lpbk_error_1, prbs_lpbk_error_0, lpbk_data_error}
                                                             : {lpbk_err_byte,lpbk_exp_data,lpbk_err_data,lpbk_data_error})
												:  {2'b0,ac_lpbk_done,ac_lpbk_fail,ac_lpbk_fail_bit};
  phy_ac_lpbk_result_obs0[8] <= `PD ac_lpbk_fail;
  phy_ac_lpbk_result_obs0[9] <= `PD ac_lpbk_done;
  
  
    phy_ac_lpbk_result_obs1[15:0]  <= `PD adr_slice ? lpbk_err_cnt : ac_lpbk_exp_cnt;
    phy_ac_lpbk_result_obs1[31:16] <= `PD adr_slice ? prbs_lpbk_error_cnt :
                                                   	  (ac_lpbk_sel_obs == 2'b00) ? (ac_lpbk_act_cnt_0) : (ac_lpbk_sel_obs == 2'b01) ? (ac_lpbk_act_cnt_1) 
                                                      : (ac_lpbk_sel_obs == 2'b10) ? (ac_lpbk_act_cnt_2) : ac_lpbk_act_cnt_3;  
*/

	
void Lpbk_GetResult()
{  
	lpbkSetupCode = lpbkSetupCode & 0xFF; // ac_lpbk_obs_sel set to 0 to read phy_ac_lpbk_result_obs0
	phy_ac_lpbk_control_write(lpbkSetupCode);
	
	lpbk_data_error   = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),0,0);
	prbs_lpbk_error_0 = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),1,1);
	prbs_lpbk_error_1 = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),2,2);
	prbs_lpbk_error_2 = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),3,3);

	lpbk_err_data     = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),3,1);
	lpbk_exp_data     = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),6,4);
	lpbk_err_byte     = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),7,7);

	ac_lpbk_0_fail_bit = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),3,0);
	ac_lpbk_0_fail     = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),4,4);
	ac_lpbk_0_done 	   = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),5,5);

	lpbkSetupCode = lpbkSetupCode + 0x100; // ac_lpbk_obs_sel set to 1
	phy_ac_lpbk_control_write(lpbkSetupCode);
	
											   
	lpbk_err_cnt    = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),15, 0);
	ac_lpbk_exp_cnt = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),15, 0);
	prbs_lpbk_error_cnt = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),31, 16);
	ac_lpbk_act_cnt_0 = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),31, 16);

	lpbkSetupCode = lpbkSetupCode + 0x40; // ac_lpbk_sel_obs1 set to 01
	phy_ac_lpbk_control_write(lpbkSetupCode);

	ac_lpbk_act_cnt_1 = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),31, 16);

	lpbkSetupCode = lpbkSetupCode + 0x40; // ac_lpbk_sel_obs1 set to 10
	phy_ac_lpbk_control_write(lpbkSetupCode);

	ac_lpbk_act_cnt_2 = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),31, 16);

	lpbkSetupCode = lpbkSetupCode + 0x40; // ac_lpbk_sel_obs1 set to 11
	phy_ac_lpbk_control_write(lpbkSetupCode);

	ac_lpbk_act_cnt_3 = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_RESULT_OBS_ADDR,true),31, 16);

	//Clear results
	jtag_dll_mc_reg_write((ulong)PHY_AC_LPBK_ERR_CLEAR_ADDR,WriteBitsToValue(1, jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_ERR_CLEAR_ADDR,true),(int)PHY_AC_LPBK_ERR_CLEAR_OFFSET,(int)PHY_AC_LPBK_ERR_CLEAR_OFFSET),true); // PHY_AC_LPBK_ERR_CLEAR

}


void Lpbk_Stop()
{
	lpbkSetupCode = lpbkSetupCode & 0x1df ;
	phy_ac_lpbk_control_write(lpbkSetupCode);
	print_message ("stop lpbkSetupCode " +lpbkSetupCode.ToString("X") + "\n");
    jtag_dll_mc_reg_write((ulong)PHY_UPDATE_MASK_ADDR,WriteBitsToValue(0, jtag_dll_mc_reg_read((ulong)PHY_UPDATE_MASK_ADDR,true),(int)PHY_UPDATE_MASK_OFFSET,(int)PHY_UPDATE_MASK_OFFSET),true);
//	print_message ("Loopback Stopped \n");
}

void phy_loopback_fn()
{	
	ulong slice_en ;	
	slice_en = (ulong)(1 << (int)slice_num );

	jtag_dll_mc_reg_write((ulong)PHY_UPDATE_MASK_ADDR,WriteBitsToValue(1, jtag_dll_mc_reg_read((ulong)PHY_UPDATE_MASK_ADDR,true),(int)PHY_UPDATE_MASK_OFFSET,(int)PHY_UPDATE_MASK_OFFSET),true);
	jtag_dll_mc_reg_write((ulong)PHY_DDL_AC_ENABLE_ADDR,WriteBitsToValue(0, jtag_dll_mc_reg_read((ulong)PHY_DDL_AC_ENABLE_ADDR,true),(int)(PHY_DDL_AC_ENABLE_OFFSET+(PHY_DDL_AC_ENABLE_WIDTH-1)),(int)PHY_DDL_AC_ENABLE_OFFSET),true); // Clearing so that phy_ac_lpbk_result_obs register give loopback run results. If programmed to non zero values, phy_ac_lpbk_result_obs register apply for DDL delay testing of address_control slices
	phy_grp_slave_delay_write(grp_slv_dly);
	jtag_dll_mc_reg_write((ulong)PHY_ADRCTL_MANUAL_UPDATE_ADDR,WriteBitsToValue(1, jtag_dll_mc_reg_read((ulong)PHY_ADRCTL_MANUAL_UPDATE_ADDR,true),(int)PHY_ADRCTL_MANUAL_UPDATE_OFFSET,(int)PHY_ADRCTL_MANUAL_UPDATE_OFFSET),true);
	SleepIn_10_MiliSecounds(100);
	jtag_dll_mc_reg_write((ulong)PHY_AC_LPBK_ERR_CLEAR_ADDR,WriteBitsToValue(1, jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_ERR_CLEAR_ADDR,true),(int)PHY_AC_LPBK_ERR_CLEAR_OFFSET,(int)PHY_AC_LPBK_ERR_CLEAR_OFFSET),true); // PHY_AC_LPBK_ERR_CLEAR
	jtag_dll_mc_reg_write((ulong)PHY_AC_LPBK_ENABLE_ADDR,WriteBitsToValue(slice_en, jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_ENABLE_ADDR,true),(int)(PHY_AC_LPBK_ENABLE_OFFSET+(PHY_AC_LPBK_ENABLE_WIDTH-1)),(int)PHY_AC_LPBK_ENABLE_OFFSET),true); // PHY_AC_LPBK_ENABLE

	Lpbk_Setup();
	Lpbk_Start();

	jtag_dll_mc_reg_write((ulong)PHY_AC_LPBK_OBS_SELECT_ADDR,WriteBitsToValue(slice_num, jtag_dll_mc_reg_read((ulong)PHY_AC_LPBK_OBS_SELECT_ADDR,true),(int)(PHY_AC_LPBK_OBS_SELECT_OFFSET+(PHY_AC_LPBK_OBS_SELECT_WIDTH-1)),(int)PHY_AC_LPBK_OBS_SELECT_OFFSET),true); // PHY_AC_LPBK_OBS_SELECT

	ac_lpbk_0_done = 0;
	ac_lpbk_0_fail = 0 ;
	
	UInt32 lpbk_done = 0;
	UInt32 lpbk_fail = 0;
	UInt32 counter = 100;
	do
	{
		Lpbk_GetResult();
		lpbk_done = ac_lpbk_0_done ;
		lpbk_fail = ac_lpbk_0_fail ;
		Application.DoEvents();
		Thread.Sleep(100); // Sleep 1 sec counter=10 is 1 secound
		counter--;
		if ((stop_lpbk == 1) || (counter == 0))
			{
				Lpbk_Stop();
				Lpbk_GetResult();
				lpbk_done = ac_lpbk_0_done ;
				lpbk_fail = ac_lpbk_0_fail ;
				break;
			}
	} while (lpbk_done == 0);	
	
	// print_message (" outside lpbk_done " +lpbk_done.ToString("X") + "\n");
	// print_message (" outside ac_lpbk_0_done " +ac_lpbk_0_done.ToString("X") + "\n");
	
	if ((lpbk_done == 1) && (lpbk_fail == 0) )
		print_message ("Loopback Passed for slice " +slice_num.ToString() + "\n");
	else
		print_message ("Loopback Failed for slice " +slice_num.ToString() + "\n");

	Lpbk_Stop();
	ac_lpbk_0_done = lpbk_done ;
	ac_lpbk_0_fail = lpbk_fail ;
}

void Clear_results()
{
	lpbk_data_error      = 0;
	prbs_lpbk_error_0    = 0;
	prbs_lpbk_error_1    = 0;
	prbs_lpbk_error_2    = 0;
	lpbk_err_data        = 0;
	lpbk_exp_data        = 0;
	lpbk_err_byte 	     = 0;
	ac_lpbk_0_fail_bit   = 0;
	ac_lpbk_0_fail       = 0;
	ac_lpbk_0_done       = 0;
	lpbk_err_cnt         = 0;
	ac_lpbk_exp_cnt      = 0;
	prbs_lpbk_error_cnt  = 0;
	ac_lpbk_act_cnt_0    = 0;
	ac_lpbk_act_cnt_1    = 0;
	ac_lpbk_act_cnt_2    = 0;
	ac_lpbk_act_cnt_3    = 0;
	print_message ("Cleared results \n");
}

