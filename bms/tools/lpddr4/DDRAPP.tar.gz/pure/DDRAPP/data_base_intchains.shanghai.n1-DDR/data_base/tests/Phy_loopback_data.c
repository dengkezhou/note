//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/

ulong lpbkSetupCode;

	ulong ctrl_lpbk_mux = 0;
	ulong ctrl_data_type = 0;
	ulong ctrl_data_err_clr = 0;
	ulong ctrl_lpbk_cnt = 0;
	
// set phy_clk_wrdqZ_slave_delay for all bits for all the slices
void SetWRDQZDelay_Slice(ulong delay)
{
	ulong sliceIdx = 0;
	ulong bitOffset;
	ulong regValue ;

	for (sliceIdx = 0; sliceIdx < PHY_MEM_SLICE_COUNT; sliceIdx++)
	{
		ulong addr = PHY_CLK_WRDQ0_SLAVE_DELAY_0_ADDR + (sliceIdx * HS_SLICE_REG_COUNT);
		regValue = (delay << 16) | delay;
		for (bitOffset = 0; bitOffset < 4; bitOffset++)
		{
			jtag_dll_mc_reg_write(addr+ bitOffset, regValue, true);
		}
		// PHY_CLK_WRDM_SLAVE_DELAY
		regValue = jtag_dll_mc_reg_read((PHY_CLK_WRDM_SLAVE_DELAY_0_ADDR + (sliceIdx * HS_SLICE_REG_COUNT)), true);
		regValue = WriteBitsToValue(delay, regValue, (int)(PHY_CLK_WRDM_SLAVE_DELAY_0_WIDTH - 1 + PHY_CLK_WRDM_SLAVE_DELAY_0_OFFSET), (int)PHY_CLK_WRDM_SLAVE_DELAY_0_OFFSET);
		jtag_dll_mc_reg_write((PHY_CLK_WRDM_SLAVE_DELAY_0_ADDR + (sliceIdx * HS_SLICE_REG_COUNT)), regValue, true);
	}
}

// Set phy_rddqs_dqZ_rise_slave_delay_X and phy_rddqs_dqZ_fall_slave_delay_X for all bits of all the slices
void SetRdDqRiseFallDelay(ulong delay = 0)
{
	ulong regAddr;
	ulong bitIdx = 0;
	ulong sliceIdx = 0;
		
	ulong regValue = (delay<<16) | delay;
	for (sliceIdx = 0; sliceIdx < PHY_MEM_SLICE_COUNT; sliceIdx++)
	{
		regAddr = PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_ADDR  + (HS_SLICE_REG_COUNT *sliceIdx);
		regValue = (delay << 16) | delay;
		for (bitIdx = 0; bitIdx < 9; bitIdx++)
		{
			jtag_dll_mc_reg_write(regAddr + bitIdx, regValue, true);
		}
	}
}

// set phy_clk_wrdqs_slave_delay_X for all bits of all the slices
void WRDQS_SLAVE_DELAY_Write( ulong delay = 0)
{

	ulong sliceIdx = 0;
	for (sliceIdx = 0; sliceIdx < PHY_MEM_SLICE_COUNT; sliceIdx++)
	{
		ulong regAddr = PHY_CLK_WRDQS_SLAVE_DELAY_0_ADDR  + (HS_SLICE_REG_COUNT *sliceIdx);
		ulong regValue = jtag_dll_mc_reg_read(regAddr, true);
		regValue = WriteBitsToValue(delay, regValue, (int)(PHY_CLK_WRDQS_SLAVE_DELAY_0_WIDTH -1 + PHY_CLK_WRDQS_SLAVE_DELAY_0_OFFSET), (int)(PHY_CLK_WRDQS_SLAVE_DELAY_0_OFFSET));
		jtag_dll_mc_reg_write(regAddr, regValue, true);
	}
}


void RDDQS_GATE_SLAVE_DELAY_Write(ulong rddqs_gate_slave_delay)
{
	ulong sliceIdx = 0;

	for (sliceIdx = 0; sliceIdx < PHY_MEM_SLICE_COUNT; sliceIdx++)
	{
		ulong regAddr = PHY_RDDQS_GATE_SLAVE_DELAY_0_ADDR  + (HS_SLICE_REG_COUNT *sliceIdx);
		ulong regValue = jtag_dll_mc_reg_read(regAddr , true);
		regValue = WriteBitsToValue(rddqs_gate_slave_delay, regValue, (int)(PHY_RDDQS_GATE_SLAVE_DELAY_0_OFFSET + PHY_RDDQS_GATE_SLAVE_DELAY_0_WIDTH - 1), ((int)PHY_RDDQS_GATE_SLAVE_DELAY_0_OFFSET));
		jtag_dll_mc_reg_write(regAddr , regValue, true);
	}
}

void PHY_RPTR_UPDATE_Write(ulong phy_rptr_update)
{
	ulong sliceIdx = 0;

	for (sliceIdx = 0; sliceIdx < PHY_MEM_SLICE_COUNT; sliceIdx++)
	{
		ulong regAddr = PHY_RPTR_UPDATE_0_ADDR  + (HS_SLICE_REG_COUNT *sliceIdx);
		ulong regValue = jtag_dll_mc_reg_read(regAddr , true);
		regValue = WriteBitsToValue(phy_rptr_update, regValue, (int)(PHY_RPTR_UPDATE_0_OFFSET + PHY_RPTR_UPDATE_0_WIDTH - 1), ((int)PHY_RPTR_UPDATE_0_OFFSET));
		jtag_dll_mc_reg_write(regAddr , regValue, true);
	}
}


void PHY_RDDQS_LATENCY_ADJUST_write(ulong phy_rddqs_latency_adjust)
{
	ulong sliceIdx = 0;

	for (sliceIdx = 0; sliceIdx < PHY_MEM_SLICE_COUNT; sliceIdx++)
	{
		ulong regAddr = PHY_RDDQS_LATENCY_ADJUST_0_ADDR  + (HS_SLICE_REG_COUNT *sliceIdx);
		ulong regValue = jtag_dll_mc_reg_read(regAddr , true);
		regValue = WriteBitsToValue(phy_rddqs_latency_adjust, regValue, (int)(PHY_RDDQS_LATENCY_ADJUST_0_OFFSET + PHY_RDDQS_LATENCY_ADJUST_0_WIDTH - 1), ((int)PHY_RDDQS_LATENCY_ADJUST_0_OFFSET));
		jtag_dll_mc_reg_write(regAddr , regValue, true);
	}
}



void sc_phy_manual_clear_write(ulong sc_phy_manual_clear)
{
	ulong sliceIdx = 0;

	for (sliceIdx = 0; sliceIdx < PHY_MEM_SLICE_COUNT; sliceIdx++)
	{
		ulong regAddr = SC_PHY_MANUAL_CLEAR_0_ADDR  + (HS_SLICE_REG_COUNT *sliceIdx);
		jtag_dll_mc_reg_write(regAddr,WriteBitsToValue(sc_phy_manual_clear,jtag_dll_mc_reg_read(regAddr,true),(int)(SC_PHY_MANUAL_CLEAR_0_OFFSET +(SC_PHY_MANUAL_CLEAR_0_WIDTH-1)),(int)SC_PHY_MANUAL_CLEAR_0_OFFSET),true);
	}
}

void RDDQ_SLAVE_DELAY_write(ulong delay = 0)
{
	ulong sliceIdx = 0;
	ulong bit_num = 0;

	ulong regAddr;
    ulong regValue;

	for (sliceIdx = 0; sliceIdx < PHY_MEM_SLICE_COUNT; sliceIdx++)
	{
		regAddr = PHY_RDDQ0_SLAVE_DELAY_0_ADDR + (HS_SLICE_REG_COUNT *sliceIdx);
		regValue = (delay<< 16) | delay;
		for (bit_num = 0; bit_num < 4; bit_num++)
		{
			jtag_dll_mc_reg_write((regAddr + bit_num), regValue, true);
		}
		regValue = jtag_dll_mc_reg_read((regAddr + bit_num), true);
		regValue = WriteBitsToValue(delay, regValue, (int)(PHY_RDDQ0_SLAVE_DELAY_0_WIDTH - 1 + PHY_RDDQ0_SLAVE_DELAY_0_OFFSET), (int)(PHY_RDDQ0_SLAVE_DELAY_0_OFFSET));
		jtag_dll_mc_reg_write(regAddr, regValue, true);
	}
}

void PHY_LPBK_CONTROL_Write(ulong phy_lpbk_control)
{
	ulong sliceIdx = 0;
	ulong regAddr;
    ulong regValue;

	for (sliceIdx = 0; sliceIdx < PHY_MEM_SLICE_COUNT; sliceIdx++)
	{
		regAddr = PHY_LPBK_CONTROL_0_ADDR + (HS_SLICE_REG_COUNT *sliceIdx);
		regValue = jtag_dll_mc_reg_read(regAddr, true);
		regValue = WriteBitsToValue(phy_lpbk_control, regValue, ((int)PHY_LPBK_CONTROL_0_OFFSET + (int)(PHY_LPBK_CONTROL_0_WIDTH-1)), ((int)PHY_LPBK_CONTROL_0_OFFSET));
		jtag_dll_mc_reg_write(regAddr, regValue, true);
	}
}

void LpbkBist_Setup()
{
/*
            ctrl_lpbk_en             <= `PD param_phy_lpbk_control[0]  || auto_timing_en_R2      ;
            ctrl_lpbk_int_mux        <= `PD (ctrl_lpbk_en && !param_phy_lpbk_control[1] && ~auto_timing_en_R2 ) || (auto_timing_en_R2 & ~auto_timing_ext_int) ;
            ctrl_lpbk_ext_mux        <= `PD (ctrl_lpbk_en && param_phy_lpbk_control[1] && ctrl_lpbk_ie_en)|| (auto_timing_en_R2 & auto_timing_ext_int && ctrl_lpbk_ie_en);
            ctrl_data_type           <= `PD param_phy_lpbk_control[3:2];
            lpbk_control3_R          <= `PD param_phy_lpbk_control[4];
            ctrl_data_err_clr        <= `PD param_phy_lpbk_control[4] && !lpbk_control3_R;
            ctrl_lpbk_cnt            <= `PD param_phy_lpbk_control[6:5];
            ctrl_lpbk_go             <= `PD param_phy_lpbk_control[7];
            ctrl_lpbk_read_only_test <= `PD param_phy_lpbk_control[8]

      else if (lpbk_rd_en && lpbk_go_hold && (data_type_q == 2'h0) && (lpbk_rddata_valid_w0 || lpbk_rddata_valid_w1)) 
        lfsr_data_syncd   <= `PD 1'b1;

      else if (lpbk_rd_en && lpbk_go_hold && (data_type_q == 2'b11) && (lpbk_rddata_valid_w0 || lpbk_rddata_valid_w1))
        prbs_data_syncd   <= `PD 1'b1;

      else if (lpbk_rd_en && lpbk_go_hold  && (data_type_q == 2'h1) && (lpbk_rddata_valid_w0 || lpbk_rddata_valid_w1))
        clk_data_syncd   <= `PD 1'b1;

	*/

	if (Lpbk_int_mux == 1 )
		ctrl_lpbk_mux = 0;
	else
		ctrl_lpbk_mux = 1;

	if ((Lpbk_PRBS7 == 1))
		ctrl_data_type = 3;
	else if (Lpbk_LFSR == 1)
		ctrl_data_type = 0;
	else
		ctrl_data_type = 1;

	if (Lpbk_err_clear == 1)
		ctrl_data_err_clr = 1;
	else
		ctrl_data_err_clr = 0;

	if (free_running == 1)
		ctrl_lpbk_cnt = 0;
	else if (DQS_toggles_1024 == 1)
		ctrl_lpbk_cnt = 1;
	else if (DQS_toggles_8192 == 1)
		ctrl_lpbk_cnt = 2;
	else if (DQS_toggles_64k == 1)
		ctrl_lpbk_cnt = 3;

	lpbkSetupCode 	=  (			((ulong)lpbk_read_only_test << 8)		+
									((ulong)ctrl_lpbk_cnt << 5)		+
									((ulong)ctrl_data_err_clr << 4) +
									((ulong)ctrl_data_type << 2)  	+
									(ctrl_lpbk_mux << 1) +
									1
								);
		//print_message("lpbkSetupCode = 0x" + lpbkSetupCode.ToString("X") + "\n" );

	PHY_LPBK_CONTROL_Write(0x10);
	PHY_LPBK_CONTROL_Write(lpbkSetupCode);
	PHY_RDDQS_LATENCY_ADJUST_write(0);
	PHY_RPTR_UPDATE_Write (phy_rptr_update);
	sc_phy_manual_clear_write(1);

	//print_message("Loopback BIST setup done\n");

}

void LpbkBist_Start()
{
	//ctrl_lpbk_go             <= `PD param_phy_lpbk_control[7];
	lpbkSetupCode = lpbkSetupCode + 0x80;
	//print_message("lpbkStartup = 0x" + lpbkSetupCode.ToString("X") + "\n" );
	PHY_LPBK_CONTROL_Write(lpbkSetupCode);
}

void LpbkBist_GetResult()
{
  // assign param_phy_lpbk_result_obs = (data_type_q == 2'b11) ? 
  //    {3'b0,ctrl_lpbk_done,~lpbk_data_syncd,lpbk_data_error,lpbk_err_byte,prbs_lpbk_error_8,prbs_lpbk_error_7,prbs_lpbk_error_6,prbs_lpbk_error_5,
  //  prbs_lpbk_error_4,prbs_lpbk_error_3,prbs_lpbk_error_2,prbs_lpbk_error_1,prbs_lpbk_error_0,prbs_lpbk_error_cnt} : 
  //  {1'b0,8'b0,1'b0,ctrl_lpbk_done,~lpbk_data_syncd,lpbk_data_error,lpbk_err_byte,lpbk_exp_data[8:0],lpbk_err_data[8:0]}; 
 
	ulong Lpbk_result_0 = 0;
	ulong Lpbk_result_1 = 0;
	ulong Lpbk_result_2 = 0;
	ulong Lpbk_result_3 = 0;
	ulong regAddr ;


	regAddr = PHY_LPBK_RESULT_OBS_0_ADDR + (HS_SLICE_REG_COUNT *0);	// Slice 0
	Lpbk_result_0 = jtag_dll_mc_reg_read(regAddr , true);
	//print_message("Lpbk_result_0 = 0x" + Lpbk_result_0.ToString("X") + " for Slice = 0" +  "\n" );
	if (Lpbk_PRBS7 == 0)
		{
			ctrl_lpbk_done_0	=	(uint)((Lpbk_result_0 >> 21) & 0x1 );
			lpbk_data_syncd_0	=	(uint) ((Lpbk_result_0 >> 20) & 0x1 );
			lpbk_data_error_0	=	(uint)((Lpbk_result_0 >> 19) & 0x1 );
			lpbk_err_byte_0   	=   (uint)((Lpbk_result_0 >> 18) & 0x1 );
			lpbk_exp_data_0		=	(uint)((Lpbk_result_0 >> 9) & 0x1FF );
			lpbk_err_data_0		=	(uint)(Lpbk_result_0 & 0x1FF);

			regAddr = PHY_LPBK_RESULT_OBS_0_ADDR + (HS_SLICE_REG_COUNT *1);	// Slice 2
			Lpbk_result_1 = jtag_dll_mc_reg_read(regAddr , true);
			//print_message("Lpbk_result_1 = 0x" + Lpbk_result_1.ToString("X") + " for Slice = 1" +  "\n" );

			ctrl_lpbk_done_1	=	(uint)((Lpbk_result_1 >> 21) & 0x1 );
			lpbk_data_syncd_1	=	(uint) ((Lpbk_result_1 >> 20) & 0x1 );
			lpbk_data_error_1	=	(uint)((Lpbk_result_1 >> 19) & 0x1 );
			lpbk_err_byte_1   	=   (uint)((Lpbk_result_1 >> 18) & 0x1 );
			lpbk_exp_data_1		=	(uint)((Lpbk_result_1 >> 9) & 0x1FF );
			lpbk_err_data_1		=	(uint)(Lpbk_result_1 & 0x1FF);

			regAddr = PHY_LPBK_RESULT_OBS_0_ADDR + (HS_SLICE_REG_COUNT *2);	// Slice 2
			Lpbk_result_2 = jtag_dll_mc_reg_read(regAddr , true);
			//print_message("Lpbk_result_2 = 0x" + Lpbk_result_2.ToString("X") + " for Slice = 2" +  "\n" );

			ctrl_lpbk_done_2	=	(uint)((Lpbk_result_2 >> 21) & 0x1 );
			lpbk_data_syncd_2	=	(uint)((Lpbk_result_2 >> 20) & 0x1 );
			lpbk_data_error_2	=	(uint)((Lpbk_result_2 >> 19) & 0x1 );
			lpbk_err_byte_2   	=   (uint)((Lpbk_result_2 >> 18) & 0x1 );
			lpbk_exp_data_2		=	(uint)((Lpbk_result_2 >> 9) & 0x1FF );
			lpbk_err_data_2		=	(uint)(Lpbk_result_2 & 0x1FF);

			regAddr = PHY_LPBK_RESULT_OBS_0_ADDR + (HS_SLICE_REG_COUNT *3);	// Slice 3
			Lpbk_result_3 = jtag_dll_mc_reg_read(regAddr , true);
			//print_message("Lpbk_result_3 = 0x" + Lpbk_result_3.ToString("X") + " for Slice = 3" +  "\n" );

			ctrl_lpbk_done_3	=	(uint)((Lpbk_result_3 >> 21) & 0x1 );
			lpbk_data_syncd_3	=	(uint)((Lpbk_result_3 >> 20) & 0x1 );
			lpbk_data_error_3	=	(uint)((Lpbk_result_3 >> 19) & 0x1 );
			lpbk_err_byte_3   	=   (uint)((Lpbk_result_3 >> 18) & 0x1 );
			lpbk_exp_data_3		=	(uint)((Lpbk_result_3 >> 9) & 0x1FF );
			lpbk_err_data_3		=	(uint)(Lpbk_result_3 & 0x1FF);
		}
	else
		{
			ctrl_lpbk_done_0	=	(uint)((Lpbk_result_0 >> 28) & 0x1 );
			lpbk_data_syncd_0	=	(uint) ((Lpbk_result_0 >> 27) & 0x1 );
			lpbk_data_error_0	=	(uint)((Lpbk_result_0 >> 26) & 0x1 );
			lpbk_err_byte_0   	=   (uint)((Lpbk_result_0 >> 25) & 0x1 );
			prbs_lpbk_error_0	=	(uint)((Lpbk_result_0 >> 16) & 0x1FF );
			prbs_lpbk_err_cnt_0	=	(uint)(Lpbk_result_0 & 0xFFFF);

			regAddr = PHY_LPBK_RESULT_OBS_0_ADDR + (HS_SLICE_REG_COUNT *1);	// Slice 2
			Lpbk_result_1 = jtag_dll_mc_reg_read(regAddr , true);
			//print_message("Lpbk_result_1 = 0x" + Lpbk_result_1.ToString("X") + " for Slice = 1" +  "\n" );

			ctrl_lpbk_done_1	=	(uint)((Lpbk_result_1 >> 28) & 0x1 );
			lpbk_data_syncd_1	=	(uint) ((Lpbk_result_1 >> 27) & 0x1 );
			lpbk_data_error_1	=	(uint)((Lpbk_result_1 >> 26) & 0x1 );
			lpbk_err_byte_1   	=   (uint)((Lpbk_result_1 >> 25) & 0x1 );
			prbs_lpbk_error_1	=	(uint)((Lpbk_result_1 >> 16) & 0x1FF );
			prbs_lpbk_err_cnt_1	=	(uint)(Lpbk_result_1 & 0xFFFF);

			regAddr = PHY_LPBK_RESULT_OBS_0_ADDR + (HS_SLICE_REG_COUNT *2);	// Slice 2
			Lpbk_result_2 = jtag_dll_mc_reg_read(regAddr , true);
			//print_message("Lpbk_result_2 = 0x" + Lpbk_result_2.ToString("X") + " for Slice = 2" +  "\n" );

			ctrl_lpbk_done_2	=	(uint)((Lpbk_result_2 >> 28) & 0x1 );
			lpbk_data_syncd_2	=	(uint)((Lpbk_result_2 >> 27) & 0x1 );
			lpbk_data_error_2	=	(uint)((Lpbk_result_2 >> 26) & 0x1 );
			lpbk_err_byte_2   	=   (uint)((Lpbk_result_2 >> 25) & 0x1 );
			prbs_lpbk_error_2	=	(uint)((Lpbk_result_2 >> 16) & 0x1FF );
			prbs_lpbk_err_cnt_2	=	(uint)(Lpbk_result_2 & 0xFFFF);

			regAddr = PHY_LPBK_RESULT_OBS_0_ADDR + (HS_SLICE_REG_COUNT *3);	// Slice 3
			Lpbk_result_3 = jtag_dll_mc_reg_read(regAddr , true);
			//print_message("Lpbk_result_3 = 0x" + Lpbk_result_3.ToString("X") + " for Slice = 3" +  "\n" );

			ctrl_lpbk_done_3	=	(uint)((Lpbk_result_3 >> 28) & 0x1 );
			lpbk_data_syncd_3	=	(uint)((Lpbk_result_3 >> 27) & 0x1 );
			lpbk_data_error_3	=	(uint)((Lpbk_result_3 >> 26) & 0x1 );
			lpbk_err_byte_3   	=   (uint)((Lpbk_result_3 >> 25) & 0x1 );
			prbs_lpbk_error_3	=	(uint)((Lpbk_result_3 >> 16) & 0x1FF );
			prbs_lpbk_err_cnt_3	=	(uint)(Lpbk_result_3 & 0xFFFF);
		}

}

/*
            ctrl_lpbk_en             <= `PD param_phy_lpbk_control[0]  || auto_timing_en_R2      ;
            ctrl_lpbk_int_mux        <= `PD (ctrl_lpbk_en && !param_phy_lpbk_control[1] && ~auto_timing_en_R2 ) || (auto_timing_en_R2 & ~auto_timing_ext_int) ;
            ctrl_lpbk_ext_mux        <= `PD (ctrl_lpbk_en && param_phy_lpbk_control[1] && ctrl_lpbk_ie_en)|| (auto_timing_en_R2 & auto_timing_ext_int && ctrl_lpbk_ie_en);
            ctrl_data_type           <= `PD param_phy_lpbk_control[3:2];
            lpbk_control3_R          <= `PD param_phy_lpbk_control[4];
            ctrl_data_err_clr        <= `PD param_phy_lpbk_control[4] && !lpbk_control3_R;
            ctrl_lpbk_cnt            <= `PD param_phy_lpbk_control[6:5];
            ctrl_lpbk_go             <= `PD param_phy_lpbk_control[7];
            ctrl_lpbk_read_only_test <= `PD param_phy_lpbk_control[8]

	*/
	
void LpbkBist_Stop()
{
	PHY_LPBK_CONTROL_Write(0x11);

	PHY_LPBK_CONTROL_Write(0);
	
	sc_phy_manual_clear_write(0x2);
	
    jtag_dll_mc_reg_write((ulong)PHY_UPDATE_MASK_ADDR,WriteBitsToValue(0, jtag_dll_mc_reg_read((ulong)PHY_UPDATE_MASK_ADDR,true),(int)PHY_UPDATE_MASK_OFFSET,(int)PHY_UPDATE_MASK_OFFSET),true);	
	
	jtag_dll_mc_reg_write((ulong)DRAM_CLK_DISABLE_ADDR,WriteBitsToValue(0x0, jtag_dll_mc_reg_read((ulong)DRAM_CLK_DISABLE_ADDR,false),(int)(DRAM_CLK_DISABLE_OFFSET + (DRAM_CLK_DISABLE_WIDTH-1)),((int)DRAM_CLK_DISABLE_OFFSET)),false);
	
	print_message("Loopback stopped \n");
	print_message(" \n");	

}

void RegLpbk_c()
{
	ulong wr_delay = 0;
	ulong rd_delay = 0;
	rd_delay = (ulong)uRdGateDelay;
	wr_delay = (ulong)uWrDQDelay;

	SetWRDQZDelay_Slice(wr_delay);
	SetRdDqRiseFallDelay(RdDqRiseFallDelay);
	// set wr-dqs-delay to 0
	WRDQS_SLAVE_DELAY_Write(wrdqs_slave_delay);
	// set rd-dqs-delay to 0x
	RDDQS_GATE_SLAVE_DELAY_Write(rd_delay);
	// set read-dq fall and rise delay to 0
	RDDQ_SLAVE_DELAY_write(rddq_slave_delay);


	jtag_dll_mc_reg_write((ulong)SC_PHY_MANUAL_UPDATE_ADDR,WriteBitsToValue(1, jtag_dll_mc_reg_read((ulong)SC_PHY_MANUAL_UPDATE_ADDR,true),((int)SC_PHY_MANUAL_UPDATE_OFFSET + (int)(SC_PHY_MANUAL_UPDATE_WIDTH-1)),((int)SC_PHY_MANUAL_UPDATE_OFFSET)),true);
	
	SleepIn_10_MiliSecounds(1000);

	LpbkBist_Setup();
	
	jtag_dll_mc_reg_write((ulong)PHY_UPDATE_MASK_ADDR,WriteBitsToValue(1, jtag_dll_mc_reg_read((ulong)PHY_UPDATE_MASK_ADDR,true),((int)PHY_UPDATE_MASK_OFFSET),((int)PHY_UPDATE_MASK_OFFSET)),true);
	jtag_dll_mc_reg_write((ulong)DRAM_CLK_DISABLE_ADDR,WriteBitsToValue(0xF, jtag_dll_mc_reg_read((ulong)DRAM_CLK_DISABLE_ADDR,false),(int)(DRAM_CLK_DISABLE_OFFSET + (DRAM_CLK_DISABLE_WIDTH-1)),((int)DRAM_CLK_DISABLE_OFFSET)),false);


	LpbkBist_Start();
	
	uint lpbk_done = 0 ;

	do
	{
		LpbkBist_GetResult();
		lpbk_done = (ctrl_lpbk_done_0 & ctrl_lpbk_done_1 & ctrl_lpbk_done_2 & ctrl_lpbk_done_3 );
		Application.DoEvents();
		Thread.Sleep(100);
		if (stop_lpbk == 1)
			{
				LpbkBist_Stop();
				return;
			}
	} while (lpbk_done == 0 );

	LpbkBist_GetResult();
	
	if (stop_lpbk == 0) LpbkBist_Stop(); // If loopback was not forced to stop then Stop loopback to reset loopback control register. This is for modes other than free running mode and forced stop scenario.

	if (free_running == 1)  // in Free running mode check the status of "lpbk_data_syncd_x" and "lpbk_data_error_x" to check the status of loopback. Dont worry about loopback done to go high.
	{
		ctrl_lpbk_done_0 = 1;
		ctrl_lpbk_done_1 = 1;
		ctrl_lpbk_done_2 = 1;
		ctrl_lpbk_done_3 = 1;
	}
	
// SLICE 0
	if ((ctrl_lpbk_done_0 == 1) && (lpbk_data_syncd_0 == 0) && (lpbk_data_error_0 == 0) )
		{
			if 	(Lpbk_int_mux == 1)
				print_message ("Internal Loopback Passed" + " for Slice = 0" + "\n");
			else
				print_message ("External Loopback Passed" + " for Slice = 0" + "\n");
		}
	else if (lpbk_data_syncd_0 == 1)
		{
			print_message ("Loopback data not Syncd" + " for Slice = 0" + "\n");
		}
	else
		{
			if 	(Lpbk_int_mux == 1)
				print_message ("Internal Loopback Failed" + " for Slice = 0" + "\n");
			else
				print_message ("External Loopback Failed" + " for Slice = 0" + "\n");
		}

// SLICE 1
	if ((ctrl_lpbk_done_1 == 1) && (lpbk_data_syncd_1 == 0) && (lpbk_data_error_1 == 0) )
		{
			if 	(Lpbk_int_mux == 1)
				print_message ("Internal Loopback Passed" + " for Slice = 1" + "\n");
			else
				print_message ("External Loopback Passed" + " for Slice = 1" + "\n");
		}
	else if (lpbk_data_syncd_1 == 1)
		{
			print_message ("Loopback data not Syncd" + " for Slice = 1" + "\n");
		}
	else
		{
			if 	(Lpbk_int_mux == 1)
				print_message ("Internal Loopback Failed" + " for Slice = 1" + "\n");
			else
				print_message ("External Loopback Failed" + " for Slice = 1" + "\n");
		}

// SLICE 2
	if ((ctrl_lpbk_done_2 == 1) && (lpbk_data_syncd_2 == 0) && (lpbk_data_error_2 == 0) )
		{
			if 	(Lpbk_int_mux == 1)
				print_message ("Internal Loopback Passed" + " for Slice = 2" + "\n");
			else
				print_message ("External Loopback Passed" + " for Slice = 2" + "\n");
		}
	else if (lpbk_data_syncd_2 == 1)
		{
			print_message ("Loopback data not Syncd" + " for Slice = 2" + "\n");
		}
	else
		{
			if 	(Lpbk_int_mux == 1)
				print_message ("Internal Loopback Failed" + " for Slice = 2" + "\n");
			else
				print_message ("External Loopback Failed" + " for Slice = 2" + "\n");
		}

// SLICE 3
	if ((ctrl_lpbk_done_3 == 1) && (lpbk_data_syncd_3 == 0) && (lpbk_data_error_3 == 0) )
		{
			if 	(Lpbk_int_mux == 1)
				print_message ("Internal Loopback Passed" + " for Slice = 3" + "\n");
			else
				print_message ("External Loopback Passed" + " for Slice = 3" + "\n");
		}
	else if (lpbk_data_syncd_3 == 1)
		{
			print_message ("Loopback data not Syncd" + " for Slice = 3" + "\n");
		}
	else
		{
			if 	(Lpbk_int_mux == 1)
				print_message ("Internal Loopback Failed" + " for Slice = 3" + "\n");
			else
				print_message ("External Loopback Failed" + " for Slice = 3" + "\n");
		}
}

