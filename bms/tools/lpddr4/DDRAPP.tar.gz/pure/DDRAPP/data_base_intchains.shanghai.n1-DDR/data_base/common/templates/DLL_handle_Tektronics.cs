﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
//using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.ComponentModel;    // KSP for win32 exceptions
using System.Net;

/// .\driver\UsbE_sfl.dll for SAnJose PC
/// usb1e_sfl.dll for my jtag dongle
   
namespace DDR_Utility
{
   public class DLL_handle_tektronics
    {
        /* Enumerated Data Type Definitions */

        static string uriBase = "http://socrchar";

        static string uploadSuite = "/test.jsp?action=new&cat=1&suite=1";

        static string uploadIter = "/testiterupload.jsp?auto=true&cat=1&suite=1";

        static string metaQuery = "/index.jsp?action=query&cat=1&suite=1";
        static string dataQuery = "/test.jsp?action=query&cat=1&suite=1";

        WebClient client = new WebClient();

       public DLL_handle_tektronics()
       {
           client.BaseAddress = uriBase;
           client.Proxy = GlobalProxySelection.GetEmptyWebProxy();
           client.Encoding = System.Text.Encoding.UTF8;
       }



       /*
        *             //String resource = "TCPIP::158.140.66.25::INSTR";
           // null below will default to the above resource:
           TekMeasure.TekMeasure measure = new TekMeasure.TekMeasure(null);
           String result = measure.GetChannelInfo();
           Console.WriteLine(result);
           // we will do multiple runs, hence add a Run in front of the data
           String measureHdr = measure.GetMeasurementsHeader("Run,");
           Console.WriteLine(measureHdr);
           for (int r = 0; r < 4; r++)
           {
               String measurement = measure.GetMeasurements(r + ",");
               Console.WriteLine(r + "," + measurement);
           }

        * /
        
       /* Retrieve Driver information */

       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern void TekMeasure(IntPtr str);

       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern IntPtr GetChannelInfo();

       /* Retrieve Driver information */
       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
       private static extern IntPtr GetMeasurementsHeader();

       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern IntPtr GetMeasurements();

       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern IntPtr GetMeasurementSource(UInt32 idx);
		
       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern IntPtr GetChannelLabel(UInt32 channel);
       

       // Use only the following
       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
       private static extern IntPtr GetSuiteConfigInfo(IntPtr suiteComnt,IntPtr chipRev, IntPtr boardRev, IntPtr DIMM, IntPtr DIMMsite, IntPtr DIMMslot, IntPtr location);

       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
       private static extern void ClearMeasurements();

       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
       private static extern IntPtr GetNewTestRunInfo(IntPtr param);

       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
       private static extern IntPtr GetRunIterHeader(IntPtr additionalcolmns);

       [DllImport(@".\driver\TekMeasureDLL.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, SetLastError = true)]
       private static extern IntPtr GetRunIterData(UInt32 number, IntPtr additionalData);


       public String dllTekGetChannelLabel(UInt32 channel)
       {
           //
           IntPtr ptr = GetChannelLabel(channel);
           string str = Marshal.PtrToStringAnsi(ptr);
           return str;

       }

       public String dllTekGetRunIterDataF(UInt32 number, String additionalData)
       {
           //
           IntPtr parameter = Marshal.StringToHGlobalAnsi(additionalData);
           IntPtr ptr = GetRunIterData(number, parameter);
           string str = Marshal.PtrToStringAnsi(ptr);
           return str;

       }

       public String dllTekGetRunIterHeaderF(String additionalcolmns)
       {
           //
           IntPtr parameter = Marshal.StringToHGlobalAnsi(additionalcolmns);
           IntPtr ptr = GetRunIterHeader(parameter);
           string str = Marshal.PtrToStringAnsi(ptr);


           return str;

       }

       public String dllTekGetNewTestRunInfoF(String param)
       {
           //
           IntPtr parameter = Marshal.StringToHGlobalAnsi(param);


           IntPtr ptr = GetNewTestRunInfo(parameter);
           string str = Marshal.PtrToStringAnsi(ptr);

           return str;

       }


       public String dllTekGetSuiteConfigInfo(String cmnt, String chipRev, String boardRev, String DIMM, String DIMMsite, String DIMMslot, String location)
       {
           //
           IntPtr suite_cmnt = Marshal.StringToHGlobalAnsi(cmnt);
           IntPtr chip_rev = Marshal.StringToHGlobalAnsi(chipRev);
           IntPtr board_Rev = Marshal.StringToHGlobalAnsi(boardRev);
           IntPtr DIMM_ = Marshal.StringToHGlobalAnsi(DIMM);
           IntPtr DIMM_site = Marshal.StringToHGlobalAnsi(DIMMsite);
           IntPtr DIMM_slot = Marshal.StringToHGlobalAnsi(DIMMslot);
           IntPtr location_ = Marshal.StringToHGlobalAnsi(location);
           IntPtr ptr = GetSuiteConfigInfo(suite_cmnt,chip_rev, board_Rev, DIMM_, DIMM_site, DIMM_slot, location_);
           string str = Marshal.PtrToStringAnsi(ptr);


           return str;

       }



       public void dllTekClearMeasurements()
       {

           ClearMeasurements();

       }

       public void dllTekMeasure(string ip_addr)
       {

           IntPtr na = Marshal.StringToHGlobalAnsi(ip_addr);
           TekMeasure(na);

       }

        public String dllTekGetChannelInfo()
        { 
           IntPtr ptr = GetChannelInfo();
           string str = Marshal.PtrToStringAnsi(ptr);

           return str;
            
        }

       public String dllTekGetMeasurementsHeader()
       {
           //
           IntPtr ptr = GetMeasurementsHeader();
           string str = Marshal.PtrToStringAnsi(ptr);


           return str;

       }

       public String dllTekGetMeasurements()
       {
           //
           IntPtr ptr = GetMeasurements();
           string str = Marshal.PtrToStringAnsi(ptr);
           return str;

       }


       public String dllTekGetMeasurementSource(UInt32 idx)
       {
           //
           IntPtr ptr = GetMeasurementSource(idx);
           string str = Marshal.PtrToStringAnsi(ptr);
           return str;
       }
	   
       /**
        * Get a dictionary of internal names to presentable names for the configuration items in a suite
        */
       public IDictionary<string, string> GetSuiteConfigItems()
       {
           IDictionary<string, string> result = new Dictionary<string, string>();
           string web = client.DownloadString(metaQuery + "&what=config");
           string[] a = web.Split(new char[] { '\n' });
           for (int i = 0; i < a.Length; i++)
           {
               string itemInfo = a[i];
               string[] info = itemInfo.Split(new char[] { ',' });
               if (info.Length > 1)
               {
                   result.Add(info[0], info[1]);
               }
           }
           return result;
       }
       /**
         * Get a list of IDs for the tests in our suite.
         * The only use is to pass them to the GetTestXXX methods
         */
       public IList<string> GetTestIds()
       {
           IList<string> result = new List<string>();
           string web = client.DownloadString(metaQuery + "&what=testIds");
           string[] a = web.Split(null);
           for (int i = 0; i < a.Length; i++)
           {
               if (a[i].Length > 0)
               {
                   result.Add(a[i]);
               }
           }
           return result;
       }

       /**
        * Get the identifier (internal name) for a test
        */
       public string GetTestIdentifier(string testId)
       {
           return client.DownloadString(metaQuery + testId + "&what=ident");
       }

       /**
        * Get the presentable name for a test
        */
       public string GetTestName(string testId)
       {
           return client.DownloadString(metaQuery + testId + "&what=name");
       }

       /**
        * Get a dictionary of internal names to presentable names for the configuration items in a suite
        */
       public IDictionary<string, string> GetTestConfigItems(string testId)
       {
           IDictionary<string, string> result = new Dictionary<string, string>();
           string web = client.DownloadString(metaQuery + testId + "&what=config");
           string[] a = web.Split(new char[] { '\n' });
           for (int i = 0; i < a.Length; i++)
           {
               string itemInfo = a[i];
               string[] info = itemInfo.Split(new char[] { ',' });
               if (info.Length > 1)
               {
                   result.Add(info[0], info[1]);
               }
           }
           return result;
       }

       /**
        * Get a list of IDs for the runs of our suite.
        * The only use is to pass them to the GetSuiteXXX methods
        */
       public IList<string> GetSuiteRunIds()
       {
           IList<string> result = new List<string>();
           string web = client.DownloadString(dataQuery + "&what=runIds");
           string[] a = web.Split(null);
           for (int i = 0; i < a.Length; i++)
           {
               if (a[i].Length > 0)
               {
                   result.Add(a[i]);
               }
           }
           return result;
       }

       /**
        * Get the start time of a suite run, in yyyy-MM-dd/HH:mm:ss format
        * @param suiteRunId one of the IDs returned by GetSuiteRunIds
        */
       public string GetSuiteRunStartTime(String suiteRunId)
       {
           return client.DownloadString(dataQuery + suiteRunId + "&what=started");
       }

       /**
        * Get a list of IDs for the test runs in a suite run.
        * The only use is to pass them to the GetTestRunXXX methods
        */
       public IList<string> GetTestRunIds(String suiteRunId)
       {
           IList<string> result = new List<string>();
           string web = client.DownloadString(dataQuery + suiteRunId + "&what=testIds");
           string[] a = web.Split(null);
           for (int i = 0; i < a.Length; i++)
           {
               if (a[i].Length > 0)
               {
                   result.Add(a[i]);
               }
           }
           return result;
       }

       /**
        * Get the start time of a suite run, in yyyy-MM-dd/HH:mm:ss format
        * @param suiteRunId one of the IDs returned by GetSuiteRunIds
        * @param testRunId one of the IDs returned by GetTestRunIds
        */
       public string GetTestRunStartTime(String suiteRunId, String testRunId)
       {
           return client.DownloadString(dataQuery + suiteRunId + testRunId + "&what=started");
       }

       /**
        * Call this with the data from GetSuiteConfigInfo
        * @param data string from GetSuiteConfigInfo
        * @return string used in next call
        */
       public string UploadSuiteRun(string data)
       {
           string result = client.DownloadString(uploadSuite + "&data=" + data);
           return result;
       }

        private void parseIterParams(string pars, NameValueCollection collection)
        {
            string[] pnvs = pars.Split(new char[] { '&' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string pnv in pnvs)
            {
                string[] nv = pnv.Split(new char[] { '=' });
                collection.Add(nv[0], nv[1]);
            }
        }

       /**
        * Upload test run info (not the actual test data, just the configuration) for the Frequency test.
        * @param suiteResult string from UploadSuiteRun, or a value returned by GetSuiteRunIds()
        * @param data string from GetNewTestRunInfo
        * @return string used in next call
        */
       public string UploadTestRunInfoF(string suiteResult, string data)
       {
           string result = client.DownloadString(uploadSuite + suiteResult + "&tid=3&data=" + data);
           return result;
       }

       /**
        * Call this with the result of the relevant UploadTestRunInfo, and the data from calls to GetRunIterHeaderF/GetRunIterDataF
        * @param suiteResult string from UploadSuiteRun
        * @param data string from GetRunIterHeader & one or more GetRunIterData calls
        */
       public void UploadTestRunItersF(string runinfoResult, string data)
       {
           NameValueCollection collection = new NameValueCollection();
           collection.Add("action", "new");
           collection.Add("cat", "1");
           collection.Add("suite", "1");
           parseIterParams(runinfoResult, collection);
           collection.Add("data", data);
           client.UploadValues("test.jsp", collection);
       }

       /**
        * Upload test run info (not the actual test data, just the configuration) for the Voltage test.
        * @param suiteResult string from UploadSuiteRun, or a value returned by GetSuiteRunIds()
        * @param data string from GetNewTestRunInfo
        * @return string used in next call
        */
       public string UploadTestRunInfoV(string suiteResult, string data)
       {
           string result = client.DownloadString(uploadSuite + suiteResult + "&tid=1&data=" + data);
           return result;
       }

       /**
        * Call this with the result of the relevant UploadTestRunInfo, and the data from calls to GetRunIterHeaderV/GetRunIterDataV
        * @param suiteResult string from UploadSuiteRun
        * @param data string from GetRunIterHeader & one or more GetRunIterData
        */
       public void UploadTestRunItersV(string runinfoResult, string data)
       {
           NameValueCollection collection = new NameValueCollection();
           collection.Add("action", "new");
           collection.Add("cat", "1");
           collection.Add("suite", "1");
           parseIterParams(runinfoResult, collection);
           collection.Add("data", data);
           client.UploadValues("test.jsp", collection);
       }

       /**
        * Upload test run info (not the actual test data, just the configuration) for the Temperature test.
        * @param suiteResult string from UploadSuiteRun, or a value returned by GetSuiteRunIds()
        * @param data string from GetNewTestRunInfo
        * @return string used in next call
        */
       public string UploadTestRunInfoT(string suiteResult, string data)
       {
           string result = client.DownloadString(uploadSuite + suiteResult + "&tid=2&data=" + data);
           return result;
       }

       /**
        * Call this with the result of the relevant UploadTestRunInfo, and the data from calls to GetRunIterHeaderV/GetRunIterDataV
        * @param suiteResult string from UploadSuiteRun
        * @param data string from GetRunIterHeader & one or more GetRunIterData
        */
       public void UploadTestRunItersT(string runinfoResult, string data)
       {
           NameValueCollection collection = new NameValueCollection();
           collection.Add("action", "new");
           collection.Add("cat", "1");
           collection.Add("suite", "1");
           parseIterParams(runinfoResult, collection);
           collection.Add("data", data);
           client.UploadValues("test.jsp", collection);
       }


    }
}
