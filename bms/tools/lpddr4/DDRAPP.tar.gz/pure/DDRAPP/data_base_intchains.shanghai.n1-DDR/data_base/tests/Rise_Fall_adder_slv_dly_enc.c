//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
void UpdatePhyPerCSTrainingIdx(UInt32 csNum)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=(PHY_PER_CS_TRAINING_INDEX_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(csNum, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_PER_CS_TRAINING_INDEX_OFFSET + (PHY_PER_CS_TRAINING_INDEX_WIDTH-1)), (int)PHY_PER_CS_TRAINING_INDEX_OFFSET), true);
    }
}

void updateMulticast (UInt32 multicast_en)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=( PHY_PER_CS_TRAINING_MULTICAST_EN_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(multicast_en, jtag_dll_mc_reg_read(regaddr, true), (int)( PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET + (PHY_PER_CS_TRAINING_MULTICAST_EN_WIDTH -1)), (int) PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET), true);
    }
}
public UInt32[] temp_reg = new UInt32[4];

void SC_PHY_SNAP_OBS_REGS_0() {
    jtag_dll_mc_reg_write(15,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(15, true),8 + 1 -1,8) ,true);
    jtag_dll_mc_reg_write(271,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(271, true),8 + 1 -1,8) ,true);
    jtag_dll_mc_reg_write(527,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(527, true),8 + 1 -1,8) ,true);
    jtag_dll_mc_reg_write(783,(UInt32)WriteBitsToValue(1,jtag_dll_mc_reg_read(783, true),8 + 1 -1,8) ,true);
}

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(29,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(285,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(541,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(797,true);
}
void Group_read() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);

    SC_PHY_SNAP_OBS_REGS_0();
    read_fn();

    UInt32 temp_obs = 0;

    temp_reg[0] = (UInt32)WriteBitsToValue(0,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(49,true);
    PHY_RDDQS_DQ_0_fall_main_0 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_0_fall_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(1,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(49,true);
    PHY_RDDQS_DQ_1_fall_main_0 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_1_fall_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(2,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(49,true);
    PHY_RDDQS_DQ_2_fall_main_0 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_2_fall_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(3,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(49,true);
    PHY_RDDQS_DQ_3_fall_main_0 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_3_fall_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(4,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(49,true);
    PHY_RDDQS_DQ_4_fall_main_0 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_4_fall_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(5,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(49,true);
    PHY_RDDQS_DQ_5_fall_main_0 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_5_fall_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(6,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(49,true);
    PHY_RDDQS_DQ_6_fall_main_0 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_6_fall_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(7,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(49,true);
    PHY_RDDQS_DQ_7_fall_main_0 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_7_fall_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(0,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(305,true);
    PHY_RDDQS_DQ_0_fall_main_1 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_0_fall_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(1,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(305,true);
    PHY_RDDQS_DQ_1_fall_main_1 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_1_fall_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(2,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(305,true);
    PHY_RDDQS_DQ_2_fall_main_1 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_2_fall_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(3,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(305,true);
    PHY_RDDQS_DQ_3_fall_main_1 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_3_fall_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(4,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(305,true);
    PHY_RDDQS_DQ_4_fall_main_1 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_4_fall_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(5,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(305,true);
    PHY_RDDQS_DQ_5_fall_main_1 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_5_fall_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(6,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(305,true);
    PHY_RDDQS_DQ_6_fall_main_1 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_6_fall_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(7,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(305,true);
    PHY_RDDQS_DQ_7_fall_main_1 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_7_fall_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(0,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(561,true);
    PHY_RDDQS_DQ_0_fall_main_2 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_0_fall_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(1,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(561,true);
    PHY_RDDQS_DQ_1_fall_main_2 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_1_fall_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(2,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(561,true);
    PHY_RDDQS_DQ_2_fall_main_2 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_2_fall_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(3,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(561,true);
    PHY_RDDQS_DQ_3_fall_main_2 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_3_fall_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(4,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(561,true);
    PHY_RDDQS_DQ_4_fall_main_2 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_4_fall_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(5,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(561,true);
    PHY_RDDQS_DQ_5_fall_main_2 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_5_fall_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(6,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(561,true);
    PHY_RDDQS_DQ_6_fall_main_2 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_6_fall_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(7,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(561,true);
    PHY_RDDQS_DQ_7_fall_main_2 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_7_fall_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(0,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(817,true);
    PHY_RDDQS_DQ_0_fall_main_3 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_0_fall_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(1,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(817,true);
    PHY_RDDQS_DQ_1_fall_main_3 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_1_fall_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(2,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(817,true);
    PHY_RDDQS_DQ_2_fall_main_3 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_2_fall_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(3,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(817,true);
    PHY_RDDQS_DQ_3_fall_main_3 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_3_fall_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(4,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(817,true);
    PHY_RDDQS_DQ_4_fall_main_3 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_4_fall_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(5,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(817,true);
    PHY_RDDQS_DQ_5_fall_main_3 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_5_fall_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(6,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(817,true);
    PHY_RDDQS_DQ_6_fall_main_3 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_6_fall_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(7,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(817,true);
    PHY_RDDQS_DQ_7_fall_main_3 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DQ_7_fall_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(8,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(49,true);
    PHY_RDDQS_DM_8_fall_main_0 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DM_8_fall_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(8,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(305,true);
    PHY_RDDQS_DM_8_fall_main_1 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DM_8_fall_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(8,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(561,true);
    PHY_RDDQS_DM_8_fall_main_2 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DM_8_fall_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(8,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(817,true);
    PHY_RDDQS_DM_8_fall_main_3 = (UInt32)GetBitsFromValue(temp_obs, 3 + 4, 3);
    PHY_RDDQS_DM_8_fall_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 2, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(0,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(48,true);
    PHY_RDDQS_DQ_0_rise_main_0 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_0_rise_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[0] = (UInt32)WriteBitsToValue(1,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(48,true);
    PHY_RDDQS_DQ_1_rise_main_0 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_1_rise_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[0] = (UInt32)WriteBitsToValue(2,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(48,true);
    PHY_RDDQS_DQ_2_rise_main_0 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_2_rise_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[0] = (UInt32)WriteBitsToValue(3,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(48,true);
    PHY_RDDQS_DQ_3_rise_main_0 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_3_rise_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[0] = (UInt32)WriteBitsToValue(4,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(48,true);
    PHY_RDDQS_DQ_4_rise_main_0 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_4_rise_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[0] = (UInt32)WriteBitsToValue(5,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(48,true);
    PHY_RDDQS_DQ_5_rise_main_0 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_5_rise_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[0] = (UInt32)WriteBitsToValue(6,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(48,true);
    PHY_RDDQS_DQ_6_rise_main_0 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_6_rise_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[0] = (UInt32)WriteBitsToValue(7,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(48,true);
    PHY_RDDQS_DQ_7_rise_main_0 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_7_rise_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[1] = (UInt32)WriteBitsToValue(0,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(304,true);
    PHY_RDDQS_DQ_0_rise_main_1 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_0_rise_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[1] = (UInt32)WriteBitsToValue(1,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(304,true);
    PHY_RDDQS_DQ_1_rise_main_1 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_1_rise_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[1] = (UInt32)WriteBitsToValue(2,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(304,true);
    PHY_RDDQS_DQ_2_rise_main_1 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_2_rise_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[1] = (UInt32)WriteBitsToValue(3,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(304,true);
    PHY_RDDQS_DQ_3_rise_main_1 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_3_rise_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[1] = (UInt32)WriteBitsToValue(4,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(304,true);
    PHY_RDDQS_DQ_4_rise_main_1 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_4_rise_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[1] = (UInt32)WriteBitsToValue(5,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(304,true);
    PHY_RDDQS_DQ_5_rise_main_1 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_5_rise_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[1] = (UInt32)WriteBitsToValue(6,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(304,true);
    PHY_RDDQS_DQ_6_rise_main_1 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_6_rise_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[1] = (UInt32)WriteBitsToValue(7,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(304,true);
    PHY_RDDQS_DQ_7_rise_main_1 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_7_rise_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[2] = (UInt32)WriteBitsToValue(0,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(560,true);
    PHY_RDDQS_DQ_0_rise_main_2 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_0_rise_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[2] = (UInt32)WriteBitsToValue(1,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(560,true);
    PHY_RDDQS_DQ_1_rise_main_2 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_1_rise_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[2] = (UInt32)WriteBitsToValue(2,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(560,true);
    PHY_RDDQS_DQ_2_rise_main_2 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_2_rise_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[2] = (UInt32)WriteBitsToValue(3,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(560,true);
    PHY_RDDQS_DQ_3_rise_main_2 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_3_rise_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[2] = (UInt32)WriteBitsToValue(4,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(560,true);
    PHY_RDDQS_DQ_4_rise_main_2 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_4_rise_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[2] = (UInt32)WriteBitsToValue(5,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(560,true);
    PHY_RDDQS_DQ_5_rise_main_2 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_5_rise_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[2] = (UInt32)WriteBitsToValue(6,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(560,true);
    PHY_RDDQS_DQ_6_rise_main_2 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_6_rise_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[2] = (UInt32)WriteBitsToValue(7,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(560,true);
    PHY_RDDQS_DQ_7_rise_main_2 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_7_rise_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[3] = (UInt32)WriteBitsToValue(0,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(816,true);
    PHY_RDDQS_DQ_0_rise_main_3 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_0_rise_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[3] = (UInt32)WriteBitsToValue(1,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(816,true);
    PHY_RDDQS_DQ_1_rise_main_3 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_1_rise_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[3] = (UInt32)WriteBitsToValue(2,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(816,true);
    PHY_RDDQS_DQ_2_rise_main_3 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_2_rise_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[3] = (UInt32)WriteBitsToValue(3,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(816,true);
    PHY_RDDQS_DQ_3_rise_main_3 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_3_rise_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[3] = (UInt32)WriteBitsToValue(4,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(816,true);
    PHY_RDDQS_DQ_4_rise_main_3 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_4_rise_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[3] = (UInt32)WriteBitsToValue(5,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(816,true);
    PHY_RDDQS_DQ_5_rise_main_3 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_5_rise_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[3] = (UInt32)WriteBitsToValue(6,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(816,true);
    PHY_RDDQS_DQ_6_rise_main_3 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_6_rise_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[3] = (UInt32)WriteBitsToValue(7,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(816,true);
    PHY_RDDQS_DQ_7_rise_main_3 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DQ_7_rise_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[0] = (UInt32)WriteBitsToValue(8,temp_reg[0],0 + 4 -1,0);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(48,true);
    PHY_RDDQS_DM_8_rise_main_0 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DM_8_rise_qtr_0 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[1] = (UInt32)WriteBitsToValue(8,temp_reg[1],0 + 4 -1,0);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(304,true);
    PHY_RDDQS_DM_8_rise_main_1 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DM_8_rise_qtr_1 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[2] = (UInt32)WriteBitsToValue(8,temp_reg[2],0 + 4 -1,0);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(560,true);
    PHY_RDDQS_DM_8_rise_main_2 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DM_8_rise_qtr_2 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);

    temp_reg[3] = (UInt32)WriteBitsToValue(8,temp_reg[3],0 + 4 -1,0);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(816,true);
    PHY_RDDQS_DM_8_rise_main_3 = (UInt32)GetBitsFromValue(temp_obs, 27 + 4, 27);
    PHY_RDDQS_DM_8_rise_qtr_3 = (UInt32)GetBitsFromValue(temp_obs, 24 + 2, 24);


    updateMulticast(1);
}
void Group_write() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    jtag_dll_mc_reg_write(29, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(285, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(541, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(797, temp_reg[3] ,true);

    updateMulticast(1);
}
