// This file deifines the global variables
// These variables will be used across multiple tabs
UInt32 debug_lvl_slice_0 = 0;
UInt32 debug_lvl_slice_1 = 0x0;
ulong DDR_CTRL_BASE_ADDRESS = 0xc3000000;
ulong DDR_PI_BASE_ADDRESS = 0xc3000800;
ulong DDR_PHY_BASE_ADDRESS = 0xc3001000 ;
String gctrl_file_path = "./data_base/regconfig/LPDDR4/mt53e1g32d2_046_CTL_BL16_CL20_1066MHz";
String gpi_file_path = "./data_base/regconfig/LPDDR4/mt53e1g32d2_046_PI_BL16_CL20_1066MHz";
String gphy_file_path = "./data_base/regconfig/LPDDR4/MT53E2G32D4DE-046_PHY_BL16_CL10_533MHz";
ulong data_value_from_file = 0;
UInt32 from_regconfig_file = 0;
int AardvarkHandle = -1;
int AarkvarkI2CBitrate_KHz = 200;
UInt32 gDDR_inst = 0;
//float step_volts_wiper_pll_vdd = 0;
ulong DDR_CLKGEN_BASE = 0xc2f08000;
ulong DDR_SIDEBAND_ADDRESS = 0xc3008000;
ulong DDR_PHY_ADDRESS = 0xc3004000;
