//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[24];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(13,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(269,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(525,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(781,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(32,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(288,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(544,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(800,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(33,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(289,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(545,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(801,true);
    temp_reg[12] = (UInt32)jtag_dll_mc_reg_read(108,true);
    temp_reg[13] = (UInt32)jtag_dll_mc_reg_read(364,true);
    temp_reg[14] = (UInt32)jtag_dll_mc_reg_read(620,true);
    temp_reg[15] = (UInt32)jtag_dll_mc_reg_read(876,true);
    temp_reg[16] = (UInt32)jtag_dll_mc_reg_read(107,true);
    temp_reg[17] = (UInt32)jtag_dll_mc_reg_read(363,true);
    temp_reg[18] = (UInt32)jtag_dll_mc_reg_read(619,true);
    temp_reg[19] = (UInt32)jtag_dll_mc_reg_read(875,true);
    temp_reg[20] = (UInt32)jtag_dll_mc_reg_read(134,true);
    temp_reg[21] = (UInt32)jtag_dll_mc_reg_read(390,true);
    temp_reg[22] = (UInt32)jtag_dll_mc_reg_read(646,true);
    temp_reg[23] = (UInt32)jtag_dll_mc_reg_read(902,true);
}
void Group_read() {
    read_fn();

    PHY_RDLVL_MULTI_PATT_RST_DISABLE_0 = (UInt32)GetBitsFromValue(temp_reg[0],24+(1-1),24);
    PHY_RDLVL_MULTI_PATT_RST_DISABLE_1 = (UInt32)GetBitsFromValue(temp_reg[1],24+(1-1),24);
    PHY_RDLVL_MULTI_PATT_RST_DISABLE_2 = (UInt32)GetBitsFromValue(temp_reg[2],24+(1-1),24);
    PHY_RDLVL_MULTI_PATT_RST_DISABLE_3 = (UInt32)GetBitsFromValue(temp_reg[3],24+(1-1),24);
    PHY_RDLVL_MULTI_PATT_ENABLE_0 = (UInt32)GetBitsFromValue(temp_reg[0],16+(1-1),16);
    PHY_RDLVL_MULTI_PATT_ENABLE_1 = (UInt32)GetBitsFromValue(temp_reg[1],16+(1-1),16);
    PHY_RDLVL_MULTI_PATT_ENABLE_2 = (UInt32)GetBitsFromValue(temp_reg[2],16+(1-1),16);
    PHY_RDLVL_MULTI_PATT_ENABLE_3 = (UInt32)GetBitsFromValue(temp_reg[3],16+(1-1),16);
    PHY_RDLVL_CAPTURE_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[4],0+(6-1),0);
    PHY_RDLVL_CAPTURE_CNT_1 = (UInt32)GetBitsFromValue(temp_reg[5],0+(6-1),0);
    PHY_RDLVL_CAPTURE_CNT_2 = (UInt32)GetBitsFromValue(temp_reg[6],0+(6-1),0);
    PHY_RDLVL_CAPTURE_CNT_3 = (UInt32)GetBitsFromValue(temp_reg[7],0+(6-1),0);
    PHY_RDLVL_DATA_MASK_0 = (UInt32)GetBitsFromValue(temp_reg[8],0+(8-1),0);
    PHY_RDLVL_DATA_MASK_1 = (UInt32)GetBitsFromValue(temp_reg[9],0+(8-1),0);
    PHY_RDLVL_DATA_MASK_2 = (UInt32)GetBitsFromValue(temp_reg[10],0+(8-1),0);
    PHY_RDLVL_DATA_MASK_3 = (UInt32)GetBitsFromValue(temp_reg[11],0+(8-1),0);
    PHY_RDLVL_MAX_EDGE_0 = (UInt32)GetBitsFromValue(temp_reg[12],0+(10-1),0);
    PHY_RDLVL_MAX_EDGE_1 = (UInt32)GetBitsFromValue(temp_reg[13],0+(10-1),0);
    PHY_RDLVL_MAX_EDGE_2 = (UInt32)GetBitsFromValue(temp_reg[14],0+(10-1),0);
    PHY_RDLVL_MAX_EDGE_3 = (UInt32)GetBitsFromValue(temp_reg[15],0+(10-1),0);
    PHY_RDLVL_DLY_STEP_0 = (UInt32)GetBitsFromValue(temp_reg[16],8+(4-1),8);
    PHY_RDLVL_DLY_STEP_1 = (UInt32)GetBitsFromValue(temp_reg[17],8+(4-1),8);
    PHY_RDLVL_DLY_STEP_2 = (UInt32)GetBitsFromValue(temp_reg[18],8+(4-1),8);
    PHY_RDLVL_DLY_STEP_3 = (UInt32)GetBitsFromValue(temp_reg[19],8+(4-1),8);
    PHY_RDLVL_OP_MODE_0 = (UInt32)GetBitsFromValue(temp_reg[4],16+(2-1),16);
    PHY_RDLVL_OP_MODE_1 = (UInt32)GetBitsFromValue(temp_reg[5],16+(2-1),16);
    PHY_RDLVL_OP_MODE_2 = (UInt32)GetBitsFromValue(temp_reg[6],16+(2-1),16);
    PHY_RDLVL_OP_MODE_3 = (UInt32)GetBitsFromValue(temp_reg[7],16+(2-1),16);
    PHY_RDLVL_RDDQS_DQ_SLV_DLY_START_0 = (UInt32)GetBitsFromValue(temp_reg[20],0+(10-1),0);
    PHY_RDLVL_RDDQS_DQ_SLV_DLY_START_1 = (UInt32)GetBitsFromValue(temp_reg[21],0+(10-1),0);
    PHY_RDLVL_RDDQS_DQ_SLV_DLY_START_2 = (UInt32)GetBitsFromValue(temp_reg[22],0+(10-1),0);
    PHY_RDLVL_RDDQS_DQ_SLV_DLY_START_3 = (UInt32)GetBitsFromValue(temp_reg[23],0+(10-1),0);
    PHY_RDLVL_UPDT_WAIT_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[4],8+(4-1),8);
    PHY_RDLVL_UPDT_WAIT_CNT_1 = (UInt32)GetBitsFromValue(temp_reg[5],8+(4-1),8);
    PHY_RDLVL_UPDT_WAIT_CNT_2 = (UInt32)GetBitsFromValue(temp_reg[6],8+(4-1),8);
    PHY_RDLVL_UPDT_WAIT_CNT_3 = (UInt32)GetBitsFromValue(temp_reg[7],8+(4-1),8);
    PHY_RDLVL_DATA_SWIZZLE_0 = (UInt32)GetBitsFromValue(temp_reg[8],8+(18-1),8);
    PHY_RDLVL_DATA_SWIZZLE_1 = (UInt32)GetBitsFromValue(temp_reg[9],8+(18-1),8);
    PHY_RDLVL_DATA_SWIZZLE_2 = (UInt32)GetBitsFromValue(temp_reg[10],8+(18-1),8);
    PHY_RDLVL_DATA_SWIZZLE_3 = (UInt32)GetBitsFromValue(temp_reg[11],8+(18-1),8);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_RDLVL_MULTI_PATT_RST_DISABLE_0, temp_reg[0] ,24+(1-1),24);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_RDLVL_MULTI_PATT_RST_DISABLE_1, temp_reg[1] ,24+(1-1),24);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_RDLVL_MULTI_PATT_RST_DISABLE_2, temp_reg[2] ,24+(1-1),24);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_RDLVL_MULTI_PATT_RST_DISABLE_3, temp_reg[3] ,24+(1-1),24);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_RDLVL_MULTI_PATT_ENABLE_0, temp_reg[0] ,16+(1-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_RDLVL_MULTI_PATT_ENABLE_1, temp_reg[1] ,16+(1-1),16);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_RDLVL_MULTI_PATT_ENABLE_2, temp_reg[2] ,16+(1-1),16);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_RDLVL_MULTI_PATT_ENABLE_3, temp_reg[3] ,16+(1-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_RDLVL_CAPTURE_CNT_0, temp_reg[4] ,0+(6-1),0);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_RDLVL_CAPTURE_CNT_1, temp_reg[5] ,0+(6-1),0);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_RDLVL_CAPTURE_CNT_2, temp_reg[6] ,0+(6-1),0);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_RDLVL_CAPTURE_CNT_3, temp_reg[7] ,0+(6-1),0);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_RDLVL_DATA_MASK_0, temp_reg[8] ,0+(8-1),0);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_RDLVL_DATA_MASK_1, temp_reg[9] ,0+(8-1),0);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_RDLVL_DATA_MASK_2, temp_reg[10] ,0+(8-1),0);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_RDLVL_DATA_MASK_3, temp_reg[11] ,0+(8-1),0);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_RDLVL_MAX_EDGE_0, temp_reg[12] ,0+(10-1),0);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_RDLVL_MAX_EDGE_1, temp_reg[13] ,0+(10-1),0);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_RDLVL_MAX_EDGE_2, temp_reg[14] ,0+(10-1),0);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_RDLVL_MAX_EDGE_3, temp_reg[15] ,0+(10-1),0);
    temp_reg[16] = (UInt32)WriteBitsToValue(PHY_RDLVL_DLY_STEP_0, temp_reg[16] ,8+(4-1),8);
    temp_reg[17] = (UInt32)WriteBitsToValue(PHY_RDLVL_DLY_STEP_1, temp_reg[17] ,8+(4-1),8);
    temp_reg[18] = (UInt32)WriteBitsToValue(PHY_RDLVL_DLY_STEP_2, temp_reg[18] ,8+(4-1),8);
    temp_reg[19] = (UInt32)WriteBitsToValue(PHY_RDLVL_DLY_STEP_3, temp_reg[19] ,8+(4-1),8);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_RDLVL_OP_MODE_0, temp_reg[4] ,16+(2-1),16);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_RDLVL_OP_MODE_1, temp_reg[5] ,16+(2-1),16);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_RDLVL_OP_MODE_2, temp_reg[6] ,16+(2-1),16);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_RDLVL_OP_MODE_3, temp_reg[7] ,16+(2-1),16);
    temp_reg[20] = (UInt32)WriteBitsToValue(PHY_RDLVL_RDDQS_DQ_SLV_DLY_START_0, temp_reg[20] ,0+(10-1),0);
    temp_reg[21] = (UInt32)WriteBitsToValue(PHY_RDLVL_RDDQS_DQ_SLV_DLY_START_1, temp_reg[21] ,0+(10-1),0);
    temp_reg[22] = (UInt32)WriteBitsToValue(PHY_RDLVL_RDDQS_DQ_SLV_DLY_START_2, temp_reg[22] ,0+(10-1),0);
    temp_reg[23] = (UInt32)WriteBitsToValue(PHY_RDLVL_RDDQS_DQ_SLV_DLY_START_3, temp_reg[23] ,0+(10-1),0);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_RDLVL_UPDT_WAIT_CNT_0, temp_reg[4] ,8+(4-1),8);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_RDLVL_UPDT_WAIT_CNT_1, temp_reg[5] ,8+(4-1),8);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_RDLVL_UPDT_WAIT_CNT_2, temp_reg[6] ,8+(4-1),8);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_RDLVL_UPDT_WAIT_CNT_3, temp_reg[7] ,8+(4-1),8);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_RDLVL_DATA_SWIZZLE_0, temp_reg[8] ,8+(18-1),8);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_RDLVL_DATA_SWIZZLE_1, temp_reg[9] ,8+(18-1),8);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_RDLVL_DATA_SWIZZLE_2, temp_reg[10] ,8+(18-1),8);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_RDLVL_DATA_SWIZZLE_3, temp_reg[11] ,8+(18-1),8);
    jtag_dll_mc_reg_write(13, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(269, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(525, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(781, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(32, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(288, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(544, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(800, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(33, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(289, temp_reg[9] ,true);
    jtag_dll_mc_reg_write(545, temp_reg[10] ,true);
    jtag_dll_mc_reg_write(801, temp_reg[11] ,true);
    jtag_dll_mc_reg_write(108, temp_reg[12] ,true);
    jtag_dll_mc_reg_write(364, temp_reg[13] ,true);
    jtag_dll_mc_reg_write(620, temp_reg[14] ,true);
    jtag_dll_mc_reg_write(876, temp_reg[15] ,true);
    jtag_dll_mc_reg_write(107, temp_reg[16] ,true);
    jtag_dll_mc_reg_write(363, temp_reg[17] ,true);
    jtag_dll_mc_reg_write(619, temp_reg[18] ,true);
    jtag_dll_mc_reg_write(875, temp_reg[19] ,true);
    jtag_dll_mc_reg_write(134, temp_reg[20] ,true);
    jtag_dll_mc_reg_write(390, temp_reg[21] ,true);
    jtag_dll_mc_reg_write(646, temp_reg[22] ,true);
    jtag_dll_mc_reg_write(902, temp_reg[23] ,true);
}
