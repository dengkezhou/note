//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[4];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(1041,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(1046,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(1290,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(1291,true);
}
void Group_read(ulong channel_num) {
    read_fn();

    UInt32 temp_obs = 0;

    temp_reg[0] = (UInt32)WriteBitsToValue(0,temp_reg[0],24 + 3 -1,24);
    jtag_dll_mc_reg_write(1041, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(1042+channel_num,true);
    calvl_pattern_cmp_range0_0 = (UInt32)GetBitsFromValue(temp_obs, 29 + 0, 29);
    left_found_0_0 = (UInt32)GetBitsFromValue(temp_obs, 28 + 0, 28);
    delay_left_0_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);
    right_found_0_0 = (UInt32)GetBitsFromValue(temp_obs, 12 + 0, 12);
    delay_right_0_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(1,temp_reg[0],24 + 3 -1,24);
    jtag_dll_mc_reg_write(1041, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(1042+channel_num,true);
    calvl_pattern_cmp_range1_0 = (UInt32)GetBitsFromValue(temp_obs, 29 + 0, 29);
    left_found_1_0 = (UInt32)GetBitsFromValue(temp_obs, 28 + 0, 28);
    delay_left_1_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);
    right_found_1_0 = (UInt32)GetBitsFromValue(temp_obs, 12 + 0, 12);
    delay_right_1_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(2,temp_reg[0],24 + 3 -1,24);
    jtag_dll_mc_reg_write(1041, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(1042+channel_num,true);
    calvl_pattern_cmp_range2_0 = (UInt32)GetBitsFromValue(temp_obs, 29 + 0, 29);
    left_found_2_0 = (UInt32)GetBitsFromValue(temp_obs, 28 + 0, 28);
    delay_left_2_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);
    right_found_2_0 = (UInt32)GetBitsFromValue(temp_obs, 12 + 0, 12);
    delay_right_2_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(3,temp_reg[0],24 + 3 -1,24);
    jtag_dll_mc_reg_write(1041, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(1042+channel_num,true);
    calvl_pattern_cmp_range3_0 = (UInt32)GetBitsFromValue(temp_obs, 29 + 0, 29);
    left_found_3_0 = (UInt32)GetBitsFromValue(temp_obs, 28 + 0, 28);
    delay_left_3_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);
    right_found_3_0 = (UInt32)GetBitsFromValue(temp_obs, 12 + 0, 12);
    delay_right_3_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(4,temp_reg[0],24 + 3 -1,24);
    jtag_dll_mc_reg_write(1041, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(1042+channel_num,true);
    calvl_pattern_cmp_range4_0 = (UInt32)GetBitsFromValue(temp_obs, 29 + 0, 29);
    left_found_4_0 = (UInt32)GetBitsFromValue(temp_obs, 28 + 0, 28);
    delay_left_4_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);
    right_found_4_0 = (UInt32)GetBitsFromValue(temp_obs, 12 + 0, 12);
    delay_right_4_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(5,temp_reg[0],24 + 3 -1,24);
    jtag_dll_mc_reg_write(1041, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(1042+channel_num,true);
    calvl_pattern_cmp_range5_0 = (UInt32)GetBitsFromValue(temp_obs, 29 + 0, 29);
    left_found_5_0 = (UInt32)GetBitsFromValue(temp_obs, 28 + 0, 28);
    delay_left_5_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);
    right_found_5_0 = (UInt32)GetBitsFromValue(temp_obs, 12 + 0, 12);
    delay_right_5_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    calvl_obs_error_inc_0 = (UInt32)GetBitsFromValue(temp_reg[1],31+(1-1),31);
    calvl_obs_error_dec_0 = (UInt32)GetBitsFromValue(temp_reg[1],30+(1-1),30);
    ca_add_occured_0 = (UInt32)GetBitsFromValue(temp_reg[1],15+(1-1),15);
    first_segment_done_0 = (UInt32)GetBitsFromValue(temp_reg[1],14+(1-1),14);
    first_capture_0 = (UInt32)GetBitsFromValue(temp_reg[1],13+(1-1),13);
    any_lanes_good_0 = (UInt32)GetBitsFromValue(temp_reg[1],11+(1-1),11);
    finding_coarse_0 = (UInt32)GetBitsFromValue(temp_reg[1],8+(1-1),8);
    finding_left_0 = (UInt32)GetBitsFromValue(temp_reg[1],7+(1-1),7);
    finding_right_0 = (UInt32)GetBitsFromValue(temp_reg[1],6+(1-1),6);
    calvl_state_pre_0 = (UInt32)GetBitsFromValue(temp_reg[1],0+(4-1),0);
    left_found_0 = (UInt32)GetBitsFromValue(temp_reg[2],28+(1-1),28);
    delay_left_0 = (UInt32)GetBitsFromValue(temp_reg[2],16+(11-1),16);
    right_found_0 = (UInt32)GetBitsFromValue(temp_reg[2],12+(1-1),12);
    delay_right_0 = (UInt32)GetBitsFromValue(temp_reg[2],0+(11-1),0);
    cslvl_obs_error_inc_0 = (UInt32)GetBitsFromValue(temp_reg[3],31+(1-1),31);
    cslvl_obs_error_dec_0 = (UInt32)GetBitsFromValue(temp_reg[3],30+(1-1),30);
    cslvl_obs_error_ca_0 = (UInt32)GetBitsFromValue(temp_reg[3],29+(1-1),29);
    cslvl_sm_error_0 = (UInt32)GetBitsFromValue(temp_reg[3],28+(1-1),28);
    cslvl_obs_error_ca_tot_0 = (UInt32)GetBitsFromValue(temp_reg[3],27+(1-1),27);
    cslvl_ca_add_flag_0 = (UInt32)GetBitsFromValue(temp_reg[3],23+(1-1),23);
    calvl_en_coarse_0 = (UInt32)GetBitsFromValue(temp_reg[3],22+(1-1),22);
    ignore_capture_0 = (UInt32)GetBitsFromValue(temp_reg[3],21+(1-1),21);
    outer_loop_0 = (UInt32)GetBitsFromValue(temp_reg[3],18+(3-1),18);
    inner_loop_0 = (UInt32)GetBitsFromValue(temp_reg[3],13+(5-1),13);
    second_capture_0 = (UInt32)GetBitsFromValue(temp_reg[3],12+(1-1),12);
    cs_first_capture_0 = (UInt32)GetBitsFromValue(temp_reg[3],11+(1-1),11);
    pattern_good_0 = (UInt32)GetBitsFromValue(temp_reg[3],10+(1-1),10);
    cslvl_pattern_cmp_0 = (UInt32)GetBitsFromValue(temp_reg[3],9+(1-1),9);
    cs_finding_coarse_0 = (UInt32)GetBitsFromValue(temp_reg[3],8+(1-1),8);
    cs_finding_left_0 = (UInt32)GetBitsFromValue(temp_reg[3],7+(1-1),7);
    cs_finding_right_0 = (UInt32)GetBitsFromValue(temp_reg[3],6+(1-1),6);
    cslvl_left_found_0 = (UInt32)GetBitsFromValue(temp_reg[3],5+(1-1),5);
    cslvl_right_found_0 = (UInt32)GetBitsFromValue(temp_reg[3],4+(1-1),4);
    cslvl_state_pre_0 = (UInt32)GetBitsFromValue(temp_reg[3],0+(4-1),0);
}
void Group_write() {
    jtag_dll_mc_reg_write(1041, temp_reg[0] ,true);
}

UInt32 sample_count = 0;

void pi_int_status_read()
{
	LVL_DONE    =  (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR),(int)PI_LVL_DONE_BIT,(int)PI_LVL_DONE_BIT);
	CALVL_REQ   =  (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR),(int)PI_CALVL_REQ_BIT,(int)PI_CALVL_REQ_BIT);
	CALVL_ERROR =  (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR),(int)PI_CALVL_ERROR_BIT,(int)PI_CALVL_ERROR_BIT);
}

void pi_int_ack()
{
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_INT_ACK_ADDR),(int)PI_LVL_DONE_BIT,(int)PI_LVL_DONE_BIT));
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_INT_ACK_ADDR),(int)PI_CALVL_REQ_BIT,(int)PI_CALVL_REQ_BIT));
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_INT_ACK_ADDR),(int)PI_CALVL_ERROR_BIT,(int)PI_CALVL_ERROR_BIT));
}

void pi_calvl_en_top(ulong channel_num, ulong slice_num)
{
	pi_calvl_en(channel_num, slice_num);
	if (LVL_DONE== 1) print_message ("PI-Initiated CA Training Completed \n");
	else print_message ("PI-Initiated CA Training Failed \n");
	pi_int_ack();
	clear_prev(slice_num);
}

public void pi_calvl_en(ulong channel_num, ulong slice_num)
{
	jtag_dll_pi_reg_write(PI_CALVL_EN_F0_ADDR,WriteBitsToValue(2,jtag_dll_pi_reg_read(PI_CALVL_EN_F0_ADDR),(int)(PI_CALVL_EN_F0_OFFSET + (PI_CALVL_EN_F0_WIDTH-1)),(int)(PI_CALVL_EN_F0_OFFSET))); 	// PI_CALVL_EN_F0
	jtag_dll_pi_reg_write(PI_CALVL_EN_F1_ADDR,WriteBitsToValue(2,jtag_dll_pi_reg_read(PI_CALVL_EN_F1_ADDR),(int)(PI_CALVL_EN_F1_OFFSET + (PI_CALVL_EN_F1_WIDTH-1)),(int)(PI_CALVL_EN_F1_OFFSET))); 	// PI_CALVL_EN_F1
	jtag_dll_pi_reg_write(PI_CALVL_EN_F2_ADDR,WriteBitsToValue(2,jtag_dll_pi_reg_read(PI_CALVL_EN_F2_ADDR),(int)(PI_CALVL_EN_F2_OFFSET + (PI_CALVL_EN_F2_WIDTH-1)),(int)(PI_CALVL_EN_F2_OFFSET))); 	// PI_CALVL_EN_F2

	jtag_dll_pi_reg_write(PI_CALVL_CS_SW_ADDR,WriteBitsToValue(lvl_cs,jtag_dll_pi_reg_read(PI_CALVL_CS_SW_ADDR),(int)(PI_CALVL_CS_SW_OFFSET + (PI_CALVL_CS_SW_WIDTH-1)),(int)(PI_CALVL_CS_SW_OFFSET))); // PI_CALVL_CS
	jtag_dll_pi_reg_write(PI_CALVL_REQ_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_CALVL_REQ_ADDR),(int)(PI_CALVL_REQ_OFFSET + (PI_CALVL_REQ_WIDTH-1)),(int)(PI_CALVL_REQ_OFFSET))); // PI_CALVL_REQ
	print_message ("PI-Initiated Training  CA in progress  \n");

	Thread.Sleep(500);
	pi_int_status_read();
	Group_read(channel_num);
}

void start_debug(ulong channel_num, ulong slice_num)
{
	sample_count = 1;

	//jtag_dll_mc_reg_write(PHY_ADR_CALVL_DEBUG_MODE_ADDR + (HS_SLICE_REG_COUNT * slice_num),WriteBitsToValue(1,jtag_dll_mc_reg_read(PHY_ADR_CALVL_DEBUG_MODE_ADDR + (HS_SLICE_REG_COUNT * slice_num),true),(int)PHY_ADR_CALVL_DEBUG_MODE_OFFSET,(int)PHY_ADR_CALVL_DEBUG_MODE_OFFSET),true);
	// cs lvl debug
	jtag_dll_mc_reg_write(PHY_CSLVL_DEBUG_MODE_ADDR,WriteBitsToValue(1,jtag_dll_mc_reg_read(PHY_CSLVL_DEBUG_MODE_ADDR, true),(int)PHY_CSLVL_DEBUG_MODE_OFFSET,(int)PHY_CSLVL_DEBUG_MODE_OFFSET),true);

	pi_calvl_en(channel_num, slice_num);
	pi_int_ack();
	Group_read(channel_num);
	Thread.Sleep(200);
	print_message ("\n Running CA Training in debug mode. \nAnalysed result for sample_count = 1 \n");
}

void stop_debug(ulong slice_num)
{
	//jtag_dll_mc_reg_write(PHY_ADR_CALVL_DEBUG_MODE_ADDR + (HS_SLICE_REG_COUNT * slice_num),WriteBitsToValue(0,jtag_dll_mc_reg_read(PHY_ADR_CALVL_DEBUG_MODE_ADDR + (HS_SLICE_REG_COUNT * slice_num),true),(int)PHY_ADR_CALVL_DEBUG_MODE_OFFSET,(int)PHY_ADR_CALVL_DEBUG_MODE_OFFSET),true);
	print_message("Debug mode Disabled \n");
	pi_int_ack();
	clear_prev(slice_num);
}

void debug_cont(ulong channel_num, ulong slice_num)
{
	if (LVL_DONE == 0)
	{
		// cs continue
		jtag_dll_mc_reg_write(SC_PHY_CSLVL_DEBUG_CONT_ADDR,WriteBitsToValue(1,jtag_dll_mc_reg_read(SC_PHY_CSLVL_DEBUG_CONT_ADDR, true),(int)24,(int)24),true);
		//jtag_dll_mc_reg_write(SC_PHY_ADR_CALVL_DEBUG_CONT_ADDR + (HS_SLICE_REG_COUNT * slice_num),WriteBitsToValue(1,jtag_dll_mc_reg_read(SC_PHY_ADR_CALVL_DEBUG_CONT_ADDR + (HS_SLICE_REG_COUNT * slice_num),true),(int)SC_PHY_ADR_CALVL_DEBUG_CONT_OFFSET,(int)SC_PHY_ADR_CALVL_DEBUG_CONT_OFFSET),true);
		pi_int_status_read();
		Group_read(channel_num);
		sample_count = sample_count + 1;
		print_message("Analysed result for sample_count = " +sample_count.ToString() + "\n");
	}
	else
	{
		print_message("CA training completed in debug mode \n");
		stop_debug(slice_num);
	}
}

void clear_prev(ulong slice_num)
{
	//ulong regaddr = (SC_PHY_ADR_CALVL_ERROR_CLR_ADDR + (HS_SLICE_REG_COUNT * slice_num));
	//jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(1, jtag_dll_mc_reg_read(regaddr,true), (int)SC_PHY_ADR_CALVL_ERROR_CLR_OFFSET, (int)SC_PHY_ADR_CALVL_ERROR_CLR_OFFSET), true);
}
