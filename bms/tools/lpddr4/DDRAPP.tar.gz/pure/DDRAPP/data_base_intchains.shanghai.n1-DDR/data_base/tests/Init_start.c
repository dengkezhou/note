//****************************************************************************************
//                       © 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence’s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/

void ddr_clksrc_select(UInt32 clksrc_select){
	ulong reg_val;

	reg_val = (ulong)((UInt32)jtag_clock_reg_read(CLKGEN_CLKSRC_SELECT_ADDR) & (~0xf)) |(clksrc_select);//0:apll 1:dpll 2:epll 3:vpll 4:mosc_clk
	jtag_clock_reg_write(CLKGEN_CLKSRC_SELECT_ADDR,reg_val);

}

void vpll_ratio_change(UInt32 freq){
	ulong reg_val = 0;

	if(freq == 2133){
		jtag_clock_reg_write(CLK_RATIO_ADDR + 0xc0,0x0);
	}
	else if(freq == 1066){
		jtag_clock_reg_write(CLK_RATIO_ADDR + 0xc0,0x1);
	}
	else if(freq == 533){
		jtag_clock_reg_write(CLK_RATIO_ADDR + 0xc0,0x3);
	}else{
		print_message("LPDDR4 freq set error\n");
	}

	while(reg_val != 0x1){
		reg_val = (ulong)((UInt32)jtag_clock_reg_read(CLKGEN_VLOCK_ADDR) & 0x1);
	}
}

/*Freq. shift handing, customer specific implementation*/
void ddr_handle_phy_freq_change_request(){
	// TBD: Cumstomer implementation here
	UInt32 freq_change_req = 0;
	UInt32 freq_change_req_type = 4;
	UInt32 pll_lock = 0;
	UInt32 reg_value;
	UInt32 monitor_source = 0;
	UInt32 monitor_func = 1;

	//reg_value = ((UInt32)jtag_dll_mc_reg_read(0x000021cc)&(0x0))|(monitor_func<<8)|(monitor_source);
    //jtag_dll_mc_reg_write(0x000021cc,reg_value);

//print_message("----xxddr change req 00----\n");
	freq_change_req = (UInt32)(jtag_sideband_reg_read(0x00000014)>>21)&(0x1);
	if(freq_change_req != 0){
		//print_message("----ddr change req 11----\n");
		freq_change_req_type = (UInt32)(jtag_sideband_reg_read(0x00000014)>>16)&(0x1f);
		if(freq_change_req_type == 0){
			jtag_clock_reg_write(0x13c,0xffff);
			//vpll_ratio_change(1066);//2_div
			jtag_clock_reg_write(CLK_RATIO_ADDR + 0xc0,  29);
			ddr_clksrc_select(1);
			//ddr_clksrc_select(4);//mosc:24Mhz
			jtag_clock_reg_write(0x13c, 0x0000);
			jtag_sideband_reg_write(0x00000004,0x2);
			//Thread.Sleep(1);
			jtag_sideband_reg_write(0x00000004,0x0);
			//while (pll_lock == 0){
			//	pll_lock = (UInt32)jtag_phy_reg_read(PHY_PLL_OBS_0_ADDR) & 0x1;
			//}
			pll_lock = 0;
			print_message("change freq to 50Mhz\n");
		}else if(freq_change_req_type == 1){
			jtag_clock_reg_write(0x13c,0xffff);
			vpll_ratio_change(533);//dram clock = Mbps/2
			ddr_clksrc_select(3);//vpll:2133
			jtag_clock_reg_write(0x13c,0x0000);
			jtag_sideband_reg_write(0x00000004,0x2);
			//Thread.Sleep(1);
			jtag_sideband_reg_write(0x00000004,0x0);
			//while (pll_lock == 0){
			//	pll_lock = (UInt32)jtag_phy_reg_read(PHY_PLL_OBS_0_ADDR) & 0x1;
			//}
			pll_lock = 0;
			print_message("change freq to 533Mhz\n");
		}else if(freq_change_req_type == 2){
			jtag_clock_reg_write(0x13c, 0xffff);
			vpll_ratio_change(1066);//
			ddr_clksrc_select(3);//mosc:24Mhzsssss
			jtag_clock_reg_write(0x13c,0x0000);
			jtag_sideband_reg_write(0x00000004,0x2);
			//Thread.Sleep(1);
			jtag_sideband_reg_write(0x00000004,0x0);
			//while (pll_lock == 0){
			//	pll_lock = (UInt32)jtag_phy_reg_read(PHY_PLL_OBS_0_ADDR) & 0x1;
			//}
			pll_lock = 0;
			print_message("change freq to 1066Mhz\n");
		}else{
			print_message("freq_change_req_type err\n");
		}
	}
}

int CheckLockStatus()
{
	ulong lck_0 = GetBitsFromValue(jtag_dll_mc_reg_read(PHY_PLL_OBS_0_ADDR, true), (int)PHY_PLL_OBS_0_OFFSET,(int)PHY_PLL_OBS_0_OFFSET);
	ulong lck_1 = GetBitsFromValue(jtag_dll_mc_reg_read(PHY_PLL_OBS_1_ADDR, true), (int)PHY_PLL_OBS_1_OFFSET,(int)PHY_PLL_OBS_1_OFFSET);
	//ulong lck_2 = GetBitsFromValue(jtag_dll_mc_reg_read(PHY_PLL_OBS_2_ADDR, true), (int)PHY_PLL_OBS_2_OFFSET,(int)PHY_PLL_OBS_2_OFFSET);
	
	if((lck_0 != 1) || (lck_1 != 1) )
	{
		print_message("De-Skew PLL failed to lock \n");
		print_message("\tlck_0 = " + lck_0.ToString());
		print_message("\tlck_1 = " + lck_1.ToString());	
		//print_message("\tlck_2 = " + lck_2.ToString());
	
		return 0;
	}

	ulong ready_0 = GetBitsFromValue(jtag_dll_mc_reg_read(PHY_PLL_OBS_0_ADDR, true), (int)(PHY_PLL_OBS_0_OFFSET+1),(int)(PHY_PLL_OBS_0_OFFSET+1));
	ulong ready_1 = GetBitsFromValue(jtag_dll_mc_reg_read(PHY_PLL_OBS_1_ADDR, true), (int)(PHY_PLL_OBS_1_OFFSET+1),(int)(PHY_PLL_OBS_1_OFFSET+1));
	//ulong ready_2 = GetBitsFromValue(jtag_dll_mc_reg_read(PHY_PLL_OBS_2_ADDR, true), (int)(PHY_PLL_OBS_2_OFFSET+1),(int)(PHY_PLL_OBS_2_OFFSET+1));
		
	if((ready_0 != 1) || (ready_1 != 1) )
	{
		print_message("De-Skew PLL not ready \n");
		print_message("\tready_0 = " + ready_0.ToString());	
		print_message("\tready_1 = " + ready_1.ToString());	
		//print_message("\tready_2 = " + ready_2.ToString());	
		return 0;
	}

	print_message("De-Skew PLL locked and ready \n");
	return 1;
}

void set_ddr_reset()
{
	// TBD: Add customer specific DDR reset code here.
}


void set_ddr_pll(UInt32 speed) // speed is DRAM0 clock
{
	// TBD: Add customer specific PLL code here. Based on speed update div and frac setting.
}



// other start up routines (if any)
void startup_routines()
{	
	set_ddr_reset();
	set_ddr_pll(DDR_freq_f2);
	
	/*Other Customer specific implementation*/
}

void update_FSP_parameters(UInt32 mr13_data, UInt32 fsp_op_current, UInt32 fsp_wr_current, UInt32 dfs_always_write_fsp, UInt32 fsp_phy_update_mrw, UInt32 pi_freq_map)
{
		jtag_dll_mc_reg_write(MR13_DATA_0_ADDR, WriteBitsToValue(mr13_data, jtag_dll_mc_reg_read(MR13_DATA_0_ADDR), (int) (MR13_DATA_0_OFFSET + (MR13_DATA_0_WIDTH - 1)), (int) (MR13_DATA_0_OFFSET)));
		jtag_dll_mc_reg_write(MR13_DATA_1_ADDR, WriteBitsToValue(mr13_data, jtag_dll_mc_reg_read(MR13_DATA_1_ADDR), (int) (MR13_DATA_1_OFFSET + (MR13_DATA_1_WIDTH - 1)), (int) (MR13_DATA_1_OFFSET)));
				
		jtag_dll_mc_reg_write(FSP_OP_CURRENT_ADDR, WriteBitsToValue(fsp_op_current, jtag_dll_mc_reg_read(FSP_OP_CURRENT_ADDR), (int) (FSP_OP_CURRENT_OFFSET + (FSP_OP_CURRENT_WIDTH - 1)), (int) (FSP_OP_CURRENT_OFFSET)));
		jtag_dll_mc_reg_write(FSP_WR_CURRENT_ADDR, WriteBitsToValue(fsp_wr_current, jtag_dll_mc_reg_read(FSP_WR_CURRENT_ADDR), (int) (FSP_WR_CURRENT_OFFSET + (FSP_WR_CURRENT_WIDTH - 1)), (int) (FSP_WR_CURRENT_OFFSET)));

		jtag_dll_mc_reg_write(DFS_ALWAYS_WRITE_FSP_ADDR, WriteBitsToValue(dfs_always_write_fsp, jtag_dll_mc_reg_read(DFS_ALWAYS_WRITE_FSP_ADDR), (int) (DFS_ALWAYS_WRITE_FSP_OFFSET + (DFS_ALWAYS_WRITE_FSP_WIDTH - 1)), (int) (DFS_ALWAYS_WRITE_FSP_OFFSET)));
		jtag_dll_mc_reg_write(FSP_PHY_UPDATE_MRW_ADDR, WriteBitsToValue(fsp_phy_update_mrw, jtag_dll_mc_reg_read(FSP_PHY_UPDATE_MRW_ADDR), (int) (FSP_PHY_UPDATE_MRW_OFFSET + (FSP_PHY_UPDATE_MRW_WIDTH - 1)), (int) (FSP_PHY_UPDATE_MRW_OFFSET)));

		jtag_dll_mc_reg_write(MR_FSP_DATA_VALID_F0_ADDR, WriteBitsToValue((pi_freq_map & 0x1), jtag_dll_mc_reg_read(MR_FSP_DATA_VALID_F0_ADDR), (int) (MR_FSP_DATA_VALID_F0_OFFSET + (MR_FSP_DATA_VALID_F0_WIDTH - 1)), (int) (MR_FSP_DATA_VALID_F0_OFFSET)));
		jtag_dll_mc_reg_write(MR_FSP_DATA_VALID_F1_ADDR, WriteBitsToValue(((pi_freq_map & 0x2)>>1), jtag_dll_mc_reg_read(MR_FSP_DATA_VALID_F1_ADDR), (int) (MR_FSP_DATA_VALID_F1_OFFSET + (MR_FSP_DATA_VALID_F1_WIDTH - 1)), (int) (MR_FSP_DATA_VALID_F1_OFFSET)));
		jtag_dll_mc_reg_write(MR_FSP_DATA_VALID_F2_ADDR, WriteBitsToValue(((pi_freq_map & 0x4)>>2), jtag_dll_mc_reg_read(MR_FSP_DATA_VALID_F2_ADDR), (int) (MR_FSP_DATA_VALID_F2_OFFSET + (MR_FSP_DATA_VALID_F2_WIDTH - 1)), (int) (MR_FSP_DATA_VALID_F2_OFFSET)));
}

void update_FSP()
{
	// Read PI working frequency
	UInt32 pi_init_work_freq = (UInt32) GetBitsFromValue(jtag_dll_pi_reg_read(PI_INIT_WORK_FREQ_ADDR), (int) (PI_INIT_WORK_FREQ_OFFSET + (PI_INIT_WORK_FREQ_WIDTH - 1)), (int) PI_INIT_WORK_FREQ_OFFSET);

	// Read PI Frequency map
	UInt32 pi_freq_map = (UInt32) GetBitsFromValue(jtag_dll_pi_reg_read(PI_FREQ_MAP_ADDR), (int) (PI_FREQ_MAP_OFFSET + (PI_FREQ_MAP_WIDTH - 1)), (int) PI_FREQ_MAP_OFFSET);
	
	UInt32 freq_num = 0;
	UInt32 pi_op7_odd = 0;

	for (UInt32 i = 0 ; i <= (UInt32)NUM_FREQ_CHANGE_REG_COPIES; i++)
	{
		freq_num = freq_num  +  ((pi_freq_map >> (int)i) & 0x1);
	}
	print_message("Total no of frequency = " + freq_num.ToString("x") + "\n");

	if ((freq_num % 2) == 0)
		pi_op7_odd = 1;		// for 2
	else
		pi_op7_odd = 0;		// for 1,3

	print_message("pi_op7_odd =" + pi_op7_odd.ToString("x") + "\n");

	if ((pi_freq_map >> (int)pi_init_work_freq) > 1)
		pi_op7_odd = ~pi_op7_odd & 0x1;

	if (pi_op7_odd == 1)
	{
		print_message("Changing DRAM FS-OP to FSOP-1 \n");
		// update_FSP_parameters(UInt32 mr13_data, UInt32 fsp_op_current, UInt32 fsp_wr_current, UInt32 dfs_always_write_fsp, UInt32 fsp_phy_update_mrw, UInt32 freq_map)
		update_FSP_parameters(0xC8, 0x1, 0x1, 0x1, 0x1, pi_freq_map);
	}
	else
	{
		update_FSP_parameters(0x08, 0x0, 0x0, 0x1, 0x1, pi_freq_map);
		print_message("DRAM FS-OP is FSOP-0 \n");
	}

	print_message("final pi_op7_odd =" + pi_op7_odd.ToString("x") + "\n");
}

void DLL_PHY_Ctrl_Init_c()
{
	UInt32 dram_class=0xFF;
	startup_routines();
	
	try
	{
		
			InitRegistersFromFile(gctrl_file_path, false,0,0);
			print_message("Loaded LPDDR4 regconfigs: "+ gctrl_file_path + "\n");
			/*Check CTL register r/w by reading the DRAM_CLASS */
			/*
			CTL & PI: DRAM_CLASS values

			1. DDR3: 0x6
			2. DDR4: 0xA
			3. DDR5: 0xC
			4. LPDDR3: 0x7
			5. LPDDR4/4X: 0xB
			6. LPDDR5: 0xD
			7. GDDR6: 0xE
			*/
			
			dram_class = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(DRAM_CLASS_ADDR), (int)(DRAM_CLASS_WIDTH - 1 + DRAM_CLASS_OFFSET), (int)(DRAM_CLASS_OFFSET));
			if (dram_class!=0x6 && dram_class!=0x7 && dram_class!=0xA && dram_class!=0xB && dram_class!=0xC && dram_class!=0xD && dram_class!=0xE)
				print_message("Error in CTL register read/write \n");
			
			dram_class=0xFF; //reset the dram class value
			
			InitRegistersFromFile(gpi_file_path, false,0,0);
			print_message("Loaded LPDDR4 regconfigs:"+ gpi_file_path + "\n");
			
			/*Check PI register r/w by reading the DRAM_CLASS */
			dram_class = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_DRAM_CLASS_ADDR), (int)(PI_DRAM_CLASS_WIDTH -1 + PI_DRAM_CLASS_OFFSET), (int)(PI_DRAM_CLASS_OFFSET));
			if (dram_class!=0x6 && dram_class!=0x7 && dram_class!=0xA && dram_class!=0xB && dram_class!=0xC && dram_class!=0xD)
				print_message("Error in PI register read/write \n");
		
			dram_class=0xFF; //reset the dram class value
			
			InitRegistersFromFile(gphy_file_path, false,0,0);
			print_message("Loaded LPDDR4 regconfigs:"+ gphy_file_path+ "\n");
			
			/*Check PHY register r/w by reading the DRAM_CLASS */
			/*
			PHY: DRAM_CLASS
			1. 	DDR3: 0
			2. 	DRR4: 2
			3. 	DDR5: 3
			4. 	LPDDR2: 4
			5. 	LPDDR3: 5
			6. 	LPDDR4: 0x6
			7. 	LPDDR5: 0x7
			*/
			
			dram_class = (UInt32) GetBitsFromValue(jtag_dll_mc_reg_read(PHY_MEM_CLASS_0_ADDR, true), (int)(PHY_MEM_CLASS_0_WIDTH -1),(int)PHY_MEM_CLASS_0_OFFSET);
			
			if (dram_class > 7)
				print_message("Error in PHY register read/write \n");
			
			Thread.Sleep(10);
		
	}
	catch (Exception ex)
	{
		print_message("Exception occurred " + ex.ToString());
	}
	
  Thread.Sleep(10);
}

void UpdateLvlSettings()
{
	jtag_dll_pi_reg_write(PI_CALVL_EN_F0_ADDR,WriteBitsToValue(ca_en,jtag_dll_pi_reg_read(PI_CALVL_EN_F0_ADDR),(int)(PI_CALVL_EN_F0_OFFSET + (PI_CALVL_EN_F0_WIDTH -1)),(int)PI_CALVL_EN_F0_OFFSET));
	jtag_dll_pi_reg_write(PI_CALVL_EN_F1_ADDR,WriteBitsToValue(ca_en,jtag_dll_pi_reg_read(PI_CALVL_EN_F1_ADDR),(int)(PI_CALVL_EN_F1_OFFSET + (PI_CALVL_EN_F1_WIDTH -1)),(int)PI_CALVL_EN_F1_OFFSET));
	jtag_dll_pi_reg_write(PI_CALVL_EN_F2_ADDR,WriteBitsToValue(ca_en,jtag_dll_pi_reg_read(PI_CALVL_EN_F2_ADDR),(int)(PI_CALVL_EN_F2_OFFSET + (PI_CALVL_EN_F2_WIDTH -1)),(int)PI_CALVL_EN_F2_OFFSET));
	jtag_dll_pi_reg_write(PI_CALVL_CS_MAP_ADDR,WriteBitsToValue(ca_map,jtag_dll_pi_reg_read(PI_CALVL_CS_MAP_ADDR),(int)(PI_CALVL_CS_MAP_OFFSET + (PI_CALVL_CS_MAP_WIDTH-1)),(int)PI_CALVL_CS_MAP_OFFSET));

	jtag_dll_pi_reg_write(PI_WRLVL_EN_F0_ADDR,WriteBitsToValue(wrlvl_en,jtag_dll_pi_reg_read(PI_WRLVL_EN_F0_ADDR),(int)(PI_WRLVL_EN_F0_OFFSET + (PI_WRLVL_EN_F0_WIDTH -1)),(int)PI_WRLVL_EN_F0_OFFSET));
	jtag_dll_pi_reg_write(PI_WRLVL_EN_F1_ADDR,WriteBitsToValue(wrlvl_en,jtag_dll_pi_reg_read(PI_WRLVL_EN_F1_ADDR),(int)(PI_WRLVL_EN_F1_OFFSET + (PI_WRLVL_EN_F1_WIDTH -1)),(int)PI_WRLVL_EN_F1_OFFSET));
	jtag_dll_pi_reg_write(PI_WRLVL_EN_F2_ADDR,WriteBitsToValue(wrlvl_en,jtag_dll_pi_reg_read(PI_WRLVL_EN_F2_ADDR),(int)(PI_WRLVL_EN_F2_OFFSET + (PI_WRLVL_EN_F2_WIDTH -1)),(int)PI_WRLVL_EN_F2_OFFSET));
	
	jtag_dll_pi_reg_write(PI_WRLVL_CS_MAP_ADDR,WriteBitsToValue(wrlvl_map,jtag_dll_pi_reg_read(PI_WRLVL_CS_MAP_ADDR),(int)(PI_WRLVL_CS_MAP_OFFSET + (PI_WRLVL_CS_MAP_WIDTH-1)),(int)PI_WRLVL_CS_MAP_OFFSET));

	jtag_dll_pi_reg_write(PI_RDLVL_GATE_EN_F0_ADDR,WriteBitsToValue(gate_en,jtag_dll_pi_reg_read(PI_RDLVL_GATE_EN_F0_ADDR),(int)(PI_RDLVL_GATE_EN_F0_OFFSET + (PI_RDLVL_GATE_EN_F0_WIDTH -1)),(int)PI_RDLVL_GATE_EN_F0_OFFSET));
	jtag_dll_pi_reg_write(PI_RDLVL_GATE_EN_F1_ADDR,WriteBitsToValue(gate_en,jtag_dll_pi_reg_read(PI_RDLVL_GATE_EN_F1_ADDR),(int)(PI_RDLVL_GATE_EN_F1_OFFSET + (PI_RDLVL_GATE_EN_F1_WIDTH -1)),(int)PI_RDLVL_GATE_EN_F1_OFFSET));
    jtag_dll_pi_reg_write(PI_RDLVL_GATE_EN_F2_ADDR,WriteBitsToValue(gate_en,jtag_dll_pi_reg_read(PI_RDLVL_GATE_EN_F2_ADDR),(int)(PI_RDLVL_GATE_EN_F2_OFFSET + (PI_RDLVL_GATE_EN_F2_WIDTH -1)),(int)PI_RDLVL_GATE_EN_F2_OFFSET));
    
	jtag_dll_pi_reg_write(PI_RDLVL_GATE_CS_MAP_ADDR, WriteBitsToValue(gate_map, jtag_dll_pi_reg_read(PI_RDLVL_GATE_CS_MAP_ADDR), (int)(PI_RDLVL_GATE_CS_MAP_OFFSET + (PI_RDLVL_GATE_CS_MAP_WIDTH - 1)), (int)PI_RDLVL_GATE_CS_MAP_OFFSET));

	jtag_dll_pi_reg_write(PI_RDLVL_EN_F0_ADDR,WriteBitsToValue(rdlvl_en,jtag_dll_pi_reg_read(PI_RDLVL_EN_F0_ADDR),(int)(PI_RDLVL_EN_F0_OFFSET + (PI_RDLVL_EN_F0_WIDTH -1)),(int)PI_RDLVL_EN_F0_OFFSET));
	jtag_dll_pi_reg_write(PI_RDLVL_EN_F1_ADDR,WriteBitsToValue(rdlvl_en,jtag_dll_pi_reg_read(PI_RDLVL_EN_F1_ADDR),(int)(PI_RDLVL_EN_F1_OFFSET + (PI_RDLVL_EN_F1_WIDTH -1)),(int)PI_RDLVL_EN_F1_OFFSET));
	jtag_dll_pi_reg_write(PI_RDLVL_EN_F2_ADDR,WriteBitsToValue(rdlvl_en,jtag_dll_pi_reg_read(PI_RDLVL_EN_F2_ADDR),(int)(PI_RDLVL_EN_F2_OFFSET + (PI_RDLVL_EN_F2_WIDTH -1)),(int)PI_RDLVL_EN_F2_OFFSET));
	
	jtag_dll_pi_reg_write(PI_RDLVL_CS_MAP_ADDR,WriteBitsToValue(rdlvl_map,jtag_dll_pi_reg_read(PI_RDLVL_CS_MAP_ADDR),(int)(PI_RDLVL_CS_MAP_OFFSET + (PI_RDLVL_CS_MAP_WIDTH-1)),(int)PI_RDLVL_CS_MAP_OFFSET));


	jtag_dll_pi_reg_write(PI_WDQLVL_EN_F0_ADDR,WriteBitsToValue(wdq_en,jtag_dll_pi_reg_read(PI_WDQLVL_EN_F0_ADDR),(int)(PI_WDQLVL_EN_F0_OFFSET + (PI_WDQLVL_EN_F0_WIDTH -1)),(int)PI_WDQLVL_EN_F0_OFFSET));
	jtag_dll_pi_reg_write(PI_WDQLVL_EN_F1_ADDR,WriteBitsToValue(wdq_en,jtag_dll_pi_reg_read(PI_WDQLVL_EN_F1_ADDR),(int)(PI_WDQLVL_EN_F1_OFFSET + (PI_WDQLVL_EN_F1_WIDTH -1)),(int)PI_WDQLVL_EN_F1_OFFSET));
	jtag_dll_pi_reg_write(PI_WDQLVL_EN_F2_ADDR,WriteBitsToValue(wdq_en,jtag_dll_pi_reg_read(PI_WDQLVL_EN_F2_ADDR),(int)(PI_WDQLVL_EN_F2_OFFSET + (PI_WDQLVL_EN_F2_WIDTH -1)),(int)PI_WDQLVL_EN_F2_OFFSET));
	
	jtag_dll_pi_reg_write(PI_WDQLVL_CS_MAP_ADDR,WriteBitsToValue(wdq_map,jtag_dll_pi_reg_read(PI_WDQLVL_CS_MAP_ADDR),(int)(PI_WDQLVL_CS_MAP_OFFSET + (PI_WDQLVL_CS_MAP_WIDTH-1)),(int)PI_WDQLVL_CS_MAP_OFFSET));

	jtag_dll_pi_reg_write(PI_CS_MAP_ADDR, WriteBitsToValue(pi_cs_map, jtag_dll_pi_reg_read(PI_CS_MAP_ADDR),(int)(PI_CS_MAP_OFFSET + (PI_CS_MAP_WIDTH -1)),(int)PI_CS_MAP_OFFSET));	// PI_CS_MAP
	jtag_dll_mc_reg_write(CS_MAP_ADDR, WriteBitsToValue(Ctrl_cs_map, jtag_dll_mc_reg_read(CS_MAP_ADDR), (int) (CS_MAP_OFFSET + (CS_MAP_WIDTH - 1)), (int) (CS_MAP_OFFSET)));
}


void UpdateFreqSelBasedParameters()   // To be updated, required only if supporting more than one frequency
{
	// f0 freqindex 0  boot 
	// f1  freq index 1 = 0

	// Disable freq based multicast enable and freq index to 1
	// fequency index 0 is already written
	jtag_dll_mc_reg_write(PHY_FREQ_SEL_MULTICAST_EN_ADDR,WriteBitsToValue(0,jtag_dll_mc_reg_read(PHY_FREQ_SEL_MULTICAST_EN_ADDR,true),(int)PHY_FREQ_SEL_MULTICAST_EN_OFFSET,(int)PHY_FREQ_SEL_MULTICAST_EN_OFFSET),true);
	
	jtag_dll_mc_reg_write(PHY_FREQ_SEL_INDEX_ADDR,WriteBitsToValue(1,jtag_dll_mc_reg_read(PHY_FREQ_SEL_INDEX_ADDR,true),(int)(PHY_FREQ_SEL_INDEX_WIDTH - 1 + PHY_FREQ_SEL_INDEX_OFFSET),(int)PHY_FREQ_SEL_INDEX_OFFSET),true);


	for(UInt32 i=0; i < PHY_MEM_SLICE_COUNT; i++)
	{
		// Add top level parameters based on alternate frequency such as PLL CTRL
		//jtag_dll_mc_reg_write(address, data,true);
		
		// To identify the required register writes, Generate PHY register configuration for alternate frequency, diff it with register config generated for operational frequency.
		// Add only non training data slice parameters based on alternate frequency. training parameters such as delays and latency will get trained during training.
		
		//TODO: Update F1 reg here 
	}
	
	//TODO: Add other reg here
	
	
	print_message("freq index 1 parameters updated \n");
	
	jtag_dll_mc_reg_write(PHY_FREQ_SEL_MULTICAST_EN_ADDR,WriteBitsToValue(1,jtag_dll_mc_reg_read(PHY_FREQ_SEL_MULTICAST_EN_ADDR,true),(int)PHY_FREQ_SEL_MULTICAST_EN_OFFSET,(int)PHY_FREQ_SEL_MULTICAST_EN_OFFSET),true);
	
	jtag_dll_mc_reg_write(PHY_FREQ_SEL_INDEX_ADDR,WriteBitsToValue(0,jtag_dll_mc_reg_read(PHY_FREQ_SEL_INDEX_ADDR,true),(int)(PHY_FREQ_SEL_INDEX_WIDTH - 1 + PHY_FREQ_SEL_INDEX_OFFSET),(int)PHY_FREQ_SEL_INDEX_OFFSET),true);
	
}

void DLL_PHY_start_ctrl_c()
{
	ulong reg_val;

	// Update cs_maps and leveling enable
	if(override_lvl_en == 1)
	{
		UpdateLvlSettings();
	}	
	
	UpdateFreqSelBasedParameters();
	
	// start PI
	if (gStartPI == 1)
	{

		if (gDisablePILvl == 1)
		{
			print_message("Disabling PI levelling at initialization\n");
			jtag_dll_pi_reg_write(PI_INIT_LVL_EN_ADDR, WriteBitsToValue(0x0, jtag_dll_pi_reg_read(PI_INIT_LVL_EN_ADDR),(int)PI_INIT_LVL_EN_OFFSET,(int)PI_INIT_LVL_EN_OFFSET));
		}
		
		jtag_dll_mc_reg_write(PHY_INDEP_TRAIN_MODE_ADDR,WriteBitsToValue(0x1,jtag_dll_mc_reg_read(PHY_INDEP_TRAIN_MODE_ADDR),(int)PHY_INDEP_TRAIN_MODE_OFFSET,(int)PHY_INDEP_TRAIN_MODE_OFFSET));
		
		if (pi_init_modeReg == 1)
		{
			jtag_dll_mc_reg_write(PHY_INDEP_INIT_MODE_ADDR,WriteBitsToValue(0x1,jtag_dll_mc_reg_read(PHY_INDEP_INIT_MODE_ADDR),(int)PHY_INDEP_INIT_MODE_OFFSET,(int)PHY_INDEP_INIT_MODE_OFFSET));
			jtag_dll_mc_reg_write(NO_MRW_INIT_ADDR,WriteBitsToValue(0x1,jtag_dll_mc_reg_read(NO_MRW_INIT_ADDR),(int)NO_MRW_INIT_OFFSET,(int)NO_MRW_INIT_OFFSET));
			jtag_dll_pi_reg_write(PI_DRAM_INIT_EN_ADDR,WriteBitsToValue(0x1,jtag_dll_pi_reg_read(PI_DRAM_INIT_EN_ADDR),(int)PI_DRAM_INIT_EN_OFFSET,(int)PI_DRAM_INIT_EN_OFFSET));

			print_message("Mode Reg Initialization by PI \n");
		}
		else
		{
			jtag_dll_mc_reg_write(PHY_INDEP_INIT_MODE_ADDR,WriteBitsToValue(0x0,jtag_dll_mc_reg_read(PHY_INDEP_INIT_MODE_ADDR),(int)PHY_INDEP_INIT_MODE_OFFSET,(int)PHY_INDEP_INIT_MODE_OFFSET));
			jtag_dll_mc_reg_write(NO_MRW_INIT_ADDR,WriteBitsToValue(0x0,jtag_dll_mc_reg_read(NO_MRW_INIT_ADDR),(int)NO_MRW_INIT_OFFSET,(int)NO_MRW_INIT_OFFSET));
			jtag_dll_pi_reg_write(PI_DRAM_INIT_EN_ADDR,WriteBitsToValue(0x0,jtag_dll_pi_reg_read(PI_DRAM_INIT_EN_ADDR),(int)PI_DRAM_INIT_EN_OFFSET,(int)PI_DRAM_INIT_EN_OFFSET));
			print_message("Mode Reg Initialization by PI and CTRL \n");
		}
		
		jtag_dll_pi_reg_write(PI_START_ADDR,WriteBitsToValue(0x1,jtag_dll_pi_reg_read(PI_START_ADDR),(int)PI_START_OFFSET,(int)PI_START_OFFSET));
		print_message("Started PI \n");
	}
	else
	{
		jtag_dll_mc_reg_write(PHY_INDEP_TRAIN_MODE_ADDR,WriteBitsToValue(0x0,jtag_dll_mc_reg_read(PHY_INDEP_TRAIN_MODE_ADDR),(int)PHY_INDEP_TRAIN_MODE_OFFSET,(int)PHY_INDEP_TRAIN_MODE_OFFSET));
		jtag_dll_mc_reg_write(PHY_INDEP_INIT_MODE_ADDR,WriteBitsToValue(0x0,jtag_dll_mc_reg_read(PHY_INDEP_INIT_MODE_ADDR),(int)PHY_INDEP_INIT_MODE_OFFSET,(int)PHY_INDEP_INIT_MODE_OFFSET));
		print_message("Not Starting PI \n");
	}
	
	update_FSP();
	
	 // start controller
	jtag_dll_mc_reg_write(START_ADDR,WriteBitsToValue(0x1,jtag_dll_mc_reg_read(START_ADDR),(int)START_OFFSET,(int)START_OFFSET)); //START

	Thread.Sleep(10);
	
   if (gStartPI == 1)
    {
        UInt32 counter = 50;
        do
        {	
			
			Thread.Sleep(500);
			counter--;
			
			mc_init = (uint)GetBitsFromValue(jtag_dll_mc_reg_read(INT_STATUS_INIT_ADDR), (int)(INT_INIT_INIT_DONE_BIT_INDEX + INT_STATUS_INIT_OFFSET), (int)(INT_INIT_INIT_DONE_BIT_INDEX + INT_STATUS_INIT_OFFSET));
			pi_init = (uint)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR), (int)(PI_INIT_DONE_BIT + PI_INT_STATUS_OFFSET), (int)(PI_INIT_DONE_BIT + PI_INT_STATUS_OFFSET));
            print_message("pi_init complete =" + pi_init.ToString("x") + "\n");
            print_message("mc_init complete =" + mc_init.ToString("x") + "\n");
			
			/*Freq. shift handing*/
			ddr_handle_phy_freq_change_request();
        } while (((mc_init == 0) ||(pi_init == 0)) && (counter > 0));
    }
	else
	{
        mc_init = (uint)GetBitsFromValue(jtag_dll_mc_reg_read(INT_STATUS_INIT_ADDR), (int)(INT_INIT_INIT_DONE_BIT_INDEX + INT_STATUS_INIT_OFFSET), (int)(INT_INIT_INIT_DONE_BIT_INDEX + INT_STATUS_INIT_OFFSET));
        print_message("mc_init complete =" + mc_init.ToString("x") + "\n");
	}

	if (CheckLockStatus() != 1)
	{
		print_message("Deskew PLL Failed \n");
	}

	if (mc_init == 1)
	{
		print_message("Controller initialized \n");
	}
	else
	{
		print_message("Controller initialization failed \n");
	}

	if (pi_init == 1)
	{
		reg_val = (ulong)((UInt32)jtag_reg_read(0xc30054b8) & (~(0x1)));
		jtag_reg_write(0xc30054b8, reg_val);

		reg_val = (ulong)((UInt32)jtag_reg_read(0xc30055b0) & (~(0x3<<2))) | (0x3<<2);
		jtag_reg_write(0xc30055b0, reg_val);

		jtag_reg_write(0xc30054c4,0xe149e61);
		jtag_reg_write(0xc30054f4,0x3f);
		jtag_reg_write(0xc30054f8,0xa00cc);

		print_message("PI initialized \n");
	}
	else
	{
		print_message("PI initialization failed \n");
	}
	
	return;
}



void DumpRegconfig_c()
{	

	print_message("Dumping regconfigs registers to file: " + gOutRegCfg + "\n");
	DumpRegconfigFilestoCpp(gctrl_file_path, gpi_file_path, gphy_file_path, gOutRegCfg);
}

void DumpCurrentRegConfig_c()
{

	print_message("Dumping hardware registers to file: " + gOutRegCfg + "\n");
	DumpCurrentRegConfigToCpp(gOutRegCfg, gctrl_file_path, gpi_file_path, gphy_file_path);
}
