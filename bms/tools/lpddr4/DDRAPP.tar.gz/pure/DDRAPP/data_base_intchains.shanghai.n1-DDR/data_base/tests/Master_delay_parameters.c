//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[10];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(102,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(358,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(614,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(870,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(101,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(357,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(613,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(869,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(1072,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(1071,true);
}
void Group_read() {
    read_fn();

    PHY_MASTER_DELAY_START_0 = (UInt32)GetBitsFromValue(temp_reg[0],0+(11-1),0);
    PHY_MASTER_DELAY_START_1 = (UInt32)GetBitsFromValue(temp_reg[1],0+(11-1),0);
    PHY_MASTER_DELAY_START_2 = (UInt32)GetBitsFromValue(temp_reg[2],0+(11-1),0);
    PHY_MASTER_DELAY_START_3 = (UInt32)GetBitsFromValue(temp_reg[3],0+(11-1),0);
    PHY_MASTER_DELAY_STEP_0 = (UInt32)GetBitsFromValue(temp_reg[0],16+(6-1),16);
    PHY_MASTER_DELAY_STEP_1 = (UInt32)GetBitsFromValue(temp_reg[1],16+(6-1),16);
    PHY_MASTER_DELAY_STEP_2 = (UInt32)GetBitsFromValue(temp_reg[2],16+(6-1),16);
    PHY_MASTER_DELAY_STEP_3 = (UInt32)GetBitsFromValue(temp_reg[3],16+(6-1),16);
    PHY_MASTER_DELAY_WAIT_0 = (UInt32)GetBitsFromValue(temp_reg[0],24+(8-1),24);
    PHY_MASTER_DELAY_WAIT_1 = (UInt32)GetBitsFromValue(temp_reg[1],24+(8-1),24);
    PHY_MASTER_DELAY_WAIT_2 = (UInt32)GetBitsFromValue(temp_reg[2],24+(8-1),24);
    PHY_MASTER_DELAY_WAIT_3 = (UInt32)GetBitsFromValue(temp_reg[3],24+(8-1),24);
    PHY_SW_MASTER_MODE_0 = (UInt32)GetBitsFromValue(temp_reg[4],16+(4-1),16);
    PHY_SW_MASTER_MODE_1 = (UInt32)GetBitsFromValue(temp_reg[5],16+(4-1),16);
    PHY_SW_MASTER_MODE_2 = (UInt32)GetBitsFromValue(temp_reg[6],16+(4-1),16);
    PHY_SW_MASTER_MODE_3 = (UInt32)GetBitsFromValue(temp_reg[7],16+(4-1),16);
    PHY_ADR_MASTER_DELAY_STEP_0 = (UInt32)GetBitsFromValue(temp_reg[8],0+(6-1),0);
    PHY_ADR_MASTER_DELAY_START_0 = (UInt32)GetBitsFromValue(temp_reg[9],16+(11-1),16);
    PHY_ADR_MASTER_DELAY_WAIT_0 = (UInt32)GetBitsFromValue(temp_reg[8],8+(8-1),8);
    PHY_ADR_SW_MASTER_MODE_0 = (UInt32)GetBitsFromValue(temp_reg[9],8+(4-1),8);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_START_0, temp_reg[0] ,0+(11-1),0);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_START_1, temp_reg[1] ,0+(11-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_START_2, temp_reg[2] ,0+(11-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_START_3, temp_reg[3] ,0+(11-1),0);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_STEP_0, temp_reg[0] ,16+(6-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_STEP_1, temp_reg[1] ,16+(6-1),16);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_STEP_2, temp_reg[2] ,16+(6-1),16);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_STEP_3, temp_reg[3] ,16+(6-1),16);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_WAIT_0, temp_reg[0] ,24+(8-1),24);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_WAIT_1, temp_reg[1] ,24+(8-1),24);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_WAIT_2, temp_reg[2] ,24+(8-1),24);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_MASTER_DELAY_WAIT_3, temp_reg[3] ,24+(8-1),24);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_SW_MASTER_MODE_0, temp_reg[4] ,16+(4-1),16);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_SW_MASTER_MODE_1, temp_reg[5] ,16+(4-1),16);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_SW_MASTER_MODE_2, temp_reg[6] ,16+(4-1),16);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_SW_MASTER_MODE_3, temp_reg[7] ,16+(4-1),16);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_ADR_MASTER_DELAY_STEP_0, temp_reg[8] ,0+(6-1),0);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_ADR_MASTER_DELAY_START_0, temp_reg[9] ,16+(11-1),16);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_ADR_MASTER_DELAY_WAIT_0, temp_reg[8] ,8+(8-1),8);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_ADR_SW_MASTER_MODE_0, temp_reg[9] ,8+(4-1),8);
    jtag_dll_mc_reg_write(102, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(358, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(614, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(870, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(101, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(357, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(613, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(869, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(1072, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(1071, temp_reg[9] ,true);
}
