//****************************************************************************************
//                       © 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence’s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/

void RegTstDisplayAll_c()
{
	print_message("REGTST Display All Selected\n");
	UInt32 regtst_data;
	UInt32 i;

	if(regtst_dll_phy == 0x1)
	{
		for(i=0; i<= (UInt32)PHY_REG_LEN;i++)
		{
			regtst_data = (UInt32)jtag_dll_mc_reg_read((ulong)(i),true);
			print_message("DLL PHY  Registers Address = " + i.ToString("") + " data = " + "0x" + regtst_data.ToString("x") + "\n");
		}
	}

	if(regtst_dll_ctrl == 0x1)
	{
		print_message("Displaying DLL CTRL Registers\n");
		for(i=0; i<= (UInt32)CTLR_REG_LEN;i++)
		{
			regtst_data = (UInt32)jtag_dll_mc_reg_read((ulong)i);
			print_message("DLL CTRL Registers Address = " + i.ToString("") + " data = " + "0x" + regtst_data.ToString("x") + "\n");
		}
	}

	if (regtst_dll_pi == 0x1)
	{
		print_message("Displaying DLL PI Registers\n");
		for( i=0; i<= (UInt32)PI_REG_LEN;i++)
		{
			regtst_data = (UInt32)jtag_dll_pi_reg_read((ulong)i);
			print_message("DLL PI Registers Address = " + i.ToString("") + " data = " + "0x" + regtst_data.ToString("x") + "\n");
		}
	}

}

void regtst_single_rwr_c()
{
	print_message("REGTST Single RWR Selected\n");
	print_message("REGTST Address = " + regtst_addr +"\n");
	print_message("REGTST WR Data = 0x" + regtst_wr_data.ToString("X") +"\n");
	// while(true)


	if(regtst_dll_phy == 0x1)
	{
		print_message("RWR Single DLL PHY Register\n");
		//UInt32 regtst_addr_val = regtst_addr + 0x200;
		regtst_prev_data = (UInt32)jtag_dll_mc_reg_read(regtst_addr,true);
		jtag_dll_mc_reg_write(regtst_addr,regtst_wr_data,true);
		regtst_rd_data = (UInt32)jtag_dll_mc_reg_read(regtst_addr,true);
	}

	if(regtst_dll_ctrl == 0x1)
	{
		print_message("RWR Single DLL CTRL Register\n");
		regtst_prev_data = (UInt32)jtag_dll_mc_reg_read(regtst_addr);
		jtag_dll_mc_reg_write(regtst_addr,regtst_wr_data);
		regtst_rd_data = (UInt32)jtag_dll_mc_reg_read(regtst_addr);
	}

	if (regtst_dll_pi == 0x1)
	{
		print_message("RWR Single DLL PI Register\n");
		regtst_prev_data = (UInt32)jtag_dll_pi_reg_read(regtst_addr);
		jtag_dll_pi_reg_write(regtst_addr,regtst_wr_data);
		regtst_rd_data = (UInt32)jtag_dll_pi_reg_read(regtst_addr);
	}
	
}

void DLL_PHy_Single_Reg_Read_c()
{
	print_message("REGTST Single Read Selected\n");
	print_message("REGTST Address = " + regtst_addr_single +"\n");
	// while(true)

	if(regtst_dll_phy == 0x1)
	{
		print_message("READ Single DLL PHY Register\n");
		//UInt32 regtst_addr_single_val = regtst_addr_single + 0x200;
		regtst_rd_data_single = (UInt32)jtag_dll_mc_reg_read(regtst_addr_single,true);
	}
  
	if (regtst_dll_pi == 0x1)
	{
		print_message("READ Single DLL PI Register\n");
		regtst_rd_data_single = (UInt32)jtag_dll_pi_reg_read(regtst_addr_single);
	}
	
	if(regtst_dll_ctrl == 0x1)
	{
		print_message("Read Single DLL CTRL Register\n");
		regtst_rd_data_single = (UInt32)jtag_dll_mc_reg_read(regtst_addr_single);
	}
	print_message("REGTST Data = 0x" + regtst_rd_data_single.ToString("X")  +"\n");
}
