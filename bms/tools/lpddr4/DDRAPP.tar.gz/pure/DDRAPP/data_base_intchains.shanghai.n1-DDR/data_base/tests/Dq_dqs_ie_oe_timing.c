//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[8];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(95,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(351,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(607,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(863,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(98,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(354,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(610,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(866,true);
}
void Group_read() {
    read_fn();

    PHY_DQ_OE_TIMING_0 = (UInt32)GetBitsFromValue(temp_reg[0],0+(8-1),0);
    PHY_DQ_OE_TIMING_1 = (UInt32)GetBitsFromValue(temp_reg[1],0+(8-1),0);
    PHY_DQ_OE_TIMING_2 = (UInt32)GetBitsFromValue(temp_reg[2],0+(8-1),0);
    PHY_DQ_OE_TIMING_3 = (UInt32)GetBitsFromValue(temp_reg[3],0+(8-1),0);
    PHY_DQS_OE_TIMING_0 = (UInt32)GetBitsFromValue(temp_reg[0],24+(8-1),24);
    PHY_DQS_OE_TIMING_1 = (UInt32)GetBitsFromValue(temp_reg[1],24+(8-1),24);
    PHY_DQS_OE_TIMING_2 = (UInt32)GetBitsFromValue(temp_reg[2],24+(8-1),24);
    PHY_DQS_OE_TIMING_3 = (UInt32)GetBitsFromValue(temp_reg[3],24+(8-1),24);
    PHY_DQ_IE_TIMING_0 = (UInt32)GetBitsFromValue(temp_reg[4],8+(8-1),8);
    PHY_DQ_IE_TIMING_1 = (UInt32)GetBitsFromValue(temp_reg[5],8+(8-1),8);
    PHY_DQ_IE_TIMING_2 = (UInt32)GetBitsFromValue(temp_reg[6],8+(8-1),8);
    PHY_DQ_IE_TIMING_3 = (UInt32)GetBitsFromValue(temp_reg[7],8+(8-1),8);
    PHY_DQS_IE_TIMING_0 = (UInt32)GetBitsFromValue(temp_reg[4],16+(8-1),16);
    PHY_DQS_IE_TIMING_1 = (UInt32)GetBitsFromValue(temp_reg[5],16+(8-1),16);
    PHY_DQS_IE_TIMING_2 = (UInt32)GetBitsFromValue(temp_reg[6],16+(8-1),16);
    PHY_DQS_IE_TIMING_3 = (UInt32)GetBitsFromValue(temp_reg[7],16+(8-1),16);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_DQ_OE_TIMING_0, temp_reg[0] ,0+(8-1),0);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_DQ_OE_TIMING_1, temp_reg[1] ,0+(8-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_DQ_OE_TIMING_2, temp_reg[2] ,0+(8-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_DQ_OE_TIMING_3, temp_reg[3] ,0+(8-1),0);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_DQS_OE_TIMING_0, temp_reg[0] ,24+(8-1),24);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_DQS_OE_TIMING_1, temp_reg[1] ,24+(8-1),24);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_DQS_OE_TIMING_2, temp_reg[2] ,24+(8-1),24);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_DQS_OE_TIMING_3, temp_reg[3] ,24+(8-1),24);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_DQ_IE_TIMING_0, temp_reg[4] ,8+(8-1),8);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_DQ_IE_TIMING_1, temp_reg[5] ,8+(8-1),8);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_DQ_IE_TIMING_2, temp_reg[6] ,8+(8-1),8);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_DQ_IE_TIMING_3, temp_reg[7] ,8+(8-1),8);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_DQS_IE_TIMING_0, temp_reg[4] ,16+(8-1),16);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_DQS_IE_TIMING_1, temp_reg[5] ,16+(8-1),16);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_DQS_IE_TIMING_2, temp_reg[6] ,16+(8-1),16);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_DQS_IE_TIMING_3, temp_reg[7] ,16+(8-1),16);
    jtag_dll_mc_reg_write(95, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(351, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(607, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(863, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(98, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(354, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(610, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(866, temp_reg[7] ,true);
}
