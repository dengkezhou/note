//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[9];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(1412,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(1413,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(1333,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(1420,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(1421,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(1337,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(1422,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(1423,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(1338,true);
}
void Group_read() {
    read_fn();

    addr_TX_DCD_0  = (UInt32)GetBitsFromValue(temp_reg[0],4,0);
    addr_TX120PULLDWN_0  = (UInt32)GetBitsFromValue(temp_reg[0],6,5);
    addr_TX_LOWSPEED_BYPASS_0  = (UInt32)GetBitsFromValue(temp_reg[0],7,7);
    addr_SLEWN_0  = (UInt32)GetBitsFromValue(temp_reg[0],10,8);
    addr_SLEWP_0  = (UInt32)GetBitsFromValue(temp_reg[0],13,11);
    addr_MODE_0  = (UInt32)GetBitsFromValue(temp_reg[0],17,14);
    addr_SPEED_0  = (UInt32)GetBitsFromValue(temp_reg[0],19,18);
    addr_BOOSTN_0  = (UInt32)GetBitsFromValue(temp_reg[0],23,20);
    addr_BOOSTP_0  = (UInt32)GetBitsFromValue(temp_reg[0],27,24);
    addr_TX_PCAS_DIS_0  = (UInt32)GetBitsFromValue(temp_reg[0],28,28);
    addr_TX_NCAS_DIS_0  = (UInt32)GetBitsFromValue(temp_reg[0],29,29);

    addr_RX_DCD_0  = (UInt32)GetBitsFromValue(temp_reg[1],4,0);
    addr_RX_CTLE_0  = (UInt32)GetBitsFromValue(temp_reg[1],7,5);
    addr_RX_OFFSET_0  = (UInt32)GetBitsFromValue(temp_reg[1],16,8);
    addr_ENSLICEN_0  = (UInt32)GetBitsFromValue(temp_reg[1],20,17);
    addr_ENSLICEP_0  = (UInt32)GetBitsFromValue(temp_reg[1],24,21);
    addr_TX_FFE_0  = (UInt32)GetBitsFromValue(temp_reg[1],26,25);
    addr_RX_IE_CAL_ALL_0  = (UInt32)GetBitsFromValue(temp_reg[1],27,27);
    addr_DRV_TP_0  = (UInt32)GetBitsFromValue(temp_reg[1],28,28);

    addr_PVTR_0  = (UInt32)GetBitsFromValue(temp_reg[2],16,12);
    addr_PVTN_0  = (UInt32)GetBitsFromValue(temp_reg[2],11,6);
    addr_PVTP_0  = (UInt32)GetBitsFromValue(temp_reg[2],5,0);
    addr_TSEL_0  = (UInt32)GetBitsFromValue(temp_reg[2],17,17);

    reset_n_TX_DCD_0  = (UInt32)GetBitsFromValue(temp_reg[3],4,0);
    reset_n_TX120PULLDWN_0  = (UInt32)GetBitsFromValue(temp_reg[3],6,5);
    reset_n_TX_LOWSPEED_BYPASS_0  = (UInt32)GetBitsFromValue(temp_reg[3],7,7);
    reset_n_SLEWN_0  = (UInt32)GetBitsFromValue(temp_reg[3],10,8);
    reset_n_SLEWP_0  = (UInt32)GetBitsFromValue(temp_reg[3],13,11);
    reset_n_MODE_0  = (UInt32)GetBitsFromValue(temp_reg[3],17,14);
    reset_n_SPEED_0  = (UInt32)GetBitsFromValue(temp_reg[3],19,18);
    reset_n_BOOSTN_0  = (UInt32)GetBitsFromValue(temp_reg[3],23,20);
    reset_n_BOOSTP_0  = (UInt32)GetBitsFromValue(temp_reg[3],27,24);
    reset_n_TX_PCAS_DIS_0  = (UInt32)GetBitsFromValue(temp_reg[3],28,28);
    reset_n_TX_NCAS_DIS_0  = (UInt32)GetBitsFromValue(temp_reg[3],29,29);

    reset_n_RX_DCD_0  = (UInt32)GetBitsFromValue(temp_reg[4],4,0);
    reset_n_RX_CTLE_0  = (UInt32)GetBitsFromValue(temp_reg[4],7,5);
    reset_n_RX_OFFSET_0  = (UInt32)GetBitsFromValue(temp_reg[4],16,8);
    reset_n_ENSLICEN_0  = (UInt32)GetBitsFromValue(temp_reg[4],20,17);
    reset_n_ENSLICEP_0  = (UInt32)GetBitsFromValue(temp_reg[4],24,21);
    reset_n_TX_FFE_0  = (UInt32)GetBitsFromValue(temp_reg[4],26,25);
    reset_n_RX_IE_CAL_ALL_0  = (UInt32)GetBitsFromValue(temp_reg[4],27,27);
    reset_n_DRV_TP_0  = (UInt32)GetBitsFromValue(temp_reg[4],28,28);

    reset_n_PVTR_0  = (UInt32)GetBitsFromValue(temp_reg[5],16,12);
    reset_n_PVTN_0  = (UInt32)GetBitsFromValue(temp_reg[5],11,6);
    reset_n_PVTP_0  = (UInt32)GetBitsFromValue(temp_reg[5],5,0);
    reset_n_TSEL_0  = (UInt32)GetBitsFromValue(temp_reg[5],17,17);

    cs_TX_DCD_0  = (UInt32)GetBitsFromValue(temp_reg[6],4,0);
    cs_TX120PULLDWN_0  = (UInt32)GetBitsFromValue(temp_reg[6],6,5);
    cs_TX_LOWSPEED_BYPASS_0  = (UInt32)GetBitsFromValue(temp_reg[6],7,7);
    cs_SLEWN_0  = (UInt32)GetBitsFromValue(temp_reg[6],10,8);
    cs_SLEWP_0  = (UInt32)GetBitsFromValue(temp_reg[6],13,11);
    cs_MODE_0  = (UInt32)GetBitsFromValue(temp_reg[6],17,14);
    cs_SPEED_0  = (UInt32)GetBitsFromValue(temp_reg[6],19,18);
    cs_BOOSTN_0  = (UInt32)GetBitsFromValue(temp_reg[6],23,20);
    cs_BOOSTP_0  = (UInt32)GetBitsFromValue(temp_reg[6],27,24);
    cs_TX_PCAS_DIS_0  = (UInt32)GetBitsFromValue(temp_reg[6],28,28);
    cs_TX_NCAS_DIS_0  = (UInt32)GetBitsFromValue(temp_reg[6],29,29);

    cs_RX_DCD_0  = (UInt32)GetBitsFromValue(temp_reg[7],4,0);
    cs_RX_CTLE_0  = (UInt32)GetBitsFromValue(temp_reg[7],7,5);
    cs_RX_OFFSET_0  = (UInt32)GetBitsFromValue(temp_reg[7],16,8);
    cs_ENSLICEN_0  = (UInt32)GetBitsFromValue(temp_reg[7],20,17);
    cs_ENSLICEP_0  = (UInt32)GetBitsFromValue(temp_reg[7],24,21);
    cs_TX_FFE_0  = (UInt32)GetBitsFromValue(temp_reg[7],26,25);
    cs_RX_IE_CAL_ALL_0  = (UInt32)GetBitsFromValue(temp_reg[7],27,27);
    cs_DRV_TP_0  = (UInt32)GetBitsFromValue(temp_reg[7],28,28);

    cs_PVTR_0  = (UInt32)GetBitsFromValue(temp_reg[8],16,12);
    cs_PVTN_0  = (UInt32)GetBitsFromValue(temp_reg[8],11,6);
    cs_PVTP_0  = (UInt32)GetBitsFromValue(temp_reg[8],5,0);
    cs_TSEL_0  = (UInt32)GetBitsFromValue(temp_reg[8],17,17);

}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_TX_DCD_0 , temp_reg[0] ,4,0);
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_TX120PULLDWN_0 , temp_reg[0] ,6,5);
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_TX_LOWSPEED_BYPASS_0 , temp_reg[0] ,7,7);
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_SLEWN_0 , temp_reg[0] ,10,8);
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_SLEWP_0 , temp_reg[0] ,13,11);
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_MODE_0 , temp_reg[0] ,17,14);
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_SPEED_0 , temp_reg[0] ,19,18);
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_BOOSTN_0 , temp_reg[0] ,23,20);
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_BOOSTP_0 , temp_reg[0] ,27,24);
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_TX_PCAS_DIS_0 , temp_reg[0] ,28,28);
    temp_reg[0] = (UInt32)WriteBitsToValue(addr_TX_NCAS_DIS_0 , temp_reg[0] ,29,29);
    temp_reg[1] = (UInt32)WriteBitsToValue(addr_RX_DCD_0 , temp_reg[1] ,4,0);
    temp_reg[1] = (UInt32)WriteBitsToValue(addr_RX_CTLE_0 , temp_reg[1] ,7,5);
    temp_reg[1] = (UInt32)WriteBitsToValue(addr_RX_OFFSET_0 , temp_reg[1] ,16,8);
    temp_reg[1] = (UInt32)WriteBitsToValue(addr_ENSLICEN_0 , temp_reg[1] ,20,17);
    temp_reg[1] = (UInt32)WriteBitsToValue(addr_ENSLICEP_0 , temp_reg[1] ,24,21);
    temp_reg[1] = (UInt32)WriteBitsToValue(addr_TX_FFE_0 , temp_reg[1] ,26,25);
    temp_reg[1] = (UInt32)WriteBitsToValue(addr_RX_IE_CAL_ALL_0 , temp_reg[1] ,27,27);
    temp_reg[1] = (UInt32)WriteBitsToValue(addr_DRV_TP_0 , temp_reg[1] ,28,28);
    temp_reg[2] = (UInt32)WriteBitsToValue(addr_PVTR_0 , temp_reg[2] ,16,12);
    temp_reg[2] = (UInt32)WriteBitsToValue(addr_PVTN_0 , temp_reg[2] ,11,6);
    temp_reg[2] = (UInt32)WriteBitsToValue(addr_PVTP_0 , temp_reg[2] ,5,0);
    temp_reg[2] = (UInt32)WriteBitsToValue(addr_TSEL_0 , temp_reg[2] ,17,17);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_TX_DCD_0 , temp_reg[3] ,4,0);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_TX120PULLDWN_0 , temp_reg[3] ,6,5);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_TX_LOWSPEED_BYPASS_0 , temp_reg[3] ,7,7);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_SLEWN_0 , temp_reg[3] ,10,8);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_SLEWP_0 , temp_reg[3] ,13,11);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_MODE_0 , temp_reg[3] ,17,14);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_SPEED_0 , temp_reg[3] ,19,18);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_BOOSTN_0 , temp_reg[3] ,23,20);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_BOOSTP_0 , temp_reg[3] ,27,24);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_TX_PCAS_DIS_0 , temp_reg[3] ,28,28);
    temp_reg[3] = (UInt32)WriteBitsToValue(reset_n_TX_NCAS_DIS_0 , temp_reg[3] ,29,29);
    temp_reg[4] = (UInt32)WriteBitsToValue(reset_n_RX_DCD_0 , temp_reg[4] ,4,0);
    temp_reg[4] = (UInt32)WriteBitsToValue(reset_n_RX_CTLE_0 , temp_reg[4] ,7,5);
    temp_reg[4] = (UInt32)WriteBitsToValue(reset_n_RX_OFFSET_0 , temp_reg[4] ,16,8);
    temp_reg[4] = (UInt32)WriteBitsToValue(reset_n_ENSLICEN_0 , temp_reg[4] ,20,17);
    temp_reg[4] = (UInt32)WriteBitsToValue(reset_n_ENSLICEP_0 , temp_reg[4] ,24,21);
    temp_reg[4] = (UInt32)WriteBitsToValue(reset_n_TX_FFE_0 , temp_reg[4] ,26,25);
    temp_reg[4] = (UInt32)WriteBitsToValue(reset_n_RX_IE_CAL_ALL_0 , temp_reg[4] ,27,27);
    temp_reg[4] = (UInt32)WriteBitsToValue(reset_n_DRV_TP_0 , temp_reg[4] ,28,28);
    temp_reg[5] = (UInt32)WriteBitsToValue(reset_n_PVTR_0 , temp_reg[5] ,16,12);
    temp_reg[5] = (UInt32)WriteBitsToValue(reset_n_PVTN_0 , temp_reg[5] ,11,6);
    temp_reg[5] = (UInt32)WriteBitsToValue(reset_n_PVTP_0 , temp_reg[5] ,5,0);
    temp_reg[5] = (UInt32)WriteBitsToValue(reset_n_TSEL_0 , temp_reg[5] ,17,17);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_TX_DCD_0 , temp_reg[6] ,4,0);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_TX120PULLDWN_0 , temp_reg[6] ,6,5);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_TX_LOWSPEED_BYPASS_0 , temp_reg[6] ,7,7);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_SLEWN_0 , temp_reg[6] ,10,8);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_SLEWP_0 , temp_reg[6] ,13,11);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_MODE_0 , temp_reg[6] ,17,14);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_SPEED_0 , temp_reg[6] ,19,18);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_BOOSTN_0 , temp_reg[6] ,23,20);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_BOOSTP_0 , temp_reg[6] ,27,24);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_TX_PCAS_DIS_0 , temp_reg[6] ,28,28);
    temp_reg[6] = (UInt32)WriteBitsToValue(cs_TX_NCAS_DIS_0 , temp_reg[6] ,29,29);
    temp_reg[7] = (UInt32)WriteBitsToValue(cs_RX_DCD_0 , temp_reg[7] ,4,0);
    temp_reg[7] = (UInt32)WriteBitsToValue(cs_RX_CTLE_0 , temp_reg[7] ,7,5);
    temp_reg[7] = (UInt32)WriteBitsToValue(cs_RX_OFFSET_0 , temp_reg[7] ,16,8);
    temp_reg[7] = (UInt32)WriteBitsToValue(cs_ENSLICEN_0 , temp_reg[7] ,20,17);
    temp_reg[7] = (UInt32)WriteBitsToValue(cs_ENSLICEP_0 , temp_reg[7] ,24,21);
    temp_reg[7] = (UInt32)WriteBitsToValue(cs_TX_FFE_0 , temp_reg[7] ,26,25);
    temp_reg[7] = (UInt32)WriteBitsToValue(cs_RX_IE_CAL_ALL_0 , temp_reg[7] ,27,27);
    temp_reg[7] = (UInt32)WriteBitsToValue(cs_DRV_TP_0 , temp_reg[7] ,28,28);
    temp_reg[8] = (UInt32)WriteBitsToValue(cs_PVTR_0 , temp_reg[8] ,16,12);
    temp_reg[8] = (UInt32)WriteBitsToValue(cs_PVTN_0 , temp_reg[8] ,11,6);
    temp_reg[8] = (UInt32)WriteBitsToValue(cs_PVTP_0 , temp_reg[8] ,5,0);
    temp_reg[8] = (UInt32)WriteBitsToValue(cs_TSEL_0 , temp_reg[8] ,17,17);
    jtag_dll_mc_reg_write(1412, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(1413, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(1333, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(1420, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(1421, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(1337, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(1422, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(1423, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(1338, temp_reg[8] ,true);
}
