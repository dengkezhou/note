//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
void UpdatePhyPerCSTrainingIdx(UInt32 csNum)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=(PHY_PER_CS_TRAINING_INDEX_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(csNum, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_PER_CS_TRAINING_INDEX_OFFSET + (PHY_PER_CS_TRAINING_INDEX_WIDTH-1)), (int)PHY_PER_CS_TRAINING_INDEX_OFFSET), true);
    }
}

void updateMulticast (UInt32 multicast_en)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=( PHY_PER_CS_TRAINING_MULTICAST_EN_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(multicast_en, jtag_dll_mc_reg_read(regaddr, true), (int)( PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET + (PHY_PER_CS_TRAINING_MULTICAST_EN_WIDTH -1)), (int) PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET), true);
    }
}
public UInt32[] temp_reg = new UInt32[20];

void SC_PHY_MANUAL_UPDATE() {
    jtag_dll_mc_reg_write(1287,(UInt32)WriteBitsToValue(0x1,jtag_dll_mc_reg_read(1287, true),0 + 1 -1,0) ,true);
}

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(129,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(385,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(641,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(897,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(130,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(386,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(642,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(898,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(56,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(312,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(568,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(824,true);
    temp_reg[12] = (UInt32)jtag_dll_mc_reg_read(54,true);
    temp_reg[13] = (UInt32)jtag_dll_mc_reg_read(55,true);
    temp_reg[14] = (UInt32)jtag_dll_mc_reg_read(310,true);
    temp_reg[15] = (UInt32)jtag_dll_mc_reg_read(311,true);
    temp_reg[16] = (UInt32)jtag_dll_mc_reg_read(566,true);
    temp_reg[17] = (UInt32)jtag_dll_mc_reg_read(567,true);
    temp_reg[18] = (UInt32)jtag_dll_mc_reg_read(822,true);
    temp_reg[19] = (UInt32)jtag_dll_mc_reg_read(823,true);
}
void Group_read() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    read_fn();

    PHY_RDDQS_GATE_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[0],16+(10-1),16);
    PHY_RDDQS_GATE_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[1],16+(10-1),16);
    PHY_RDDQS_GATE_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[2],16+(10-1),16);
    PHY_RDDQS_GATE_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[3],16+(10-1),16);
    PHY_RDDQS_LATENCY_ADJUST_0 = (UInt32)GetBitsFromValue(temp_reg[4],0+(4-1),0);
    PHY_RDDQS_LATENCY_ADJUST_1 = (UInt32)GetBitsFromValue(temp_reg[5],0+(4-1),0);
    PHY_RDDQS_LATENCY_ADJUST_2 = (UInt32)GetBitsFromValue(temp_reg[6],0+(4-1),0);
    PHY_RDDQS_LATENCY_ADJUST_3 = (UInt32)GetBitsFromValue(temp_reg[7],0+(4-1),0);
    gate_sample_0 = (UInt32)GetBitsFromValue(temp_reg[8],0+(1-1),0);
    gate_zero_found_0 = (UInt32)GetBitsFromValue(temp_reg[8],2+(1-1),2);
    gate_one_found_0 = (UInt32)GetBitsFromValue(temp_reg[8],3+(1-1),3);
    hard0_0 = (UInt32)GetBitsFromValue(temp_reg[8],4+(1-1),4);
    hard1_0 = (UInt32)GetBitsFromValue(temp_reg[8],5+(1-1),5);
    gtlvl_error_min_0_0 = (UInt32)GetBitsFromValue(temp_reg[8],6+(1-1),6);
    gtlvl_error_max_0_0 = (UInt32)GetBitsFromValue(temp_reg[8],7+(1-1),7);
    gtlvl_state_0 = (UInt32)GetBitsFromValue(temp_reg[8],14+(4-1),14);
    gate_sample_1 = (UInt32)GetBitsFromValue(temp_reg[9],0+(1-1),0);
    gate_zero_found_1 = (UInt32)GetBitsFromValue(temp_reg[9],2+(1-1),2);
    gate_one_found_1 = (UInt32)GetBitsFromValue(temp_reg[9],3+(1-1),3);
    hard0_1 = (UInt32)GetBitsFromValue(temp_reg[9],4+(1-1),4);
    hard1_1 = (UInt32)GetBitsFromValue(temp_reg[9],5+(1-1),5);
    gtlvl_error_min_0_1 = (UInt32)GetBitsFromValue(temp_reg[9],6+(1-1),6);
    gtlvl_error_max_0_1 = (UInt32)GetBitsFromValue(temp_reg[9],7+(1-1),7);
    gtlvl_state_1 = (UInt32)GetBitsFromValue(temp_reg[9],14+(4-1),14);
    gate_sample_2 = (UInt32)GetBitsFromValue(temp_reg[10],0+(1-1),0);
    gate_zero_found_2 = (UInt32)GetBitsFromValue(temp_reg[10],2+(1-1),2);
    gate_one_found_2 = (UInt32)GetBitsFromValue(temp_reg[10],3+(1-1),3);
    hard0_2 = (UInt32)GetBitsFromValue(temp_reg[10],4+(1-1),4);
    hard1_2 = (UInt32)GetBitsFromValue(temp_reg[10],5+(1-1),5);
    gtlvl_error_min_0_2 = (UInt32)GetBitsFromValue(temp_reg[10],6+(1-1),6);
    gtlvl_error_max_0_2 = (UInt32)GetBitsFromValue(temp_reg[10],7+(1-1),7);
    gtlvl_state_2 = (UInt32)GetBitsFromValue(temp_reg[10],14+(4-1),14);
    gate_sample_3 = (UInt32)GetBitsFromValue(temp_reg[11],0+(1-1),0);
    gate_zero_found_3 = (UInt32)GetBitsFromValue(temp_reg[11],2+(1-1),2);
    gate_one_found_3 = (UInt32)GetBitsFromValue(temp_reg[11],3+(1-1),3);
    hard0_3 = (UInt32)GetBitsFromValue(temp_reg[11],4+(1-1),4);
    hard1_3 = (UInt32)GetBitsFromValue(temp_reg[11],5+(1-1),5);
    gtlvl_error_min_0_3 = (UInt32)GetBitsFromValue(temp_reg[11],6+(1-1),6);
    gtlvl_error_max_0_3 = (UInt32)GetBitsFromValue(temp_reg[11],7+(1-1),7);
    gtlvl_state_3 = (UInt32)GetBitsFromValue(temp_reg[11],14+(4-1),14);
    PHY_GTLVL_HARD0_DELAY_OBS_0 = (UInt32)GetBitsFromValue(temp_reg[12],16+(14-1),16);
    PHY_GTLVL_HARD1_DELAY_OBS_0 = (UInt32)GetBitsFromValue(temp_reg[13],0+(14-1),0);
    PHY_GTLVL_HARD0_DELAY_OBS_1 = (UInt32)GetBitsFromValue(temp_reg[14],16+(14-1),16);
    PHY_GTLVL_HARD1_DELAY_OBS_1 = (UInt32)GetBitsFromValue(temp_reg[15],0+(14-1),0);
    PHY_GTLVL_HARD0_DELAY_OBS_2 = (UInt32)GetBitsFromValue(temp_reg[16],16+(14-1),16);
    PHY_GTLVL_HARD1_DELAY_OBS_2 = (UInt32)GetBitsFromValue(temp_reg[17],0+(14-1),0);
    PHY_GTLVL_HARD0_DELAY_OBS_3 = (UInt32)GetBitsFromValue(temp_reg[18],16+(14-1),16);
    PHY_GTLVL_HARD1_DELAY_OBS_3 = (UInt32)GetBitsFromValue(temp_reg[19],0+(14-1),0);

    updateMulticast(1);
}
void Group_write() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_RDDQS_GATE_SLAVE_DELAY_0, temp_reg[0] ,16+(10-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_RDDQS_GATE_SLAVE_DELAY_1, temp_reg[1] ,16+(10-1),16);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_RDDQS_GATE_SLAVE_DELAY_2, temp_reg[2] ,16+(10-1),16);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_RDDQS_GATE_SLAVE_DELAY_3, temp_reg[3] ,16+(10-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_RDDQS_LATENCY_ADJUST_0, temp_reg[4] ,0+(4-1),0);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_RDDQS_LATENCY_ADJUST_1, temp_reg[5] ,0+(4-1),0);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_RDDQS_LATENCY_ADJUST_2, temp_reg[6] ,0+(4-1),0);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_RDDQS_LATENCY_ADJUST_3, temp_reg[7] ,0+(4-1),0);
    jtag_dll_mc_reg_write(129, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(385, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(641, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(897, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(130, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(386, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(642, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(898, temp_reg[7] ,true);

    SC_PHY_MANUAL_UPDATE();


    updateMulticast(1);
}

ulong regaddr;
ulong debug =0;
UInt32 sample_count = 0;


void pi_int_status_read()
{
	LVL_DONE    		=    (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR),(int)(PI_INT_STATUS_OFFSET + PI_LVL_DONE_BIT),(int)(PI_INT_STATUS_OFFSET + PI_LVL_DONE_BIT));
	RDLVL_GATE_REQ    	=    (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR),(int)(PI_INT_STATUS_OFFSET + PI_RDLVL_GATE_REQ_BIT),(int)(PI_INT_STATUS_OFFSET + PI_RDLVL_GATE_REQ_BIT));
	RDLVL_GATE_ERROR  	=    (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR),(int)(PI_INT_STATUS_OFFSET + PI_RDLVL_GATE_ERROR_BIT),(int)(PI_INT_STATUS_OFFSET + PI_RDLVL_GATE_ERROR_BIT));
}

void pi_int_ack()
{
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_INT_ACK_ADDR),(int)(PI_INT_ACK_OFFSET + PI_LVL_DONE_BIT),(int)(PI_INT_ACK_OFFSET + PI_LVL_DONE_BIT)));
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_INT_ACK_ADDR),(int)(PI_INT_ACK_OFFSET + PI_RDLVL_GATE_REQ_BIT),(int)(PI_INT_ACK_OFFSET + PI_RDLVL_GATE_REQ_BIT)));
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_INT_ACK_ADDR),(int)(PI_INT_ACK_OFFSET + PI_RDLVL_GATE_ERROR_BIT),(int)(PI_INT_ACK_OFFSET + PI_RDLVL_GATE_ERROR_BIT)));
}

void pi_rdlvl_gate_en_top()
{
	pi_rdlvl_gate_en();
	if (LVL_DONE== 1) print_message ("PI-Initiated Gate Training Completed \n");
	else print_message ("PI-Initiated Gate Training Failed \n");
	pi_int_ack();
}

void pi_rdlvl_gate_en()
{
	jtag_dll_pi_reg_write(PI_RDLVL_GATE_EN_F0_ADDR,WriteBitsToValue(2,jtag_dll_pi_reg_read(PI_RDLVL_GATE_EN_F0_ADDR),(int)(PI_RDLVL_GATE_EN_F0_OFFSET + (PI_RDLVL_GATE_EN_F0_WIDTH -1)),(int)PI_RDLVL_GATE_EN_F0_OFFSET));
	jtag_dll_pi_reg_write(PI_RDLVL_GATE_EN_F1_ADDR,WriteBitsToValue(2,jtag_dll_pi_reg_read(PI_RDLVL_GATE_EN_F1_ADDR),(int)(PI_RDLVL_GATE_EN_F1_OFFSET + (PI_RDLVL_GATE_EN_F1_WIDTH -1)),(int)PI_RDLVL_GATE_EN_F1_OFFSET));
	jtag_dll_pi_reg_write(PI_RDLVL_GATE_EN_F2_ADDR,WriteBitsToValue(2,jtag_dll_pi_reg_read(PI_RDLVL_GATE_EN_F2_ADDR),(int)(PI_RDLVL_GATE_EN_F2_OFFSET + (PI_RDLVL_GATE_EN_F2_WIDTH -1)),(int)PI_RDLVL_GATE_EN_F2_OFFSET));

	jtag_dll_pi_reg_write(PI_RDLVL_CS_SW_ADDR,WriteBitsToValue(lvl_cs,jtag_dll_pi_reg_read(PI_RDLVL_CS_SW_ADDR),(int)(PI_RDLVL_CS_SW_OFFSET + (PI_RDLVL_CS_SW_WIDTH-1)),(int)PI_RDLVL_CS_SW_OFFSET));
	jtag_dll_pi_reg_write(PI_RDLVL_GATE_REQ_ADDR,WriteBitsToValue(1,jtag_dll_pi_reg_read(PI_RDLVL_GATE_REQ_ADDR),(int)(PI_RDLVL_GATE_REQ_OFFSET + (PI_RDLVL_GATE_REQ_WIDTH-1)),(int)PI_RDLVL_GATE_REQ_OFFSET));
	print_message ("PI-Initiated Gate Training in progress \n");

	// Delay for gate training to complete
	Thread.Sleep(500);
	pi_int_status_read();
	Group_read();
}

void start_debug()
{
	LVL_DONE=0;
	sample_count = 1;
	pi_int_ack();

	for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr=(PHY_LVL_DEBUG_MODE_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(1, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_LVL_DEBUG_MODE_0_OFFSET ), (int)PHY_LVL_DEBUG_MODE_0_OFFSET), true);
	}

	pi_rdlvl_gate_en();

	Thread.Sleep(200);
	print_message ("Running Gate Training in debug mode. \n Analysed result for sample_count = 1 \n");
}

void stop_debug()
{
	for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr=(PHY_LVL_DEBUG_MODE_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(0, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_LVL_DEBUG_MODE_0_OFFSET ), (int)PHY_LVL_DEBUG_MODE_0_OFFSET), true);
	}
	pi_int_ack();
	print_message("Debug mode Disabled \n");
}

void debug_cont()
{
	if (LVL_DONE == 0)
	{
		for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
		{
			regaddr=(SC_PHY_LVL_DEBUG_CONT_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
			jtag_dll_mc_reg_write(regaddr,WriteBitsToValue(1,jtag_dll_mc_reg_read(regaddr,true),(int)SC_PHY_LVL_DEBUG_CONT_0_OFFSET,(int)SC_PHY_LVL_DEBUG_CONT_0_OFFSET),true);
		}

		pi_int_status_read();
		Group_read();
		sample_count = sample_count + 1;
		print_message("Analysed result for sample_count = " +sample_count.ToString() + "\n");
	}
	else
	{
		print_message("Gate Training Completed in debug mode \n");
		stop_debug();
	}
}
