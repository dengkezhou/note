//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
void UpdatePhyPerCSTrainingIdx(UInt32 csNum)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=(PHY_PER_CS_TRAINING_INDEX_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(csNum, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_PER_CS_TRAINING_INDEX_OFFSET + (PHY_PER_CS_TRAINING_INDEX_WIDTH-1)), (int)PHY_PER_CS_TRAINING_INDEX_OFFSET), true);
    }
}

void updateMulticast (UInt32 multicast_en)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=( PHY_PER_CS_TRAINING_MULTICAST_EN_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(multicast_en, jtag_dll_mc_reg_read(regaddr, true), (int)( PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET + (PHY_PER_CS_TRAINING_MULTICAST_EN_WIDTH -1)), (int) PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET), true);
    }
}
public UInt32[] temp_reg = new UInt32[8];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(35,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(291,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(547,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(803,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(61,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(317,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(573,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(829,true);
}
void Group_read() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    read_fn();

    UInt32 temp_obs = 0;

    temp_reg[0] = (UInt32)WriteBitsToValue(0,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_0_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(1,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_1_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(2,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_2_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(3,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_3_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(4,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_4_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(5,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_5_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(6,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_6_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(7,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_7_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(0,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_0_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(1,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_1_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(2,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_2_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(3,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_3_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(4,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_4_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(5,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_5_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(6,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_6_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(7,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_7_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(0,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_0_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(1,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_1_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(2,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_2_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(3,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_3_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(4,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_4_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(5,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_5_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(6,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_6_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(7,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_7_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(0,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_0_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(1,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_1_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(2,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_2_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(3,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_3_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(4,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_4_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(5,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_5_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(6,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_6_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(7,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_7_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(8,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dm_8_le_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[1] = (UInt32)WriteBitsToValue(8,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dm_8_le_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[2] = (UInt32)WriteBitsToValue(8,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dm_8_le_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[3] = (UInt32)WriteBitsToValue(8,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dm_8_le_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 0 + 10, 0);

    temp_reg[0] = (UInt32)WriteBitsToValue(0,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_0_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(1,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_1_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(2,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_2_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(3,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_3_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(4,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_4_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(5,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_5_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(6,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_6_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(7,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dq_7_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(0,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_0_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(1,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_1_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(2,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_2_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(3,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_3_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(4,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_4_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(5,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_5_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(6,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_6_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(7,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dq_7_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(0,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_0_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(1,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_1_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(2,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_2_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(3,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_3_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(4,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_4_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(5,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_5_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(6,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_6_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(7,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dq_7_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(0,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_0_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(1,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_1_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(2,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_2_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(3,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_3_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(4,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_4_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(5,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_5_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(6,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_6_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(7,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dq_7_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[0] = (UInt32)WriteBitsToValue(8,temp_reg[0],24 + 4 -1,24);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(60,true);
    dm_8_te_dly_0 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[1] = (UInt32)WriteBitsToValue(8,temp_reg[1],24 + 4 -1,24);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(316,true);
    dm_8_te_dly_1 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[2] = (UInt32)WriteBitsToValue(8,temp_reg[2],24 + 4 -1,24);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(572,true);
    dm_8_te_dly_2 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    temp_reg[3] = (UInt32)WriteBitsToValue(8,temp_reg[3],24 + 4 -1,24);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);
    temp_obs = (UInt32)jtag_dll_mc_reg_read(828,true);
    dm_8_te_dly_3 = (UInt32)GetBitsFromValue(temp_obs, 16 + 10, 16);

    dq_dm_le_found_0 = (UInt32)GetBitsFromValue(temp_reg[4],0+(9-1),0);
    dq_dm_te_found_0 = (UInt32)GetBitsFromValue(temp_reg[4],9+(9-1),9);
    dq_dm_fail_0 = (UInt32)GetBitsFromValue(temp_reg[4],18+(9-1),18);
    wdqlvl_lfsr_patt_0 = (UInt32)GetBitsFromValue(temp_reg[4],27+(1-1),27);
    wdqlvl_clk_patt_0 = (UInt32)GetBitsFromValue(temp_reg[4],28+(1-1),28);
    wdqlvl_user_patt_0 = (UInt32)GetBitsFromValue(temp_reg[4],29+(1-1),29);
    incorrect_write_burst_0 = (UInt32)GetBitsFromValue(temp_reg[4],30+(1-1),30);
    incorrect_read_burst_0 = (UInt32)GetBitsFromValue(temp_reg[4],31+(1-1),31);
    dq_dm_le_found_1 = (UInt32)GetBitsFromValue(temp_reg[5],0+(9-1),0);
    dq_dm_te_found_1 = (UInt32)GetBitsFromValue(temp_reg[5],9+(9-1),9);
    dq_dm_fail_1 = (UInt32)GetBitsFromValue(temp_reg[5],18+(9-1),18);
    wdqlvl_lfsr_patt_1 = (UInt32)GetBitsFromValue(temp_reg[5],27+(1-1),27);
    wdqlvl_clk_patt_1 = (UInt32)GetBitsFromValue(temp_reg[5],28+(1-1),28);
    wdqlvl_user_patt_1 = (UInt32)GetBitsFromValue(temp_reg[5],29+(1-1),29);
    incorrect_write_burst_1 = (UInt32)GetBitsFromValue(temp_reg[5],30+(1-1),30);
    incorrect_read_burst_1 = (UInt32)GetBitsFromValue(temp_reg[5],31+(1-1),31);
    dq_dm_le_found_2 = (UInt32)GetBitsFromValue(temp_reg[6],0+(9-1),0);
    dq_dm_te_found_2 = (UInt32)GetBitsFromValue(temp_reg[6],9+(9-1),9);
    dq_dm_fail_2 = (UInt32)GetBitsFromValue(temp_reg[6],18+(9-1),18);
    wdqlvl_lfsr_patt_2 = (UInt32)GetBitsFromValue(temp_reg[6],27+(1-1),27);
    wdqlvl_clk_patt_2 = (UInt32)GetBitsFromValue(temp_reg[6],28+(1-1),28);
    wdqlvl_user_patt_2 = (UInt32)GetBitsFromValue(temp_reg[6],29+(1-1),29);
    incorrect_write_burst_2 = (UInt32)GetBitsFromValue(temp_reg[6],30+(1-1),30);
    incorrect_read_burst_2 = (UInt32)GetBitsFromValue(temp_reg[6],31+(1-1),31);
    dq_dm_le_found_3 = (UInt32)GetBitsFromValue(temp_reg[7],0+(9-1),0);
    dq_dm_te_found_3 = (UInt32)GetBitsFromValue(temp_reg[7],9+(9-1),9);
    dq_dm_fail_3 = (UInt32)GetBitsFromValue(temp_reg[7],18+(9-1),18);
    wdqlvl_lfsr_patt_3 = (UInt32)GetBitsFromValue(temp_reg[7],27+(1-1),27);
    wdqlvl_clk_patt_3 = (UInt32)GetBitsFromValue(temp_reg[7],28+(1-1),28);
    wdqlvl_user_patt_3 = (UInt32)GetBitsFromValue(temp_reg[7],29+(1-1),29);
    incorrect_write_burst_3 = (UInt32)GetBitsFromValue(temp_reg[7],30+(1-1),30);
    incorrect_read_burst_3 = (UInt32)GetBitsFromValue(temp_reg[7],31+(1-1),31);

    updateMulticast(1);
}
void Group_write() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    jtag_dll_mc_reg_write(35, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(291, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(547, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(803, temp_reg[3] ,true);

    updateMulticast(1);
}

UInt32 sample_count = 0;
ulong regaddr =0;
ulong slice_num =0;

void pi_int_status_read()
{
	LVL_DONE    	=  (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR), (int)(PI_INT_STATUS_OFFSET + PI_LVL_DONE_BIT), (int)(PI_INT_STATUS_OFFSET + PI_LVL_DONE_BIT));
	WDQLVL_REQ    	=  (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR), (int)(PI_INT_STATUS_OFFSET + PI_WDQLVL_REQ_BIT), (int)(PI_INT_STATUS_OFFSET + PI_WDQLVL_REQ_BIT));
	WDQLVL_ERROR    =  (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR), (int)(PI_INT_STATUS_OFFSET + PI_WDQLVL_ERROR_BIT), (int)(PI_INT_STATUS_OFFSET + PI_WDQLVL_ERROR_BIT));
}

void pi_int_ack()
{
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1, jtag_dll_pi_reg_read(PI_INT_ACK_ADDR), (int)(PI_INT_ACK_OFFSET + PI_LVL_DONE_BIT), (int)(PI_INT_ACK_OFFSET + PI_LVL_DONE_BIT))); 			// LVL_DONE
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1, jtag_dll_pi_reg_read(PI_INT_ACK_ADDR), (int)(PI_INT_ACK_OFFSET + PI_WDQLVL_REQ_BIT), (int)(PI_INT_ACK_OFFSET + PI_WDQLVL_REQ_BIT))); 		// WRDQLVL_REQ
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR,WriteBitsToValue(1, jtag_dll_pi_reg_read(PI_INT_ACK_ADDR), (int)(PI_INT_ACK_OFFSET + PI_WDQLVL_ERROR_BIT), (int)(PI_INT_ACK_OFFSET + PI_WDQLVL_ERROR_BIT)));   	// WRDQLVL_ERROR
}

void pi_wdqlvl_en_top()
{
	dcc_wdqlvl(dcc_wdqlvl_en);
	pi_wdqlvl_en();
	if (LVL_DONE == 1) print_message ("PI-Initiated Write DQ training Completed \n");
	else print_message ("PI-Initiated Write DQ training Failed \n");
	pi_int_ack();
	clear_prev();
}

public void pi_wdqlvl_en()
{
	update_wrdqlvl_params();

	jtag_dll_pi_reg_write(PI_WDQLVL_VREF_EN_ADDR, WriteBitsToValue(PI_wdqlvl_vref_en, jtag_dll_pi_reg_read(PI_WDQLVL_VREF_EN_ADDR), (int)(PI_WDQLVL_VREF_EN_OFFSET + (PI_WDQLVL_VREF_EN_WIDTH -1)), (int)PI_WDQLVL_VREF_EN_OFFSET));  //PI_WDQLVL_VREF_EN
	jtag_dll_pi_reg_write(PI_WDQLVL_EN_F0_ADDR, WriteBitsToValue(2, jtag_dll_pi_reg_read(PI_WDQLVL_EN_F0_ADDR), (int)(PI_WDQLVL_EN_F0_OFFSET + (PI_WDQLVL_EN_F0_WIDTH - 1)), (int)PI_WDQLVL_EN_F0_OFFSET));
	jtag_dll_pi_reg_write(PI_WDQLVL_EN_F1_ADDR, WriteBitsToValue(2, jtag_dll_pi_reg_read(PI_WDQLVL_EN_F1_ADDR), (int)(PI_WDQLVL_EN_F1_OFFSET + (PI_WDQLVL_EN_F1_WIDTH - 1)), (int)PI_WDQLVL_EN_F1_OFFSET));
	jtag_dll_pi_reg_write(PI_WDQLVL_EN_F2_ADDR, WriteBitsToValue(2, jtag_dll_pi_reg_read(PI_WDQLVL_EN_F2_ADDR), (int)(PI_WDQLVL_EN_F2_OFFSET + (PI_WDQLVL_EN_F2_WIDTH - 1)), (int)PI_WDQLVL_EN_F2_OFFSET));

	jtag_dll_pi_reg_write(PI_WDQLVL_CS_SW_ADDR, WriteBitsToValue(lvl_cs, jtag_dll_pi_reg_read(PI_WDQLVL_CS_SW_ADDR), (int)(PI_WDQLVL_CS_SW_OFFSET + (PI_WDQLVL_CS_SW_WIDTH-1)), (int)PI_WDQLVL_CS_SW_OFFSET));
	jtag_dll_pi_reg_write(PI_WDQLVL_REQ_ADDR, WriteBitsToValue(1, jtag_dll_pi_reg_read(PI_WDQLVL_REQ_ADDR),(int)(PI_WDQLVL_REQ_OFFSET + (PI_WDQLVL_REQ_WIDTH - 1)),(int)PI_WDQLVL_REQ_OFFSET));

	print_message ("PI-Initiated WRDQ Training in progress \n");
	Thread.Sleep(500);

	pi_int_status_read();
}

void dcc_wdqlvl(UInt32 dcc_wdqlvl_en)
{
	for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr=(PHY_DATA_DC_WDQLVL_ENABLE_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(dcc_wdqlvl_en, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_DATA_DC_WDQLVL_ENABLE_0_OFFSET), (int)PHY_DATA_DC_WDQLVL_ENABLE_0_OFFSET), true);
	}
}
void start_debug()
{
	LVL_DONE=0;
	sample_count = 1;
	pi_int_ack();

	for (slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr=(PHY_LVL_DEBUG_MODE_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(1, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_LVL_DEBUG_MODE_0_OFFSET), (int)PHY_LVL_DEBUG_MODE_0_OFFSET), true);
	}

	pi_wdqlvl_en();
	print_message ("Running write DQ Training in debug mode. \nAnalysed result for sample_count = 1 \n");
}
void stop_debug()
{
	for (slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr=(PHY_LVL_DEBUG_MODE_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(0, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_LVL_DEBUG_MODE_0_OFFSET), (int)PHY_LVL_DEBUG_MODE_0_OFFSET), true);
	}
	print_message("Debug mode Disabled \n");
	pi_int_ack();
	clear_prev();
}
void debug_cont()
{
	if (LVL_DONE == 0)
	{
		for (slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
		{
			regaddr=(SC_PHY_LVL_DEBUG_CONT_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
			jtag_dll_mc_reg_write(regaddr,WriteBitsToValue(1,jtag_dll_mc_reg_read(regaddr,true),(int)SC_PHY_LVL_DEBUG_CONT_0_OFFSET,(int)SC_PHY_LVL_DEBUG_CONT_0_OFFSET),true);
		}
	Thread.Sleep(100);
	pi_int_status_read();
	sample_count = sample_count + 1;
	print_message("Analysed result for sample_count = " +sample_count.ToString() + "\n");
	}
	else
	{
		print_message("Write DQ training completed in debug mode \n");
		stop_debug();
	}
}

void update_wrdqlvl_params()
{
	regaddr =0;
	slice_num = 0;

	for ( slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr = (PHY_NTP_TRAIN_EN_0_ADDR + (HS_SLICE_REG_COUNT * slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(PHY_ntp_train_en, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_NTP_TRAIN_EN_0_OFFSET), (int)(PHY_NTP_TRAIN_EN_0_OFFSET)), true);  //PHY_NTP_TRAIN_EN
		regaddr = (PHY_NTP_MULT_TRAIN_0_ADDR + (HS_SLICE_REG_COUNT * slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(PHY_ntp_mult_train, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_NTP_MULT_TRAIN_0_OFFSET), (int)(PHY_NTP_MULT_TRAIN_0_OFFSET)), true); //PHY_NTP_MULT_TRAIN
	}
}

void clear_prev()
{
	regaddr =0;
	slice_num = 0;
	for ( slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr = (SC_PHY_WDQLVL_CLR_PREV_RESULTS_0_ADDR + (HS_SLICE_REG_COUNT * slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(1, jtag_dll_mc_reg_read(regaddr,true), (int)SC_PHY_WDQLVL_CLR_PREV_RESULTS_0_OFFSET, (int)SC_PHY_WDQLVL_CLR_PREV_RESULTS_0_OFFSET), true);
	}
}