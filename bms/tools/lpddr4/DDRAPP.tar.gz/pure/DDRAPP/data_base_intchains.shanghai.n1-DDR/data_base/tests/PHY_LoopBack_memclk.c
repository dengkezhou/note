//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
ulong lpbkSetupCode;

void Lpbk_Setup()
{
/*
  ac_lpbk_ext_int = phy_ac_lpbk_control_sync[0];
  ac_lpbk_cycle = phy_ac_lpbk_control_sync[2:1];
  ac_lpbk_go = phy_ac_lpbk_control_sync[3] && ac_lpbk_enable;
  ac_lpbk_obs_sel = phy_ac_lpbk_control_sync[5:4];
*/
	lpbkSetupCode =0;
	ulong ac_lpbk_ext_int = 0;
	ulong ac_lpbk_cycle = 0;

	if (Lpbk_int_mux == 1 )
		ac_lpbk_ext_int = 0;
	else
		ac_lpbk_ext_int = 1;

	if (free_running == 1)
		ac_lpbk_cycle = 0;
	else if (DQS_toggles_1024 == 1)
		ac_lpbk_cycle = 1;
	else if (DQS_toggles_8192 == 1)
		ac_lpbk_cycle = 2;
	else if (DQS_toggles_64k == 1)
		ac_lpbk_cycle = 3;

	lpbkSetupCode 	=  (((ulong)ac_lpbk_cycle << 1) +
						(ac_lpbk_ext_int));

	PHY_AC_CLK_LPBK_CONTROL_Write(lpbkSetupCode);

}


void PHY_AC_CLK_LPBK_CONTROL_Write(ulong phy_lpbk_control)
{
    jtag_dll_mc_reg_write((ulong)PHY_AC_CLK_LPBK_CONTROL_ADDR,WriteBitsToValue(phy_lpbk_control, jtag_dll_mc_reg_read((ulong)PHY_AC_CLK_LPBK_CONTROL_ADDR,true),(int)(PHY_AC_CLK_LPBK_CONTROL_OFFSET+(PHY_AC_CLK_LPBK_CONTROL_WIDTH-1)),(int)PHY_AC_CLK_LPBK_CONTROL_OFFSET),true);
}

void Lpbk_Start()
{
   // ac_lpbk_go = phy_ac_lpbk_control_sync[3] && ac_lpbk_enable;
	lpbkSetupCode = lpbkSetupCode + 0x8; // asserting the 3th bit
	PHY_AC_CLK_LPBK_CONTROL_Write(lpbkSetupCode);
	
	print_message ("Loopback Started for slice " +slice_num.ToString() + "\n");
	
}

void Lpbk_GetResult()
{

 //       phy_ac_lpbk_result_obs0[0] <= `PD ac_lpbk_fail;
 //       phy_ac_lpbk_result_obs0[1] <= `PD ac_lpbk_done;

	lpbkSetupCode = lpbkSetupCode &  0xf; // ac_lpbk_obs_sel  set to 00
	PHY_AC_CLK_LPBK_CONTROL_Write(lpbkSetupCode);
	
	ac_clk_lpbk_fail     = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_CLK_LPBK_RESULT_OBS_ADDR,true),0,0);
	ac_clk_lpbk_done 	 = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_CLK_LPBK_RESULT_OBS_ADDR,true),1,1);

	lpbkSetupCode = lpbkSetupCode + 0x10; // ac_lpbk_obs_sel  set to 01
	PHY_AC_CLK_LPBK_CONTROL_Write(lpbkSetupCode);

		ac_clk_lpbk_exp_cnt = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_CLK_LPBK_RESULT_OBS_ADDR,true),15,0);

	lpbkSetupCode = lpbkSetupCode + 0x10; // ac_lpbk_obs_sel set to 10
	PHY_AC_CLK_LPBK_CONTROL_Write(lpbkSetupCode);

		ac_clk_lpbk_act_cnt = (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read((ulong)PHY_AC_CLK_LPBK_RESULT_OBS_ADDR,true),15,0);
}

void Lpbk_Stop()
{
	PHY_AC_CLK_LPBK_CONTROL_Write(0);

    jtag_dll_mc_reg_write((ulong)PHY_UPDATE_MASK_ADDR,WriteBitsToValue(0, jtag_dll_mc_reg_read((ulong)PHY_UPDATE_MASK_ADDR,true),(int)PHY_UPDATE_MASK_OFFSET,(int)PHY_UPDATE_MASK_OFFSET),true);
	
	print_message ("Loopback Stopped \n");
}

void phy_loopback_fn()
{
	jtag_dll_mc_reg_write((ulong)PHY_UPDATE_MASK_ADDR,WriteBitsToValue(1, jtag_dll_mc_reg_read((ulong)PHY_UPDATE_MASK_ADDR,true),(int)PHY_UPDATE_MASK_OFFSET,(int)PHY_UPDATE_MASK_OFFSET),true);
	
	ulong slice_enable = (ulong)(1 << (int)slice_num) ;


	jtag_dll_mc_reg_write((ulong)PHY_AC_CLK_LPBK_ENABLE_ADDR,WriteBitsToValue(slice_enable, jtag_dll_mc_reg_read((ulong)PHY_AC_CLK_LPBK_ENABLE_ADDR,true),(int)(PHY_AC_CLK_LPBK_ENABLE_OFFSET+(PHY_AC_CLK_LPBK_ENABLE_WIDTH-1)),(int)PHY_AC_CLK_LPBK_ENABLE_OFFSET),true); // PHY_AC_LPBK_ENABLE
	jtag_dll_mc_reg_write((ulong)PHY_AC_CLK_LPBK_OBS_SELECT_ADDR,WriteBitsToValue(slice_num, jtag_dll_mc_reg_read((ulong)PHY_AC_CLK_LPBK_OBS_SELECT_ADDR,true),(int)(PHY_AC_CLK_LPBK_OBS_SELECT_OFFSET+(PHY_AC_CLK_LPBK_OBS_SELECT_WIDTH-1)),(int)PHY_AC_CLK_LPBK_OBS_SELECT_OFFSET),true); // PHY_AC_LPBK_OBS_SELECT
	print_message("\nLPBK test progressing for Memclk \n");


	Lpbk_Setup();
	Lpbk_Start();

	SleepIn_10_MiliSecounds(100);
	ac_clk_lpbk_done = 0;
	ac_clk_lpbk_fail = 0;
	
	UInt32 lpbk_done = 0;
	UInt32 lpbk_fail = 0;
	
	do
	{
		Lpbk_GetResult();
		lpbk_done = ac_clk_lpbk_done ;
		lpbk_fail = ac_clk_lpbk_fail ;
		
		Application.DoEvents();
		Thread.Sleep(10); // Sleep 1 sec counter=10 is 1 secound

		if (lpbk_stop == 1)
		{
			Lpbk_Stop();
			Lpbk_GetResult();
			lpbk_done = ac_clk_lpbk_done ;
			lpbk_fail = ac_clk_lpbk_fail ;
			break;
		}

	} while ( lpbk_done == 0);

	if ((lpbk_done ==1) && (lpbk_fail == 0)  )
		print_message ("Loopback Passed for slice " +slice_num.ToString() + "\n");
	else
		print_message ("Loopback Failed for slice " +slice_num.ToString() + "\n");
	
	Lpbk_Stop();
	
	ac_clk_lpbk_done = lpbk_done ;
	ac_clk_lpbk_fail = lpbk_fail ;
		
}