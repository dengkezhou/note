//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
void UpdatePhyPerCSTrainingIdx(UInt32 csNum)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=(PHY_PER_CS_TRAINING_INDEX_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(csNum, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_PER_CS_TRAINING_INDEX_OFFSET + (PHY_PER_CS_TRAINING_INDEX_WIDTH-1)), (int)PHY_PER_CS_TRAINING_INDEX_OFFSET), true);
    }
}

void updateMulticast (UInt32 multicast_en)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=( PHY_PER_CS_TRAINING_MULTICAST_EN_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(multicast_en, jtag_dll_mc_reg_read(regaddr, true), (int)( PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET + (PHY_PER_CS_TRAINING_MULTICAST_EN_WIDTH -1)), (int) PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET), true);
    }
}
public UInt32[] temp_reg = new UInt32[20];

void SC_PHY_MANUAL_UPDATE() {
    jtag_dll_mc_reg_write(1287,(UInt32)WriteBitsToValue(0x1,jtag_dll_mc_reg_read(1287, true),0 + 1 -1,0) ,true);
}

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(115,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(116,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(117,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(118,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(119,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(371,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(372,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(373,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(374,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(375,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(627,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(628,true);
    temp_reg[12] = (UInt32)jtag_dll_mc_reg_read(629,true);
    temp_reg[13] = (UInt32)jtag_dll_mc_reg_read(630,true);
    temp_reg[14] = (UInt32)jtag_dll_mc_reg_read(631,true);
    temp_reg[15] = (UInt32)jtag_dll_mc_reg_read(883,true);
    temp_reg[16] = (UInt32)jtag_dll_mc_reg_read(884,true);
    temp_reg[17] = (UInt32)jtag_dll_mc_reg_read(885,true);
    temp_reg[18] = (UInt32)jtag_dll_mc_reg_read(886,true);
    temp_reg[19] = (UInt32)jtag_dll_mc_reg_read(887,true);
}
void Group_read() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    read_fn();

    PHY_CLK_WRDQ0_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[0],0+(11-1),0);
    PHY_CLK_WRDQ1_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[0],16+(11-1),16);
    PHY_CLK_WRDQ2_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[1],0+(11-1),0);
    PHY_CLK_WRDQ3_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[1],16+(11-1),16);
    PHY_CLK_WRDQ4_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[2],0+(11-1),0);
    PHY_CLK_WRDQ5_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[2],16+(11-1),16);
    PHY_CLK_WRDQ6_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[3],0+(11-1),0);
    PHY_CLK_WRDQ7_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[3],16+(11-1),16);
    PHY_CLK_WRDM_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[4],0+(11-1),0);
    PHY_CLK_WRDQS_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[4],16+(10-1),16);
    PHY_CLK_WRDQ0_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[5],0+(11-1),0);
    PHY_CLK_WRDQ1_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[5],16+(11-1),16);
    PHY_CLK_WRDQ2_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[6],0+(11-1),0);
    PHY_CLK_WRDQ3_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[6],16+(11-1),16);
    PHY_CLK_WRDQ4_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[7],0+(11-1),0);
    PHY_CLK_WRDQ5_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[7],16+(11-1),16);
    PHY_CLK_WRDQ6_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[8],0+(11-1),0);
    PHY_CLK_WRDQ7_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[8],16+(11-1),16);
    PHY_CLK_WRDM_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[9],0+(11-1),0);
    PHY_CLK_WRDQS_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[9],16+(10-1),16);
    PHY_CLK_WRDQ0_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[10],0+(11-1),0);
    PHY_CLK_WRDQ1_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[10],16+(11-1),16);
    PHY_CLK_WRDQ2_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[11],0+(11-1),0);
    PHY_CLK_WRDQ3_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[11],16+(11-1),16);
    PHY_CLK_WRDQ4_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[12],0+(11-1),0);
    PHY_CLK_WRDQ5_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[12],16+(11-1),16);
    PHY_CLK_WRDQ6_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[13],0+(11-1),0);
    PHY_CLK_WRDQ7_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[13],16+(11-1),16);
    PHY_CLK_WRDM_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[14],0+(11-1),0);
    PHY_CLK_WRDQS_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[14],16+(10-1),16);
    PHY_CLK_WRDQ0_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[15],0+(11-1),0);
    PHY_CLK_WRDQ1_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[15],16+(11-1),16);
    PHY_CLK_WRDQ2_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[16],0+(11-1),0);
    PHY_CLK_WRDQ3_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[16],16+(11-1),16);
    PHY_CLK_WRDQ4_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[17],0+(11-1),0);
    PHY_CLK_WRDQ5_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[17],16+(11-1),16);
    PHY_CLK_WRDQ6_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[18],0+(11-1),0);
    PHY_CLK_WRDQ7_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[18],16+(11-1),16);
    PHY_CLK_WRDM_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[19],0+(11-1),0);
    PHY_CLK_WRDQS_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[19],16+(10-1),16);

    updateMulticast(1);
}
void Group_write() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ0_SLAVE_DELAY_0, temp_reg[0] ,0+(11-1),0);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ1_SLAVE_DELAY_0, temp_reg[0] ,16+(11-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ2_SLAVE_DELAY_0, temp_reg[1] ,0+(11-1),0);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ3_SLAVE_DELAY_0, temp_reg[1] ,16+(11-1),16);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ4_SLAVE_DELAY_0, temp_reg[2] ,0+(11-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ5_SLAVE_DELAY_0, temp_reg[2] ,16+(11-1),16);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ6_SLAVE_DELAY_0, temp_reg[3] ,0+(11-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ7_SLAVE_DELAY_0, temp_reg[3] ,16+(11-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_CLK_WRDM_SLAVE_DELAY_0, temp_reg[4] ,0+(11-1),0);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQS_SLAVE_DELAY_0, temp_reg[4] ,16+(10-1),16);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ0_SLAVE_DELAY_1, temp_reg[5] ,0+(11-1),0);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ1_SLAVE_DELAY_1, temp_reg[5] ,16+(11-1),16);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ2_SLAVE_DELAY_1, temp_reg[6] ,0+(11-1),0);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ3_SLAVE_DELAY_1, temp_reg[6] ,16+(11-1),16);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ4_SLAVE_DELAY_1, temp_reg[7] ,0+(11-1),0);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ5_SLAVE_DELAY_1, temp_reg[7] ,16+(11-1),16);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ6_SLAVE_DELAY_1, temp_reg[8] ,0+(11-1),0);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ7_SLAVE_DELAY_1, temp_reg[8] ,16+(11-1),16);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_CLK_WRDM_SLAVE_DELAY_1, temp_reg[9] ,0+(11-1),0);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQS_SLAVE_DELAY_1, temp_reg[9] ,16+(10-1),16);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ0_SLAVE_DELAY_2, temp_reg[10] ,0+(11-1),0);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ1_SLAVE_DELAY_2, temp_reg[10] ,16+(11-1),16);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ2_SLAVE_DELAY_2, temp_reg[11] ,0+(11-1),0);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ3_SLAVE_DELAY_2, temp_reg[11] ,16+(11-1),16);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ4_SLAVE_DELAY_2, temp_reg[12] ,0+(11-1),0);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ5_SLAVE_DELAY_2, temp_reg[12] ,16+(11-1),16);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ6_SLAVE_DELAY_2, temp_reg[13] ,0+(11-1),0);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ7_SLAVE_DELAY_2, temp_reg[13] ,16+(11-1),16);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_CLK_WRDM_SLAVE_DELAY_2, temp_reg[14] ,0+(11-1),0);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQS_SLAVE_DELAY_2, temp_reg[14] ,16+(10-1),16);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ0_SLAVE_DELAY_3, temp_reg[15] ,0+(11-1),0);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ1_SLAVE_DELAY_3, temp_reg[15] ,16+(11-1),16);
    temp_reg[16] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ2_SLAVE_DELAY_3, temp_reg[16] ,0+(11-1),0);
    temp_reg[16] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ3_SLAVE_DELAY_3, temp_reg[16] ,16+(11-1),16);
    temp_reg[17] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ4_SLAVE_DELAY_3, temp_reg[17] ,0+(11-1),0);
    temp_reg[17] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ5_SLAVE_DELAY_3, temp_reg[17] ,16+(11-1),16);
    temp_reg[18] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ6_SLAVE_DELAY_3, temp_reg[18] ,0+(11-1),0);
    temp_reg[18] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQ7_SLAVE_DELAY_3, temp_reg[18] ,16+(11-1),16);
    temp_reg[19] = (UInt32)WriteBitsToValue(PHY_CLK_WRDM_SLAVE_DELAY_3, temp_reg[19] ,0+(11-1),0);
    temp_reg[19] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQS_SLAVE_DELAY_3, temp_reg[19] ,16+(10-1),16);
    jtag_dll_mc_reg_write(115, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(116, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(117, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(118, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(119, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(371, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(372, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(373, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(374, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(375, temp_reg[9] ,true);
    jtag_dll_mc_reg_write(627, temp_reg[10] ,true);
    jtag_dll_mc_reg_write(628, temp_reg[11] ,true);
    jtag_dll_mc_reg_write(629, temp_reg[12] ,true);
    jtag_dll_mc_reg_write(630, temp_reg[13] ,true);
    jtag_dll_mc_reg_write(631, temp_reg[14] ,true);
    jtag_dll_mc_reg_write(883, temp_reg[15] ,true);
    jtag_dll_mc_reg_write(884, temp_reg[16] ,true);
    jtag_dll_mc_reg_write(885, temp_reg[17] ,true);
    jtag_dll_mc_reg_write(886, temp_reg[18] ,true);
    jtag_dll_mc_reg_write(887, temp_reg[19] ,true);

    SC_PHY_MANUAL_UPDATE();


    updateMulticast(1);
}
