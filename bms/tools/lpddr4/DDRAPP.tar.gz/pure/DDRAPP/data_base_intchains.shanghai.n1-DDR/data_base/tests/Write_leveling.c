//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
void UpdatePhyPerCSTrainingIdx(UInt32 csNum)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=(PHY_PER_CS_TRAINING_INDEX_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(csNum, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_PER_CS_TRAINING_INDEX_OFFSET + (PHY_PER_CS_TRAINING_INDEX_WIDTH-1)), (int)PHY_PER_CS_TRAINING_INDEX_OFFSET), true);
    }
}

void updateMulticast (UInt32 multicast_en)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=( PHY_PER_CS_TRAINING_MULTICAST_EN_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(multicast_en, jtag_dll_mc_reg_read(regaddr, true), (int)( PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET + (PHY_PER_CS_TRAINING_MULTICAST_EN_WIDTH -1)), (int) PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET), true);
    }
}
public UInt32[] temp_reg = new UInt32[20];

void SC_PHY_MANUAL_UPDATE() {
    jtag_dll_mc_reg_write(1287,(UInt32)WriteBitsToValue(0x1,jtag_dll_mc_reg_read(1287, true),0 + 1 -1,0) ,true);
}

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(119,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(375,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(631,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(887,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(130,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(386,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(642,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(898,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(54,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(310,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(566,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(822,true);
    temp_reg[12] = (UInt32)jtag_dll_mc_reg_read(51,true);
    temp_reg[13] = (UInt32)jtag_dll_mc_reg_read(307,true);
    temp_reg[14] = (UInt32)jtag_dll_mc_reg_read(563,true);
    temp_reg[15] = (UInt32)jtag_dll_mc_reg_read(819,true);
    temp_reg[16] = (UInt32)jtag_dll_mc_reg_read(52,true);
    temp_reg[17] = (UInt32)jtag_dll_mc_reg_read(308,true);
    temp_reg[18] = (UInt32)jtag_dll_mc_reg_read(564,true);
    temp_reg[19] = (UInt32)jtag_dll_mc_reg_read(820,true);
}
void Group_read() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    read_fn();

    PHY_CLK_WRDQS_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[0],16+(10-1),16);
    PHY_CLK_WRDQS_SLAVE_DELAY_1 = (UInt32)GetBitsFromValue(temp_reg[1],16+(10-1),16);
    PHY_CLK_WRDQS_SLAVE_DELAY_2 = (UInt32)GetBitsFromValue(temp_reg[2],16+(10-1),16);
    PHY_CLK_WRDQS_SLAVE_DELAY_3 = (UInt32)GetBitsFromValue(temp_reg[3],16+(10-1),16);
    PHY_WRITE_PATH_LAT_ADD_0 = (UInt32)GetBitsFromValue(temp_reg[4],8+(3-1),8);
    PHY_WRITE_PATH_LAT_ADD_1 = (UInt32)GetBitsFromValue(temp_reg[5],8+(3-1),8);
    PHY_WRITE_PATH_LAT_ADD_2 = (UInt32)GetBitsFromValue(temp_reg[6],8+(3-1),8);
    PHY_WRITE_PATH_LAT_ADD_3 = (UInt32)GetBitsFromValue(temp_reg[7],8+(3-1),8);
    PHY_WRLVL_ERROR_OBS_0 = (UInt32)GetBitsFromValue(temp_reg[8],0+(16-1),0);
    PHY_WRLVL_ERROR_OBS_1 = (UInt32)GetBitsFromValue(temp_reg[9],0+(16-1),0);
    PHY_WRLVL_ERROR_OBS_2 = (UInt32)GetBitsFromValue(temp_reg[10],0+(16-1),0);
    PHY_WRLVL_ERROR_OBS_3 = (UInt32)GetBitsFromValue(temp_reg[11],0+(16-1),0);
    PHY_WRLVL_HARD0_DELAY_OBS_0 = (UInt32)GetBitsFromValue(temp_reg[12],0+(10-1),0);
    PHY_WRLVL_HARD1_DELAY_OBS_0 = (UInt32)GetBitsFromValue(temp_reg[12],16+(10-1),16);
    PHY_WRLVL_HARD0_DELAY_OBS_1 = (UInt32)GetBitsFromValue(temp_reg[13],0+(10-1),0);
    PHY_WRLVL_HARD1_DELAY_OBS_1 = (UInt32)GetBitsFromValue(temp_reg[13],16+(10-1),16);
    PHY_WRLVL_HARD0_DELAY_OBS_2 = (UInt32)GetBitsFromValue(temp_reg[14],0+(10-1),0);
    PHY_WRLVL_HARD1_DELAY_OBS_2 = (UInt32)GetBitsFromValue(temp_reg[14],16+(10-1),16);
    PHY_WRLVL_HARD0_DELAY_OBS_3 = (UInt32)GetBitsFromValue(temp_reg[15],0+(10-1),0);
    PHY_WRLVL_HARD1_DELAY_OBS_3 = (UInt32)GetBitsFromValue(temp_reg[15],16+(10-1),16);
    wrlvl_rd_dq_0 = (UInt32)GetBitsFromValue(temp_reg[16],0+(8-1),0);
    write_zero_found_0 = (UInt32)GetBitsFromValue(temp_reg[16],8+(1-1),8);
    write_one_found_0 = (UInt32)GetBitsFromValue(temp_reg[16],9+(1-1),9);
    hard0_0 = (UInt32)GetBitsFromValue(temp_reg[16],10+(1-1),10);
    hard1_0 = (UInt32)GetBitsFromValue(temp_reg[16],11+(1-1),11);
    wrlvl_error_int_0_0 = (UInt32)GetBitsFromValue(temp_reg[16],12+(1-1),12);
    wrlvl_state_0 = (UInt32)GetBitsFromValue(temp_reg[16],13+(4-1),13);
    wrlvl_algo_state_pre_0 = (UInt32)GetBitsFromValue(temp_reg[16],17+(4-1),17);
    wrlvl_rd_dq_1 = (UInt32)GetBitsFromValue(temp_reg[17],0+(8-1),0);
    write_zero_found_1 = (UInt32)GetBitsFromValue(temp_reg[17],8+(1-1),8);
    write_one_found_1 = (UInt32)GetBitsFromValue(temp_reg[17],9+(1-1),9);
    hard0_1 = (UInt32)GetBitsFromValue(temp_reg[17],10+(1-1),10);
    hard1_1 = (UInt32)GetBitsFromValue(temp_reg[17],11+(1-1),11);
    wrlvl_error_int_0_1 = (UInt32)GetBitsFromValue(temp_reg[17],12+(1-1),12);
    wrlvl_state_1 = (UInt32)GetBitsFromValue(temp_reg[17],13+(4-1),13);
    wrlvl_algo_state_pre_1 = (UInt32)GetBitsFromValue(temp_reg[17],17+(4-1),17);
    wrlvl_rd_dq_2 = (UInt32)GetBitsFromValue(temp_reg[18],0+(8-1),0);
    write_zero_found_2 = (UInt32)GetBitsFromValue(temp_reg[18],8+(1-1),8);
    write_one_found_2 = (UInt32)GetBitsFromValue(temp_reg[18],9+(1-1),9);
    hard0_2 = (UInt32)GetBitsFromValue(temp_reg[18],10+(1-1),10);
    hard1_2 = (UInt32)GetBitsFromValue(temp_reg[18],11+(1-1),11);
    wrlvl_error_int_0_2 = (UInt32)GetBitsFromValue(temp_reg[18],12+(1-1),12);
    wrlvl_state_2 = (UInt32)GetBitsFromValue(temp_reg[18],13+(4-1),13);
    wrlvl_algo_state_pre_2 = (UInt32)GetBitsFromValue(temp_reg[18],17+(4-1),17);
    wrlvl_rd_dq_3 = (UInt32)GetBitsFromValue(temp_reg[19],0+(8-1),0);
    write_zero_found_3 = (UInt32)GetBitsFromValue(temp_reg[19],8+(1-1),8);
    write_one_found_3 = (UInt32)GetBitsFromValue(temp_reg[19],9+(1-1),9);
    hard0_3 = (UInt32)GetBitsFromValue(temp_reg[19],10+(1-1),10);
    hard1_3 = (UInt32)GetBitsFromValue(temp_reg[19],11+(1-1),11);
    wrlvl_error_int_0_3 = (UInt32)GetBitsFromValue(temp_reg[19],12+(1-1),12);
    wrlvl_state_3 = (UInt32)GetBitsFromValue(temp_reg[19],13+(4-1),13);
    wrlvl_algo_state_pre_3 = (UInt32)GetBitsFromValue(temp_reg[19],17+(4-1),17);

    updateMulticast(1);
}
void Group_write() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQS_SLAVE_DELAY_0, temp_reg[0] ,16+(10-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQS_SLAVE_DELAY_1, temp_reg[1] ,16+(10-1),16);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQS_SLAVE_DELAY_2, temp_reg[2] ,16+(10-1),16);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_CLK_WRDQS_SLAVE_DELAY_3, temp_reg[3] ,16+(10-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_WRITE_PATH_LAT_ADD_0, temp_reg[4] ,8+(3-1),8);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_WRITE_PATH_LAT_ADD_1, temp_reg[5] ,8+(3-1),8);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_WRITE_PATH_LAT_ADD_2, temp_reg[6] ,8+(3-1),8);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_WRITE_PATH_LAT_ADD_3, temp_reg[7] ,8+(3-1),8);
    jtag_dll_mc_reg_write(119, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(375, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(631, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(887, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(130, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(386, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(642, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(898, temp_reg[7] ,true);

    SC_PHY_MANUAL_UPDATE();


    updateMulticast(1);
}

ulong regaddr;
ulong debug =0;
UInt32 sample_count = 0;

void pi_int_status_read()
{
	LVL_DONE    	=    (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR), (int)(PI_INT_STATUS_OFFSET + PI_LVL_DONE_BIT), (int)(PI_INT_STATUS_OFFSET + PI_LVL_DONE_BIT));
	WRLVL_REQ    	=    (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR), (int)(PI_INT_STATUS_OFFSET + PI_WRLVL_REQ_BIT), (int)(PI_INT_STATUS_OFFSET + PI_WRLVL_REQ_BIT));
	WRLVL_ERROR   	=    (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR), (int)(PI_INT_STATUS_OFFSET + PI_WRLVL_ERROR_BIT), (int)(PI_INT_STATUS_OFFSET + PI_WRLVL_ERROR_BIT));
}

void pi_int_ack()
{
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR, WriteBitsToValue(1, jtag_dll_pi_reg_read(PI_INT_ACK_ADDR), (int)(PI_INT_ACK_OFFSET + PI_LVL_DONE_BIT), (int)(PI_INT_ACK_OFFSET + PI_LVL_DONE_BIT)));      // LVL_DONE
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR, WriteBitsToValue(1, jtag_dll_pi_reg_read(PI_INT_ACK_ADDR), (int)(PI_INT_ACK_OFFSET + PI_WRLVL_REQ_BIT), (int)(PI_INT_ACK_OFFSET + PI_WRLVL_REQ_BIT)));    // WRLVL_REQ
	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR, WriteBitsToValue(1, jtag_dll_pi_reg_read(PI_INT_ACK_ADDR), (int)(PI_INT_ACK_OFFSET + PI_WRLVL_ERROR_BIT), (int)(PI_INT_ACK_OFFSET + PI_WRLVL_ERROR_BIT)));// WRLVL_ERROR
}

void pi_wrlvl_en_top()
{
	dcc_wrlvl(dcc_wrlvl_en);
	pi_wrlvl_en();
	if (LVL_DONE == 1) print_message ("PI-Initiated Write leveling Completed \n");
	else print_message ("PI-Initiated Write leveling Failed \n");
	pi_int_ack();
}

void pi_wrlvl_en()
{
	jtag_dll_pi_reg_write(PI_WRLVL_EN_F0_ADDR, WriteBitsToValue(2, jtag_dll_pi_reg_read(PI_WRLVL_EN_F0_ADDR), (int)(PI_WRLVL_EN_F0_OFFSET + (PI_WRLVL_EN_F0_WIDTH -1)), (int)PI_WRLVL_EN_F0_OFFSET));
	jtag_dll_pi_reg_write(PI_WRLVL_EN_F1_ADDR, WriteBitsToValue(2, jtag_dll_pi_reg_read(PI_WRLVL_EN_F1_ADDR), (int)(PI_WRLVL_EN_F1_OFFSET + (PI_WRLVL_EN_F1_WIDTH -1)), (int)PI_WRLVL_EN_F1_OFFSET));
	jtag_dll_pi_reg_write(PI_WRLVL_EN_F2_ADDR, WriteBitsToValue(2, jtag_dll_pi_reg_read(PI_WRLVL_EN_F2_ADDR), (int)(PI_WRLVL_EN_F2_OFFSET + (PI_WRLVL_EN_F2_WIDTH -1)), (int)PI_WRLVL_EN_F2_OFFSET));

	jtag_dll_pi_reg_write(PI_WRLVL_CS_SW_ADDR, WriteBitsToValue(lvl_cs, jtag_dll_pi_reg_read(PI_WRLVL_CS_SW_ADDR), (int)(PI_WRLVL_CS_SW_OFFSET + (PI_WRLVL_CS_SW_WIDTH-1)), (int)PI_WRLVL_CS_SW_OFFSET));
	jtag_dll_pi_reg_write(PI_WRLVL_REQ_ADDR,WriteBitsToValue(1, jtag_dll_pi_reg_read(PI_WRLVL_REQ_ADDR), (int)(PI_WRLVL_REQ_OFFSET + (PI_WRLVL_REQ_WIDTH-1)), (int)PI_WRLVL_REQ_OFFSET));

	print_message ("PI-Initiated Write leveling in Progress \n");
	Thread.Sleep(500);
	pi_int_status_read();
	Group_read();
}

void dcc_wrlvl(UInt32 dcc_wrlvl_en)
{
	for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr=(PHY_DATA_DC_WRLVL_ENABLE_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(dcc_wrlvl_en, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_DATA_DC_WRLVL_ENABLE_0_OFFSET), (int)PHY_DATA_DC_WRLVL_ENABLE_0_OFFSET), true);
	}
}

void start_debug()
{
	pi_int_ack();
	LVL_DONE=0;
	sample_count = 1;
	for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr=(PHY_LVL_DEBUG_MODE_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(1, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_LVL_DEBUG_MODE_0_OFFSET ), (int)PHY_LVL_DEBUG_MODE_0_OFFSET), true);
	}
	pi_wrlvl_en();
	Thread.Sleep(200);
	print_message ("Running Write leveling in debug mode. \n Analysed result for sample_count = 1 \n");
}

void stop_debug()
{
	for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
	{
		regaddr=(PHY_LVL_DEBUG_MODE_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
		jtag_dll_mc_reg_write(regaddr, WriteBitsToValue(0, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_LVL_DEBUG_MODE_0_OFFSET ), (int)PHY_LVL_DEBUG_MODE_0_OFFSET), true);
	}
	pi_int_ack();
	print_message("Debug mode Disabled \n");
}

void debug_cont()
{
	if (LVL_DONE == 0)
	{
		for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
		{
			regaddr=(SC_PHY_LVL_DEBUG_CONT_0_ADDR + (HS_SLICE_REG_COUNT*slice_num));
			jtag_dll_mc_reg_write(regaddr,WriteBitsToValue(1,jtag_dll_mc_reg_read(regaddr,true),(int)SC_PHY_LVL_DEBUG_CONT_0_OFFSET,(int)SC_PHY_LVL_DEBUG_CONT_0_OFFSET),true);
		}

	pi_int_status_read();
	Group_read();

	sample_count = sample_count + 1;
	print_message("Analysed result for sample_count = " +sample_count.ToString() + "\n");
	}
	else
	{
		print_message("Write Leveling completed in debug mode \n");
		stop_debug();
	}
}
