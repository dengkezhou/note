//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[16];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(31,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(287,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(543,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(799,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(104,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(360,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(616,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(872,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(105,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(361,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(617,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(873,true);
    temp_reg[12] = (UInt32)jtag_dll_mc_reg_read(132,true);
    temp_reg[13] = (UInt32)jtag_dll_mc_reg_read(388,true);
    temp_reg[14] = (UInt32)jtag_dll_mc_reg_read(644,true);
    temp_reg[15] = (UInt32)jtag_dll_mc_reg_read(900,true);
}
void Group_read() {
    read_fn();

    PHY_GTLVL_UPDT_WAIT_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[0],24+(4-1),24);
    PHY_GTLVL_UPDT_WAIT_CNT_1 = (UInt32)GetBitsFromValue(temp_reg[1],24+(4-1),24);
    PHY_GTLVL_UPDT_WAIT_CNT_2 = (UInt32)GetBitsFromValue(temp_reg[2],24+(4-1),24);
    PHY_GTLVL_UPDT_WAIT_CNT_3 = (UInt32)GetBitsFromValue(temp_reg[3],24+(4-1),24);
    PHY_GTLVL_CAPTURE_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[0],16+(6-1),16);
    PHY_GTLVL_CAPTURE_CNT_1 = (UInt32)GetBitsFromValue(temp_reg[1],16+(6-1),16);
    PHY_GTLVL_CAPTURE_CNT_2 = (UInt32)GetBitsFromValue(temp_reg[2],16+(6-1),16);
    PHY_GTLVL_CAPTURE_CNT_3 = (UInt32)GetBitsFromValue(temp_reg[3],16+(6-1),16);
    PHY_GTLVL_DLY_STEP_0 = (UInt32)GetBitsFromValue(temp_reg[4],8+(4-1),8);
    PHY_GTLVL_DLY_STEP_1 = (UInt32)GetBitsFromValue(temp_reg[5],8+(4-1),8);
    PHY_GTLVL_DLY_STEP_2 = (UInt32)GetBitsFromValue(temp_reg[6],8+(4-1),8);
    PHY_GTLVL_DLY_STEP_3 = (UInt32)GetBitsFromValue(temp_reg[7],8+(4-1),8);
    PHY_GTLVL_BACK_STEP_0 = (UInt32)GetBitsFromValue(temp_reg[8],0+(10-1),0);
    PHY_GTLVL_BACK_STEP_1 = (UInt32)GetBitsFromValue(temp_reg[9],0+(10-1),0);
    PHY_GTLVL_BACK_STEP_2 = (UInt32)GetBitsFromValue(temp_reg[10],0+(10-1),0);
    PHY_GTLVL_BACK_STEP_3 = (UInt32)GetBitsFromValue(temp_reg[11],0+(10-1),0);
    PHY_GTLVL_RESP_WAIT_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[4],16+(5-1),16);
    PHY_GTLVL_RESP_WAIT_CNT_1 = (UInt32)GetBitsFromValue(temp_reg[5],16+(5-1),16);
    PHY_GTLVL_RESP_WAIT_CNT_2 = (UInt32)GetBitsFromValue(temp_reg[6],16+(5-1),16);
    PHY_GTLVL_RESP_WAIT_CNT_3 = (UInt32)GetBitsFromValue(temp_reg[7],16+(5-1),16);
    PHY_GTLVL_FINAL_STEP_0 = (UInt32)GetBitsFromValue(temp_reg[8],16+(10-1),16);
    PHY_GTLVL_FINAL_STEP_1 = (UInt32)GetBitsFromValue(temp_reg[9],16+(10-1),16);
    PHY_GTLVL_FINAL_STEP_2 = (UInt32)GetBitsFromValue(temp_reg[10],16+(10-1),16);
    PHY_GTLVL_FINAL_STEP_3 = (UInt32)GetBitsFromValue(temp_reg[11],16+(10-1),16);
    PHY_GTLVL_LAT_ADJ_START_0 = (UInt32)GetBitsFromValue(temp_reg[12],16+(4-1),16);
    PHY_GTLVL_LAT_ADJ_START_1 = (UInt32)GetBitsFromValue(temp_reg[13],16+(4-1),16);
    PHY_GTLVL_LAT_ADJ_START_2 = (UInt32)GetBitsFromValue(temp_reg[14],16+(4-1),16);
    PHY_GTLVL_LAT_ADJ_START_3 = (UInt32)GetBitsFromValue(temp_reg[15],16+(4-1),16);
    PHY_GTLVL_RDDQS_SLV_DLY_START_0 = (UInt32)GetBitsFromValue(temp_reg[12],0+(10-1),0);
    PHY_GTLVL_RDDQS_SLV_DLY_START_1 = (UInt32)GetBitsFromValue(temp_reg[13],0+(10-1),0);
    PHY_GTLVL_RDDQS_SLV_DLY_START_2 = (UInt32)GetBitsFromValue(temp_reg[14],0+(10-1),0);
    PHY_GTLVL_RDDQS_SLV_DLY_START_3 = (UInt32)GetBitsFromValue(temp_reg[15],0+(10-1),0);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_GTLVL_UPDT_WAIT_CNT_0, temp_reg[0] ,24+(4-1),24);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_GTLVL_UPDT_WAIT_CNT_1, temp_reg[1] ,24+(4-1),24);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_GTLVL_UPDT_WAIT_CNT_2, temp_reg[2] ,24+(4-1),24);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_GTLVL_UPDT_WAIT_CNT_3, temp_reg[3] ,24+(4-1),24);
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_GTLVL_CAPTURE_CNT_0, temp_reg[0] ,16+(6-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_GTLVL_CAPTURE_CNT_1, temp_reg[1] ,16+(6-1),16);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_GTLVL_CAPTURE_CNT_2, temp_reg[2] ,16+(6-1),16);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_GTLVL_CAPTURE_CNT_3, temp_reg[3] ,16+(6-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_GTLVL_DLY_STEP_0, temp_reg[4] ,8+(4-1),8);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_GTLVL_DLY_STEP_1, temp_reg[5] ,8+(4-1),8);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_GTLVL_DLY_STEP_2, temp_reg[6] ,8+(4-1),8);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_GTLVL_DLY_STEP_3, temp_reg[7] ,8+(4-1),8);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_GTLVL_BACK_STEP_0, temp_reg[8] ,0+(10-1),0);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_GTLVL_BACK_STEP_1, temp_reg[9] ,0+(10-1),0);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_GTLVL_BACK_STEP_2, temp_reg[10] ,0+(10-1),0);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_GTLVL_BACK_STEP_3, temp_reg[11] ,0+(10-1),0);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_GTLVL_RESP_WAIT_CNT_0, temp_reg[4] ,16+(5-1),16);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_GTLVL_RESP_WAIT_CNT_1, temp_reg[5] ,16+(5-1),16);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_GTLVL_RESP_WAIT_CNT_2, temp_reg[6] ,16+(5-1),16);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_GTLVL_RESP_WAIT_CNT_3, temp_reg[7] ,16+(5-1),16);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_GTLVL_FINAL_STEP_0, temp_reg[8] ,16+(10-1),16);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_GTLVL_FINAL_STEP_1, temp_reg[9] ,16+(10-1),16);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_GTLVL_FINAL_STEP_2, temp_reg[10] ,16+(10-1),16);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_GTLVL_FINAL_STEP_3, temp_reg[11] ,16+(10-1),16);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_GTLVL_LAT_ADJ_START_0, temp_reg[12] ,16+(4-1),16);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_GTLVL_LAT_ADJ_START_1, temp_reg[13] ,16+(4-1),16);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_GTLVL_LAT_ADJ_START_2, temp_reg[14] ,16+(4-1),16);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_GTLVL_LAT_ADJ_START_3, temp_reg[15] ,16+(4-1),16);
    temp_reg[12] = (UInt32)WriteBitsToValue(PHY_GTLVL_RDDQS_SLV_DLY_START_0, temp_reg[12] ,0+(10-1),0);
    temp_reg[13] = (UInt32)WriteBitsToValue(PHY_GTLVL_RDDQS_SLV_DLY_START_1, temp_reg[13] ,0+(10-1),0);
    temp_reg[14] = (UInt32)WriteBitsToValue(PHY_GTLVL_RDDQS_SLV_DLY_START_2, temp_reg[14] ,0+(10-1),0);
    temp_reg[15] = (UInt32)WriteBitsToValue(PHY_GTLVL_RDDQS_SLV_DLY_START_3, temp_reg[15] ,0+(10-1),0);
    jtag_dll_mc_reg_write(31, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(287, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(543, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(799, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(104, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(360, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(616, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(872, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(105, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(361, temp_reg[9] ,true);
    jtag_dll_mc_reg_write(617, temp_reg[10] ,true);
    jtag_dll_mc_reg_write(873, temp_reg[11] ,true);
    jtag_dll_mc_reg_write(132, temp_reg[12] ,true);
    jtag_dll_mc_reg_write(388, temp_reg[13] ,true);
    jtag_dll_mc_reg_write(644, temp_reg[14] ,true);
    jtag_dll_mc_reg_write(900, temp_reg[15] ,true);
}
