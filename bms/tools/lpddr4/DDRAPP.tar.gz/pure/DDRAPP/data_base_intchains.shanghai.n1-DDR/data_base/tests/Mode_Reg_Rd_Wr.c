//****************************************************************************************
//                       © 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence’s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
// Mode Register Write

public bool MRW_write_c(ulong chip_select, ulong mode_reg_num , ulong mode_reg_data)
{
	bool success = true;
	int time_out = 0;
	mrw_op_done = 0;
	mrw_op_status = 0;
	
	
	UInt32 write_mode_reg_value = 0;
	
	// MRData single
	jtag_dll_mc_reg_write(MRSINGLE_DATA_0_ADDR, WriteBitsToValue(mode_reg_data,jtag_dll_mc_reg_read(MRSINGLE_DATA_0_ADDR), (int)(MRSINGLE_DATA_0_OFFSET + (MRSINGLE_DATA_0_WIDTH - 1)),(int)MRSINGLE_DATA_0_OFFSET));
	jtag_dll_mc_reg_write(MRSINGLE_DATA_1_ADDR, WriteBitsToValue(mode_reg_data,jtag_dll_mc_reg_read(MRSINGLE_DATA_1_ADDR), (int)(MRSINGLE_DATA_1_OFFSET + (MRSINGLE_DATA_1_WIDTH - 1)),(int)MRSINGLE_DATA_1_OFFSET));
	//jtag_dll_mc_reg_write(MRSINGLE_DATA_2_ADDR, WriteBitsToValue(mode_reg_data,jtag_dll_mc_reg_read(MRSINGLE_DATA_2_ADDR), (int)(MRSINGLE_DATA_2_OFFSET + (MRSINGLE_DATA_2_WIDTH - 1)),(int)MRSINGLE_DATA_2_OFFSET));
	//jtag_dll_mc_reg_write(MRSINGLE_DATA_3_ADDR, WriteBitsToValue(mode_reg_data,jtag_dll_mc_reg_read(MRSINGLE_DATA_3_ADDR), (int)(MRSINGLE_DATA_3_OFFSET + (MRSINGLE_DATA_3_WIDTH - 1)),(int)MRSINGLE_DATA_3_OFFSET));

	write_mode_reg_value =	(UInt32)(((int)mode_reg_num << (int)(WRITE_MODEREG_OFFSET + MRW_REGNUM_END)) + 
							(0x1 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_SINGLE)) + 
							(0x0 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_UPDATEALL)) +
							(0x0 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_START)));
							
	jtag_dll_mc_reg_write(WRITE_MODEREG_ADDR, write_mode_reg_value);

	write_mode_reg_value =	(UInt32)(((int)mode_reg_num << (int)(WRITE_MODEREG_OFFSET + MRW_REGNUM_END)) + 
							(0x1 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_SINGLE)) + 
							(0x0 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_UPDATEALL)) +
							(0x1 << (int)(WRITE_MODEREG_OFFSET + MRW_MODEBIT_START)));
							
	jtag_dll_mc_reg_write(WRITE_MODEREG_ADDR, write_mode_reg_value);	
	//print_message("write_mode_reg_value = 0x" + write_mode_reg_value.ToString("X") + "\n");
	
	// Wait for completion
	do
	{
		Application.DoEvents();
		Thread.Sleep(100);
		time_out = time_out + 1 ;
		if (time_out == 30)
		{
			success =  false;
			break;
		}
		mrw_op_done = (uint)GetBitsFromValue(jtag_dll_mc_reg_read(INT_STATUS_MODE_ADDR), (int)(INT_STATUS_MODE_OFFSET + INT_MODE_WRITE_MODEREG_DONE_BIT_INDEX), (int)(INT_STATUS_MODE_OFFSET + INT_MODE_WRITE_MODEREG_DONE_BIT_INDEX));  //WRITE_MODEREG_DONE_BIT
	}
	while(mrw_op_done == 0);

	if (mrw_op_done ==1) 
	{
		mrw_op_status = (uint)GetBitsFromValue(jtag_dll_mc_reg_read(MRW_STATUS_ADDR), (int)((MRW_STATUS_WIDTH-1)+ MRW_STATUS_OFFSET), (int)MRW_STATUS_OFFSET);	// Check the error status
		if (mrw_op_status !=0) print_message("ERROR: MRW Operation Completed with error \n");
	    jtag_dll_mc_reg_write(INT_ACK_MODE_ADDR, WriteBitsToValue(0x1,jtag_dll_mc_reg_read(INT_ACK_MODE_ADDR), (int)(INT_ACK_MODE_OFFSET + INT_MODE_WRITE_MODEREG_DONE_BIT_INDEX), (int)(INT_ACK_MODE_OFFSET + INT_MODE_WRITE_MODEREG_DONE_BIT_INDEX))); // Ack mode register done bit	
	}
	else
	{
		print_message("ERROR: MRW Operation Failed \n");
		success =  false;
	}

	return success;
}


// Mode Register Read
public bool MRR_read_c(ulong chip_select,ulong mode_reg_num)
{
	int time_out =0;
	bool success = true ;
	mrr_op_done =0;			// .tst defines
	mrr_err_bit = 0;		// .tst defines
	mrr_err_status = 0;		// .tst defines
	
	UInt32 read_mode_reg_value = 0;
	
	read_mode_reg_value = (UInt32)(((int)chip_select << (int)(READ_MODEREG_OFFSET + MRR_CSNUM_END)) + 
						  ((int)mode_reg_num << (int)(READ_MODEREG_OFFSET + MRR_REGNUM_END)) + 
						  (0 << (int)(READ_MODEREG_OFFSET + (READ_MODEREG_WIDTH - 1))));
	
	jtag_dll_mc_reg_write(READ_MODEREG_ADDR, read_mode_reg_value);
	
	read_mode_reg_value = (UInt32)(((int)chip_select << (int)(READ_MODEREG_OFFSET + MRR_CSNUM_END)) + 
						  ((int)mode_reg_num << (int)(READ_MODEREG_OFFSET + MRR_REGNUM_END)) + 
						  (1 << (int)(READ_MODEREG_OFFSET + (READ_MODEREG_WIDTH - 1))));
	
	jtag_dll_mc_reg_write(READ_MODEREG_ADDR, read_mode_reg_value);	

	// Wait for MRR operation to complete
	do
	{
		Thread.Sleep(100);
		mrr_op_done = (UInt32)(GetBitsFromValue(jtag_dll_mc_reg_read(INT_STATUS_MODE_ADDR),(int)(INT_STATUS_MODE_OFFSET + INT_MODE_PERIPHERAL_MRR_DONE_BIT_INDEX),(int)(INT_STATUS_MODE_OFFSET + INT_MODE_PERIPHERAL_MRR_DONE_BIT_INDEX)));
		time_out =time_out +1;
		if (time_out==30)
		{
			success = false;
			break;
		}
    }while(mrr_op_done ==0) ;
	
	// Check the error status
	mrr_err_bit = (UInt32)(GetBitsFromValue(jtag_dll_mc_reg_read(INT_STATUS_MODE_ADDR),(int)(INT_STATUS_MODE_OFFSET + INT_MODE_MRR_ERROR_BIT_INDEX),(int)(INT_STATUS_MODE_OFFSET + INT_MODE_MRR_ERROR_BIT_INDEX)));
	if (mrr_err_bit == 1)
	{
		print_message("ERROR: MRR error bit is set \n");
		mrr_err_status = (uint)GetBitsFromValue(jtag_dll_mc_reg_read(MRR_ERROR_STATUS_ADDR), (int)((MRR_ERROR_STATUS_WIDTH -1) + MRR_ERROR_STATUS_OFFSET), (int)MRR_ERROR_STATUS_OFFSET);	
		success = false;
	}

	if (mrr_op_done == 1)
	{
		// ACK PERIPHERAL_MRR_DONE_BIT
		jtag_dll_mc_reg_write(INT_ACK_MODE_ADDR, WriteBitsToValue(0x1,jtag_dll_mc_reg_read(INT_ACK_MODE_ADDR), (int)(INT_ACK_MODE_OFFSET + INT_MODE_PERIPHERAL_MRR_DONE_BIT_INDEX),(int)(INT_ACK_MODE_OFFSET + INT_MODE_PERIPHERAL_MRR_DONE_BIT_INDEX)));
	}
	else
	{
		print_message("ERROR: MRR Operation Failed \n");	
		success = false;
	}
	
	 // PERIPHERAL_MRR_DATA:RD:0:40
    gRead_Data_0   =      (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(PERIPHERAL_MRR_DATA_ADDR),7,0); 	// MRR data for device 0
	gRead_Data_1   =      (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(PERIPHERAL_MRR_DATA_ADDR),15,8); 	// MRR data for device 1
	gRead_Data_2   =      (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(PERIPHERAL_MRR_DATA_ADDR),23,16); 	// MRR data for device 2
	gRead_Data_3   =      (UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(PERIPHERAL_MRR_DATA_ADDR),31,24); 	// MRR data for device 3
	
	gRead_CS       =  	(UInt32)GetBitsFromValue(jtag_dll_mc_reg_read(PERIPHERAL_MRR_DATA_ADDR+1),7,0); 	// MRR chip information
	
	return success;
}
