﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.ComponentModel;    // KSP for win32 exceptions
using System.IO.Ports;
using System.IO;


/// .\driver\UsbE_sfl.dll for SAnJose PC
/// usb1e_sfl.dll for my jtag dongle
   
namespace DDR_Utility
{
    public class DLL_handle : DLL_handle_tektronics
    {

		/* return codes for sfl function calls */

        private const Int32 STATUS_OK = 0;
		private const Int32 SUCCESS = 0;
		private const Int32 TRANS_FAIL = -1;
		private const Int32 RECV_FAIL = -2;
		private const Int32 DRIVER_ERROR = -3;
		private const Int32 DEVICE_ERROR = -5;
		private const Int32 PARAMETER_ERROR = -100;

		private Form form;
		private System.Windows.Forms.ProgressBar progressBar2;
		private System.Windows.Forms.PictureBox pictureBox2;

		private String COMTemp;
		private String COMIoPort;
		private String COMCorePort;
		private String Temp_Head;
		
		public DLL_handle()
		{
			form = new Form();
			progressBar2 = new System.Windows.Forms.ProgressBar();
			pictureBox2 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(pictureBox2)).BeginInit();
			form.SuspendLayout();

			progressBar2.Location = new System.Drawing.Point(12, 61);
			progressBar2.Name = "progressBar2";
			progressBar2.Size = new System.Drawing.Size(628, 30);
			progressBar2.TabIndex = 0;


			//pictureBox2->Image = Image::FromFile(Application.StartupPath + "\\data_base" + "\\Cadece_Logo_Red_Reg.gif");
			pictureBox2.ImageLocation = pictureBox2.ImageLocation = Application.StartupPath + "\\Cadece_Logo_Red_Reg.gif";
			pictureBox2.Location = new System.Drawing.Point(187, 117);
			pictureBox2.Name = "pictureBox2";
			pictureBox2.Size = new System.Drawing.Size(268, 72);
			pictureBox2.TabIndex = 1;
			pictureBox2.TabStop = false;

			form.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			form.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			form.ClientSize = new System.Drawing.Size(652, 179);
			form.ControlBox = false;
			form.Controls.Add(this.pictureBox2);
			form.Controls.Add(this.progressBar2);
			form.MaximizeBox = false;
			form.MinimizeBox = false;

			form.Name = "Form1";
			form.Text = "Progress...";
			form.StartPosition = FormStartPosition.CenterScreen;
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			form.ResumeLayout(false);

			// Read the COM port assignement
			StreamReader readFile = new StreamReader(@"./Port_config.txt");
			String FileLine = null;
			while ((FileLine = readFile.ReadLine()) != null)
			{
				if (FileLine.Contains("Silicon") || FileLine.Contains("silicon"))
				{
				  string[] stringSeparators = new string[] { "=", " " };
				  string[] splitStrings = FileLine.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);
				  COMTemp = splitStrings[0];
				  Temp_Head = "Silicon";
				}
				else if(FileLine.Contains("Temptronic") || FileLine.Contains("temptronic"))
				{
				  string[] stringSeparators = new string[] { "=", " " };
				  string[] splitStrings = FileLine.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);
				  COMTemp = splitStrings[0];
				  Temp_Head = "Temptronic";
				}
				else if (FileLine.Contains("VDDIO"))
				{
				  string[] stringSeparators = new string[] { "=", " " };
				  string[] splitStrings = FileLine.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);
				  COMIoPort = splitStrings[0];

				}
				else if (FileLine.Contains("VDDC"))
				{
				  string[] stringSeparators = new string[] { "=", " " };
				  string[] splitStrings = FileLine.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);
				  COMCorePort = splitStrings[0];
				}
			}
		}

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate UInt32 RegReadDel(UInt32 address);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate Int32 RegWriteDel(UInt32 address, UInt32 data);
	
        private bool bConnectionInitialized = false;



        /*********************************************************/
        /*                  Interface Lib functions                 */
        /*********************************************************/
		[DllImport(@".\driver\InterfaceLib.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.I4)]
        private static extern Int32 OpenConnection(StringBuilder ipAddress, StringBuilder port);

        [DllImport(@".\driver\InterfaceLib.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.I4)]
        private static extern Int32 ReadMemory(UInt32 registerAddress, IntPtr registerValuePtr);

        [DllImport(@".\driver\InterfaceLib.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.I4)]
        private static extern Int32 WriteMemory(UInt32 memAddress, UInt32 memValue);

        [DllImport(@".\driver\InterfaceLib.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
        private static extern void CloseConnection();

        private Boolean HandleDriverError(Int32 stat)
        {
            String str = null;
            if (SUCCESS == stat)
            {
                return true;
            }
            if(stat == TRANS_FAIL)
            {
               str = "Driver error tarnsfer failed\n";
            }
            else if(RECV_FAIL == stat)
            {
                str = "Driver error Receive failed\n";
            }
            else if(DRIVER_ERROR == stat)
            {
                str = "Driver error occured\n";
            }
            else if(DEVICE_ERROR == stat)
            {
                str = "Device  error Receive failed\n";
            }
            else if (PARAMETER_ERROR == stat)
            {
                str = "Parameter  error  failed\n";
            }
            

            MessageBox.Show(str);
            Int32 err;
            err = Marshal.GetLastWin32Error();
            if (err != 0)
                MessageBox.Show("Win32 Last error was " + err);
            return false;
        }


           //
           
            
        #region IF_DLL_FUCTIONS

        Int32[] TempReadBuffer = new Int32[2];
        public Int32 DLL_OpenConnection(String ipAddrString, String portString)
        {
            StringBuilder ipAddress = new StringBuilder(ipAddrString);
            StringBuilder port = new StringBuilder(portString);
            Int32 status = OpenConnection(ipAddress, port);

			if (status >= 0) bConnectionInitialized = true;

            return status;
        }

        public UInt32 DLL_ReadMemory(UInt32 regAddress)
        {
            UInt32 regValue = 0xDEADBEEF;
            Int32 status = -1;
            TempReadBuffer[0] = 0;

            IntPtr regValuePtr = Marshal.AllocHGlobal(Marshal.SizeOf(TempReadBuffer[0]) * 2);

            try
            {
                status = ReadMemory(regAddress, regValuePtr);
                if (status >= 0)
                {
                    Marshal.Copy(regValuePtr, TempReadBuffer, 0, 1);
                    regValue = (UInt32)TempReadBuffer[0];
                }
            }
            finally
            {
                Marshal.FreeHGlobal(regValuePtr);
            }

            return regValue;
        }

        public Int32 DLL_WriteMemory(UInt32 regAddress, UInt32 regValue)
        {
            Int32 status = WriteMemory(regAddress, regValue);
            return status;
        }

        public void Close_Connection()
        {
            CloseConnection();
        }
		
        #endregion
		

        ~DLL_handle()
        {
            if (bConnectionInitialized)
            {
                CloseConnection();
				bConnectionInitialized = false;
            }
        }		
		
    }
}
