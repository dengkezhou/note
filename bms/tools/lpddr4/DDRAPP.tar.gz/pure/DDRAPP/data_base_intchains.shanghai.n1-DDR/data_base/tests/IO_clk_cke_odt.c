//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[6];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(1414,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(1415,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(1334,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(1418,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(1419,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(1336,true);
}
void Group_read() {
    read_fn();

    mem_clk_ENSLICEN_0  = (UInt32)GetBitsFromValue(temp_reg[0],3,0);
    mem_clk_ENSLICEP_0  = (UInt32)GetBitsFromValue(temp_reg[0],7,4);
    mem_clk_SLEWN_0  = (UInt32)GetBitsFromValue(temp_reg[0],10,8);
    mem_clk_SLEWP_0  = (UInt32)GetBitsFromValue(temp_reg[0],13,11);
    mem_clk_MODE_0  = (UInt32)GetBitsFromValue(temp_reg[0],17,14);
    mem_clk_SPEED_0  = (UInt32)GetBitsFromValue(temp_reg[0],19,18);
    mem_clk_RXDQEN_0  = (UInt32)GetBitsFromValue(temp_reg[0],20,20);
    mem_clk_TX120PULLDWN_0  = (UInt32)GetBitsFromValue(temp_reg[0],22,21);
    mem_clk_BOOSTN_0  = (UInt32)GetBitsFromValue(temp_reg[0],26,23);
    mem_clk_BOOSTP_0  = (UInt32)GetBitsFromValue(temp_reg[0],30,27);
    mem_clk_RPULL_0  = (UInt32)GetBitsFromValue(temp_reg[0],31,31);

    mem_clk_TX_DCD_0  = (UInt32)GetBitsFromValue(temp_reg[1],4,0);
    mem_clk_RX_DCD_0  = (UInt32)GetBitsFromValue(temp_reg[1],9,5);
    mem_clk_TX_PCAS_DIS_0  = (UInt32)GetBitsFromValue(temp_reg[1],10,10);
    mem_clk_TX_NCAS_DIS_0  = (UInt32)GetBitsFromValue(temp_reg[1],11,11);
    mem_clk_RX_CTLE_0  = (UInt32)GetBitsFromValue(temp_reg[1],14,12);
    mem_clk_TX_LOWSPEED_BYPASS_0  = (UInt32)GetBitsFromValue(temp_reg[1],15,15);
    mem_clk_TX_FFE_0  = (UInt32)GetBitsFromValue(temp_reg[1],17,16);
    mem_clk_RX_IE_CAL_ALL_0  = (UInt32)GetBitsFromValue(temp_reg[1],18,18);
    mem_clk_DRV_TP_0  = (UInt32)GetBitsFromValue(temp_reg[1],19,19);

    mem_clk_PVTR_0  = (UInt32)GetBitsFromValue(temp_reg[2],16,12);
    mem_clk_PVTN_0  = (UInt32)GetBitsFromValue(temp_reg[2],11,6);
    mem_clk_PVTP_0  = (UInt32)GetBitsFromValue(temp_reg[2],5,0);
    mem_clk_TSEL_0  = (UInt32)GetBitsFromValue(temp_reg[2],17,17);

    cke_TX_DCD_0  = (UInt32)GetBitsFromValue(temp_reg[3],4,0);
    cke_TX120PULLDWN_0  = (UInt32)GetBitsFromValue(temp_reg[3],6,5);
    cke_TX_LOWSPEED_BYPASS_0  = (UInt32)GetBitsFromValue(temp_reg[3],7,7);
    cke_SLEWN_0  = (UInt32)GetBitsFromValue(temp_reg[3],10,8);
    cke_SLEWP_0  = (UInt32)GetBitsFromValue(temp_reg[3],13,11);
    cke_MODE_0  = (UInt32)GetBitsFromValue(temp_reg[3],17,14);
    cke_SPEED_0  = (UInt32)GetBitsFromValue(temp_reg[3],19,18);
    cke_BOOSTN_0  = (UInt32)GetBitsFromValue(temp_reg[3],23,20);
    cke_BOOSTP_0  = (UInt32)GetBitsFromValue(temp_reg[3],27,24);
    cke_TX_PCAS_DIS_0  = (UInt32)GetBitsFromValue(temp_reg[3],28,28);
    cke_TX_NCAS_DIS_0  = (UInt32)GetBitsFromValue(temp_reg[3],29,29);

    cke_RX_DCD_0  = (UInt32)GetBitsFromValue(temp_reg[4],4,0);
    cke_RX_CTLE_0  = (UInt32)GetBitsFromValue(temp_reg[4],7,5);
    cke_RX_OFFSET_0  = (UInt32)GetBitsFromValue(temp_reg[4],16,8);
    cke_ENSLICEN_0  = (UInt32)GetBitsFromValue(temp_reg[4],20,17);
    cke_ENSLICEP_0  = (UInt32)GetBitsFromValue(temp_reg[4],24,21);
    cke_TX_FFE_0  = (UInt32)GetBitsFromValue(temp_reg[4],26,25);
    cke_RX_IE_CAL_ALL_0  = (UInt32)GetBitsFromValue(temp_reg[4],27,27);
    cke_DRV_TP_0  = (UInt32)GetBitsFromValue(temp_reg[4],28,28);

    cke_PVTR_0  = (UInt32)GetBitsFromValue(temp_reg[5],16,12);
    cke_PVTN_0  = (UInt32)GetBitsFromValue(temp_reg[5],11,6);
    cke_PVTP_0  = (UInt32)GetBitsFromValue(temp_reg[5],5,0);
    cke_TSEL_0  = (UInt32)GetBitsFromValue(temp_reg[5],17,17);




}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_ENSLICEN_0 , temp_reg[0] ,3,0);
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_ENSLICEP_0 , temp_reg[0] ,7,4);
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_SLEWN_0 , temp_reg[0] ,10,8);
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_SLEWP_0 , temp_reg[0] ,13,11);
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_MODE_0 , temp_reg[0] ,17,14);
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_SPEED_0 , temp_reg[0] ,19,18);
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_RXDQEN_0 , temp_reg[0] ,20,20);
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_TX120PULLDWN_0 , temp_reg[0] ,22,21);
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_BOOSTN_0 , temp_reg[0] ,26,23);
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_BOOSTP_0 , temp_reg[0] ,30,27);
    temp_reg[0] = (UInt32)WriteBitsToValue(mem_clk_RPULL_0 , temp_reg[0] ,31,31);
    temp_reg[1] = (UInt32)WriteBitsToValue(mem_clk_TX_DCD_0 , temp_reg[1] ,4,0);
    temp_reg[1] = (UInt32)WriteBitsToValue(mem_clk_RX_DCD_0 , temp_reg[1] ,9,5);
    temp_reg[1] = (UInt32)WriteBitsToValue(mem_clk_TX_PCAS_DIS_0 , temp_reg[1] ,10,10);
    temp_reg[1] = (UInt32)WriteBitsToValue(mem_clk_TX_NCAS_DIS_0 , temp_reg[1] ,11,11);
    temp_reg[1] = (UInt32)WriteBitsToValue(mem_clk_RX_CTLE_0 , temp_reg[1] ,14,12);
    temp_reg[1] = (UInt32)WriteBitsToValue(mem_clk_TX_LOWSPEED_BYPASS_0 , temp_reg[1] ,15,15);
    temp_reg[1] = (UInt32)WriteBitsToValue(mem_clk_TX_FFE_0 , temp_reg[1] ,17,16);
    temp_reg[1] = (UInt32)WriteBitsToValue(mem_clk_RX_IE_CAL_ALL_0 , temp_reg[1] ,18,18);
    temp_reg[1] = (UInt32)WriteBitsToValue(mem_clk_DRV_TP_0 , temp_reg[1] ,19,19);
    temp_reg[2] = (UInt32)WriteBitsToValue(mem_clk_PVTR_0 , temp_reg[2] ,16,12);
    temp_reg[2] = (UInt32)WriteBitsToValue(mem_clk_PVTN_0 , temp_reg[2] ,11,6);
    temp_reg[2] = (UInt32)WriteBitsToValue(mem_clk_PVTP_0 , temp_reg[2] ,5,0);
    temp_reg[2] = (UInt32)WriteBitsToValue(mem_clk_TSEL_0 , temp_reg[2] ,17,17);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_TX_DCD_0 , temp_reg[3] ,4,0);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_TX120PULLDWN_0 , temp_reg[3] ,6,5);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_TX_LOWSPEED_BYPASS_0 , temp_reg[3] ,7,7);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_SLEWN_0 , temp_reg[3] ,10,8);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_SLEWP_0 , temp_reg[3] ,13,11);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_MODE_0 , temp_reg[3] ,17,14);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_SPEED_0 , temp_reg[3] ,19,18);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_BOOSTN_0 , temp_reg[3] ,23,20);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_BOOSTP_0 , temp_reg[3] ,27,24);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_TX_PCAS_DIS_0 , temp_reg[3] ,28,28);
    temp_reg[3] = (UInt32)WriteBitsToValue(cke_TX_NCAS_DIS_0 , temp_reg[3] ,29,29);
    temp_reg[4] = (UInt32)WriteBitsToValue(cke_RX_DCD_0 , temp_reg[4] ,4,0);
    temp_reg[4] = (UInt32)WriteBitsToValue(cke_RX_CTLE_0 , temp_reg[4] ,7,5);
    temp_reg[4] = (UInt32)WriteBitsToValue(cke_RX_OFFSET_0 , temp_reg[4] ,16,8);
    temp_reg[4] = (UInt32)WriteBitsToValue(cke_ENSLICEN_0 , temp_reg[4] ,20,17);
    temp_reg[4] = (UInt32)WriteBitsToValue(cke_ENSLICEP_0 , temp_reg[4] ,24,21);
    temp_reg[4] = (UInt32)WriteBitsToValue(cke_TX_FFE_0 , temp_reg[4] ,26,25);
    temp_reg[4] = (UInt32)WriteBitsToValue(cke_RX_IE_CAL_ALL_0 , temp_reg[4] ,27,27);
    temp_reg[4] = (UInt32)WriteBitsToValue(cke_DRV_TP_0 , temp_reg[4] ,28,28);
    temp_reg[5] = (UInt32)WriteBitsToValue(cke_PVTR_0 , temp_reg[5] ,16,12);
    temp_reg[5] = (UInt32)WriteBitsToValue(cke_PVTN_0 , temp_reg[5] ,11,6);
    temp_reg[5] = (UInt32)WriteBitsToValue(cke_PVTP_0 , temp_reg[5] ,5,0);
    temp_reg[5] = (UInt32)WriteBitsToValue(cke_TSEL_0 , temp_reg[5] ,17,17);
    jtag_dll_mc_reg_write(1414, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(1415, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(1334, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(1418, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(1419, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(1336, temp_reg[5] ,true);
}
