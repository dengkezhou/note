//****************************************************************************************
//                       © 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence’s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public bool bist_fn()
{
	ulong 	pass_count 		= 0;
	ulong 	fail_count 		= 0;
  	ulong 	loop_count 		= lp_count;
  	bool 	bist_result 	= false;
	ulong 	cs_map_orig  =0;
	
	if(loop_count==0)
	{
		print_message("Loop Count value cannot be Zero. Minimum Loop Count value is One \n");
 		return bist_result;
    }

	if (pi_bist ==1)
	{
		cs_map_orig = GetBitsFromValue(jtag_dll_pi_reg_read(PI_CS_MAP_ADDR),(int)(PI_CS_MAP_OFFSET+(PI_CS_MAP_WIDTH-1)),(int)(PI_CS_MAP_OFFSET));
		jtag_dll_pi_reg_write(PI_CS_MAP_ADDR,WriteBitsToValue(chipselect,jtag_dll_pi_reg_read(PI_CS_MAP_ADDR),(int)(PI_CS_MAP_OFFSET+(PI_CS_MAP_WIDTH-1)),(int)(PI_CS_MAP_OFFSET)));
	}
	else
	{
		cs_map_orig = GetBitsFromValue(jtag_dll_mc_reg_read(CS_MAP_ADDR),(int)(CS_MAP_OFFSET+(CS_MAP_WIDTH-1)),(int)(CS_MAP_OFFSET));
		jtag_dll_mc_reg_write(CS_MAP_ADDR,WriteBitsToValue(chipselect,jtag_dll_mc_reg_read(CS_MAP_ADDR),(int)(CS_MAP_OFFSET+(CS_MAP_WIDTH-1)),(int)(CS_MAP_OFFSET)));
	}
	
	jtag_dll_mc_reg_write(IN_ORDER_ACCEPT_ADDR,WriteBitsToValue(1,jtag_dll_mc_reg_read(IN_ORDER_ACCEPT_ADDR),(int)IN_ORDER_ACCEPT_OFFSET,(int)IN_ORDER_ACCEPT_OFFSET));

	while (loop_count != 0)
	{
		loop_count-- ;
		Application.DoEvents();

		if(pi_bist ==1)
			bist_result = pi_mbist(start_addr, data_mask0, data_mask1, data_ck, addr_sp, chipselect);
		else
			bist_result = ctlr_mbist(start_addr, data_mask0, data_mask1, data_ck, addr_sp, chipselect);

		if(stop_bist == 0x1)
		{
			restore_cs(cs_map_orig);
			jtag_dll_mc_reg_write(IN_ORDER_ACCEPT_ADDR,WriteBitsToValue(0,jtag_dll_mc_reg_read(IN_ORDER_ACCEPT_ADDR),(int)IN_ORDER_ACCEPT_OFFSET,(int)IN_ORDER_ACCEPT_OFFSET));
			print_message ("BIST Stopped \n");
			return bist_result;
		}

		if (bist_result == true)
		{
			pass_count = pass_count + 1;
		}
		else
		{
			fail_count = fail_count + 1;

			if(pi_bist ==1)
			{
				// PI_BIST_FAIL_ADDR:RD:0:34
				adr_fail = (ulong)jtag_dll_pi_reg_read(PI_BIST_FAIL_ADDR_ADDR);
				ulong addr_msb = jtag_dll_pi_reg_read(PI_BIST_FAIL_ADDR_ADDR+1);
				addr_msb = addr_msb & 0x3;
				adr_fail |= (addr_msb << (int)32);
			
				// PI_BIST_EXP_DATA:RD:0:128:=0x00000000
				exp_data0 = jtag_dll_pi_reg_read(PI_BIST_EXP_DATA_ADDR);
				exp_data0 |= (jtag_dll_pi_reg_read(PI_BIST_EXP_DATA_ADDR+1) << (int)32);
				exp_data1 = jtag_dll_pi_reg_read(PI_BIST_EXP_DATA_ADDR+2);
				exp_data1 |= (jtag_dll_pi_reg_read(PI_BIST_EXP_DATA_ADDR+3) << (int)32);
				
				// PI_BIST_FAIL_DATA:RD:0:128:=0x00000000
				data_fail0 = jtag_dll_pi_reg_read(PI_BIST_FAIL_DATA_ADDR);
				data_fail0 |= (jtag_dll_pi_reg_read(PI_BIST_FAIL_DATA_ADDR+1) << (int)32);
				data_fail1 = jtag_dll_pi_reg_read(PI_BIST_FAIL_DATA_ADDR+2);
				data_fail1 |= (jtag_dll_pi_reg_read(PI_BIST_FAIL_DATA_ADDR+3) << (int)32);
				
			}
			else
			{
				// BIST_FAIL_ADDR:RD:0:36:=0x00000000
				adr_fail = (ulong)jtag_dll_mc_reg_read(BIST_FAIL_ADDR_ADDR);
				ulong addr_msb = jtag_dll_mc_reg_read(BIST_FAIL_ADDR_ADDR+1);
				addr_msb = addr_msb & 0xf;
				adr_fail |= (addr_msb << (int)32);
			
				// BIST_EXP_DATA:RD:0:128:=0x00000000
				exp_data0 = jtag_dll_mc_reg_read(BIST_EXP_DATA_ADDR);
				exp_data0 |= (jtag_dll_mc_reg_read(BIST_EXP_DATA_ADDR+1) << (int)32);
				exp_data1 = jtag_dll_mc_reg_read(BIST_EXP_DATA_ADDR+2);
				exp_data1 |= (jtag_dll_mc_reg_read(BIST_EXP_DATA_ADDR+3) << (int)32);
								
				// BIST_FAIL_DATA:RD:0:128:=0x00000000
				data_fail0 = jtag_dll_mc_reg_read(BIST_FAIL_DATA_ADDR);
				data_fail0 |= (jtag_dll_mc_reg_read(BIST_FAIL_DATA_ADDR+1) << (int)32);
				data_fail1 = jtag_dll_mc_reg_read(BIST_FAIL_DATA_ADDR+2);
				data_fail1 |= (jtag_dll_mc_reg_read(BIST_FAIL_DATA_ADDR+3) << (int)32);
			}
		}
	}
	restore_cs(cs_map_orig);
	jtag_dll_mc_reg_write(IN_ORDER_ACCEPT_ADDR,WriteBitsToValue(0,jtag_dll_mc_reg_read(IN_ORDER_ACCEPT_ADDR),(int)IN_ORDER_ACCEPT_OFFSET,(int)IN_ORDER_ACCEPT_OFFSET));

	print_message("Pass count = " +pass_count.ToString() + "\n");
	print_message("Fail count = " +fail_count.ToString() + "\n");
	if(pi_bist ==1)
		print_message("PI BIST Completed \n");
	else
		print_message("CTLR BIST Completed \n");

	return bist_result;
}

public bool pi_mbist(ulong start_addr, ulong data_mask0, ulong data_mask1, ulong bist_type, ulong address_space, ulong cs_map)
{
	bool success = true;
	ulong pi_int_stat;
  	ulong bit_pos = (ulong)(1 << (int)(PI_BIST_DONE_BIT));
 	UInt32 counter = 0;

	ulong	cs_map_orig = GetBitsFromValue(jtag_dll_pi_reg_read(PI_CS_MAP_ADDR),(int)(PI_CS_MAP_OFFSET+(PI_CS_MAP_WIDTH-1)),(int)(PI_CS_MAP_OFFSET));
	jtag_dll_pi_reg_write(PI_CS_MAP_ADDR,WriteBitsToValue(cs_map,jtag_dll_pi_reg_read(PI_CS_MAP_ADDR),(int)(PI_CS_MAP_OFFSET+(PI_CS_MAP_WIDTH-1)),(int)(PI_CS_MAP_OFFSET)));
	
	jtag_dll_mc_reg_write(IN_ORDER_ACCEPT_ADDR,WriteBitsToValue(1,jtag_dll_mc_reg_read(IN_ORDER_ACCEPT_ADDR),(int)IN_ORDER_ACCEPT_OFFSET,(int)IN_ORDER_ACCEPT_OFFSET));

	// BIST address space
	jtag_dll_pi_reg_write(PI_ADDR_SPACE_ADDR, WriteBitsToValue(address_space, jtag_dll_pi_reg_read(PI_ADDR_SPACE_ADDR), (int)(PI_ADDR_SPACE_OFFSET+(PI_ADDR_SPACE_WIDTH-1)), (int)(PI_ADDR_SPACE_OFFSET)));

	// BIST start address
	// PI_BIST_START_ADDRESS:RW:0:34
	jtag_dll_pi_reg_write(PI_BIST_START_ADDRESS_ADDR, WriteBitsToValue(start_addr, jtag_dll_pi_reg_read(PI_BIST_START_ADDRESS_ADDR), 31, 0));
	ulong start_addr_msb = (ulong) start_addr >> 32;
	jtag_dll_pi_reg_write(PI_BIST_START_ADDRESS_ADDR + 1, WriteBitsToValue(start_addr_msb, jtag_dll_pi_reg_read(PI_BIST_START_ADDRESS_ADDR + 1), 1, 0));

  	if(bist_type == 0x0)	// BIST Address check (bist_type == 0x0)
  	{
  		// Clear data checking
		jtag_dll_pi_reg_write(PI_BIST_DATA_CHECK_ADDR,WriteBitsToValue(0x0, jtag_dll_pi_reg_read(PI_BIST_DATA_CHECK_ADDR),(int)PI_BIST_DATA_CHECK_OFFSET,(int)PI_BIST_DATA_CHECK_OFFSET));

		// Set address checking
		jtag_dll_pi_reg_write(PI_BIST_ADDR_CHECK_ADDR,WriteBitsToValue(0x1,jtag_dll_pi_reg_read(PI_BIST_ADDR_CHECK_ADDR),(int)PI_BIST_ADDR_CHECK_OFFSET,(int)PI_BIST_ADDR_CHECK_OFFSET));
  	}
  	else
  	{
		jtag_dll_pi_reg_write(PI_BIST_DATA_CHECK_ADDR,WriteBitsToValue(0x1, jtag_dll_pi_reg_read(PI_BIST_DATA_CHECK_ADDR),(int)PI_BIST_DATA_CHECK_OFFSET,(int)PI_BIST_DATA_CHECK_OFFSET));
		jtag_dll_pi_reg_write(PI_BIST_ADDR_CHECK_ADDR,WriteBitsToValue(0x0,jtag_dll_pi_reg_read(PI_BIST_ADDR_CHECK_ADDR),(int)PI_BIST_ADDR_CHECK_OFFSET,(int)PI_BIST_ADDR_CHECK_OFFSET));
  	}

	// PI_BIST_DATA_MASK:RW:0:64:
	jtag_dll_pi_reg_write(PI_BIST_DATA_MASK_ADDR,data_mask0);
	jtag_dll_pi_reg_write((PI_BIST_DATA_MASK_ADDR+1),data_mask1);
	
  	// Set the bist_go parameter
	jtag_dll_pi_reg_write(PI_BIST_GO_ADDR, WriteBitsToValue(0x1,jtag_dll_pi_reg_read(PI_BIST_GO_ADDR), (int)PI_BIST_GO_OFFSET,(int)PI_BIST_GO_OFFSET));
	Thread.Sleep(100);

  	do
	{
		pi_int_stat = GetBitsFromValue(jtag_dll_pi_reg_read(PI_INT_STATUS_ADDR),28,0);

		Application.DoEvents();
		Thread.Sleep(100);
		counter++;
		if(counter > (100*60))
		{
			print_message("Exiting on counter expiration. \n");
			success = false;
			break;
		}
	}while(((pi_int_stat & bit_pos) != bit_pos) && (stop_bist ==0));

	jtag_dll_mc_reg_write(IN_ORDER_ACCEPT_ADDR,WriteBitsToValue(0,jtag_dll_mc_reg_read(IN_ORDER_ACCEPT_ADDR),(int)IN_ORDER_ACCEPT_OFFSET,(int)IN_ORDER_ACCEPT_OFFSET));

	jtag_dll_pi_reg_write(PI_INT_ACK_ADDR, WriteBitsToValue(bit_pos,jtag_dll_pi_reg_read(PI_INT_ACK_ADDR), (int)(PI_INT_ACK_OFFSET + (PI_INT_ACK_WIDTH-1)),(int)PI_INT_ACK_OFFSET));

  	ulong bist_rslt = GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_RESULT_ADDR),(int)(PI_BIST_RESULT_OFFSET+(PI_BIST_RESULT_WIDTH-1)),(int)(PI_BIST_RESULT_OFFSET));

	jtag_dll_pi_reg_write(PI_BIST_GO_ADDR, WriteBitsToValue(0x0,jtag_dll_pi_reg_read(PI_BIST_GO_ADDR), (int)PI_BIST_GO_OFFSET,(int)PI_BIST_GO_OFFSET));
	
	jtag_dll_pi_reg_write(PI_BIST_DATA_CHECK_ADDR,WriteBitsToValue(0x0, jtag_dll_pi_reg_read(PI_BIST_DATA_CHECK_ADDR),(int)PI_BIST_DATA_CHECK_OFFSET,(int)PI_BIST_DATA_CHECK_OFFSET));
	jtag_dll_pi_reg_write(PI_BIST_ADDR_CHECK_ADDR,WriteBitsToValue(0x0,jtag_dll_pi_reg_read(PI_BIST_ADDR_CHECK_ADDR),(int)PI_BIST_ADDR_CHECK_OFFSET,(int)PI_BIST_ADDR_CHECK_OFFSET));

	jtag_dll_pi_reg_write(PI_CS_MAP_ADDR,WriteBitsToValue(cs_map_orig,jtag_dll_pi_reg_read(PI_CS_MAP_ADDR),(int)(PI_CS_MAP_OFFSET+(PI_CS_MAP_WIDTH-1)),(int)(PI_CS_MAP_OFFSET)));
	
	if( stop_bist==1)
		return false;

	if(bist_type == 0x0)	// BIST address check
	{
		bist_rslt = bist_rslt >> (int)0x1;
		if(bist_rslt == 0x1)
		{
			success = true;
		}
		else
		{
			success = false;
		}
	}
  	else	// BIST data check
	{
		bist_rslt &= 0x1;
		if(bist_rslt == 0x1)
		{
			success = true;
		}
		else
		{
			success = false;
		}
	}
	return success;
}

public bool ctlr_mbist(ulong start_addr, ulong data_mask0, ulong data_mask1, ulong bist_type, ulong address_space, ulong cs_map)
{
	bool success = true;
	ulong int_stat;
  	ulong bit_pos = (ulong)(1 << (int)(INT_BIST_BIST_DONE_BIT_INDEX));
 	UInt32 counter = 0;

	ulong	cs_map_orig = GetBitsFromValue(jtag_dll_mc_reg_read(CS_MAP_ADDR),(int)(CS_MAP_OFFSET+(CS_MAP_WIDTH-1)),(int)(CS_MAP_OFFSET));
	jtag_dll_mc_reg_write(CS_MAP_ADDR,WriteBitsToValue(cs_map,jtag_dll_mc_reg_read(CS_MAP_ADDR),(int)(CS_MAP_OFFSET+(CS_MAP_WIDTH-1)),(int)(CS_MAP_OFFSET)));
	
	jtag_dll_mc_reg_write(IN_ORDER_ACCEPT_ADDR,WriteBitsToValue(1,jtag_dll_mc_reg_read(IN_ORDER_ACCEPT_ADDR),(int)IN_ORDER_ACCEPT_OFFSET,(int)IN_ORDER_ACCEPT_OFFSET));

	// BIST address space
	jtag_dll_mc_reg_write(ADDR_SPACE_ADDR, WriteBitsToValue(address_space, jtag_dll_mc_reg_read(ADDR_SPACE_ADDR), (int)(ADDR_SPACE_OFFSET+(ADDR_SPACE_WIDTH-1)), (int)(ADDR_SPACE_OFFSET)));

	// BIST start address
	// BIST_START_ADDRESS:RW:0:36
	jtag_dll_mc_reg_write(BIST_START_ADDRESS_ADDR, WriteBitsToValue(start_addr, jtag_dll_mc_reg_read(BIST_START_ADDRESS_ADDR), 31, 0));
	ulong start_addr_msb = (ulong) start_addr >> 32;
    jtag_dll_mc_reg_write((BIST_START_ADDRESS_ADDR + 1), WriteBitsToValue(start_addr_msb, jtag_dll_mc_reg_read((BIST_START_ADDRESS_ADDR+1)), 3, 0));

  	if(bist_type == 0x0)	// BIST Address check (bist_type == 0x0)
  	{
  		// Clear data checking
		jtag_dll_mc_reg_write(BIST_DATA_CHECK_ADDR,WriteBitsToValue(0x0, jtag_dll_mc_reg_read(BIST_DATA_CHECK_ADDR),(int)BIST_DATA_CHECK_OFFSET,(int)BIST_DATA_CHECK_OFFSET));

		// Set address checking
		jtag_dll_mc_reg_write(BIST_ADDR_CHECK_ADDR,WriteBitsToValue(0x1,jtag_dll_mc_reg_read(BIST_ADDR_CHECK_ADDR),(int)BIST_ADDR_CHECK_OFFSET,(int)BIST_ADDR_CHECK_OFFSET));
  	}
  	else
  	{
		jtag_dll_mc_reg_write(BIST_DATA_CHECK_ADDR,WriteBitsToValue(0x1, jtag_dll_mc_reg_read(BIST_DATA_CHECK_ADDR),(int)BIST_DATA_CHECK_OFFSET,(int)BIST_DATA_CHECK_OFFSET));
		jtag_dll_mc_reg_write(BIST_ADDR_CHECK_ADDR,WriteBitsToValue(0x0,jtag_dll_mc_reg_read(BIST_ADDR_CHECK_ADDR),(int)BIST_ADDR_CHECK_OFFSET,(int)BIST_ADDR_CHECK_OFFSET));
  	}

	// BIST_DATA_MASK:RW:0:64
	jtag_dll_mc_reg_write(BIST_DATA_MASK_ADDR, data_mask0);
	jtag_dll_mc_reg_write(BIST_DATA_MASK_ADDR + 1, data_mask1);

  	// Set the bist_go parameter
	jtag_dll_mc_reg_write(BIST_GO_ADDR, WriteBitsToValue(0x1,jtag_dll_mc_reg_read(BIST_GO_ADDR), (int)BIST_GO_OFFSET,(int)BIST_GO_OFFSET));
	Thread.Sleep(100);

  	do
	{
		int_stat = GetBitsFromValue(jtag_dll_mc_reg_read(INT_STATUS_BIST_ADDR),(int)(INT_STATUS_BIST_OFFSET + (INT_STATUS_BIST_WIDTH-1)),(int)INT_STATUS_BIST_OFFSET);

		Application.DoEvents();
		Thread.Sleep(100);

		counter++;
		if(counter > (100*60))
		{
			print_message("Exiting on counter expiration. \n");
			success = false;
			break;
		}
	}while(((int_stat & bit_pos) != bit_pos) && (stop_bist ==0));

	jtag_dll_mc_reg_write(IN_ORDER_ACCEPT_ADDR,WriteBitsToValue(0,jtag_dll_mc_reg_read(IN_ORDER_ACCEPT_ADDR),(int)IN_ORDER_ACCEPT_OFFSET,(int)IN_ORDER_ACCEPT_OFFSET));

	jtag_dll_mc_reg_write(INT_ACK_BIST_ADDR, WriteBitsToValue(bit_pos,jtag_dll_mc_reg_read(INT_ACK_BIST_ADDR), (int)(INT_ACK_BIST_OFFSET + (INT_ACK_BIST_WIDTH-1)),(int)INT_ACK_BIST_OFFSET));

  	ulong bist_rslt = GetBitsFromValue(jtag_dll_mc_reg_read(BIST_RESULT_ADDR),(int)(BIST_RESULT_OFFSET+(BIST_RESULT_WIDTH-1)),(int)(BIST_RESULT_OFFSET));
	jtag_dll_mc_reg_write(BIST_GO_ADDR, WriteBitsToValue(0x0,jtag_dll_mc_reg_read(BIST_GO_ADDR), (int)BIST_GO_OFFSET,(int)BIST_GO_OFFSET));

	jtag_dll_mc_reg_write(BIST_DATA_CHECK_ADDR,WriteBitsToValue(0x0, jtag_dll_mc_reg_read(BIST_DATA_CHECK_ADDR),(int)BIST_DATA_CHECK_OFFSET,(int)BIST_DATA_CHECK_OFFSET));
	jtag_dll_mc_reg_write(BIST_ADDR_CHECK_ADDR,WriteBitsToValue(0x0,jtag_dll_mc_reg_read(BIST_ADDR_CHECK_ADDR),(int)BIST_ADDR_CHECK_OFFSET,(int)BIST_ADDR_CHECK_OFFSET));

	jtag_dll_mc_reg_write(CS_MAP_ADDR,WriteBitsToValue(cs_map_orig, jtag_dll_mc_reg_read(CS_MAP_ADDR),(int)(CS_MAP_OFFSET+(CS_MAP_WIDTH-1)),(int)(CS_MAP_OFFSET)));
	
	if( stop_bist==1)
		return false;

  	if(bist_type == 0x0)	// BIST address check
	{
		bist_rslt = bist_rslt >> (int)0x1;
		if(bist_rslt == 0x1)
		{
			success = true;
		}
		else
		{
			success = false;
		}
	}
  	else	// BIST data check
	{
		bist_rslt &= 0x1;
		if(bist_rslt == 0x1)
		{
			success = true;
		}
		else
		{
			success = false;
		}
	}

	return success;
}

void bist_parameters_write()
{
	jtag_dll_pi_reg_write(PI_BIST_MODE_ADDR,WriteBitsToValue(pi_bist_mode_0,jtag_dll_pi_reg_read(PI_BIST_MODE_ADDR),(int)(PI_BIST_MODE_OFFSET+(PI_BIST_MODE_WIDTH-1)),(int)(PI_BIST_MODE_OFFSET)));
	jtag_dll_pi_reg_write(PI_BIST_PAT_NUM_ADDR,WriteBitsToValue(pi_bist_pat_num,jtag_dll_pi_reg_read(PI_BIST_PAT_NUM_ADDR),(int)(PI_BIST_PAT_NUM_OFFSET+(PI_BIST_PAT_NUM_WIDTH-1)),(int)(PI_BIST_PAT_NUM_OFFSET)));
	jtag_dll_pi_reg_write(PI_BIST_ADDR_MODE_ADDR,WriteBitsToValue(pi_bist_addr_mode_0,jtag_dll_pi_reg_read(PI_BIST_ADDR_MODE_ADDR),(int)(PI_BIST_ADDR_MODE_OFFSET+(PI_BIST_ADDR_MODE_WIDTH-1)),(int)(PI_BIST_ADDR_MODE_OFFSET)));
	
	jtag_dll_pi_reg_write(PI_BIST_PAT_MODE_ADDR,WriteBitsToValue(pi_bist_pat_mode_0,jtag_dll_pi_reg_read(PI_BIST_PAT_MODE_ADDR),(int)(PI_BIST_PAT_MODE_OFFSET+(PI_BIST_PAT_MODE_WIDTH-1)),(int)(PI_BIST_PAT_MODE_OFFSET)));
	// PI_BIST_USER_PAT:RW:0:128:=0x00000000
	jtag_dll_pi_reg_write(PI_BIST_USER_PAT_ADDR,WriteBitsToValue(pi_bist_user_pat_0,jtag_dll_pi_reg_read(PI_BIST_USER_PAT_ADDR),(int)(PI_BIST_USER_PAT_OFFSET+(32-1)),(int)(PI_BIST_USER_PAT_OFFSET)));
	jtag_dll_pi_reg_write((PI_BIST_USER_PAT_ADDR + 1),WriteBitsToValue(pi_bist_user_pat_1,jtag_dll_pi_reg_read(PI_BIST_USER_PAT_ADDR + 1),(int)(PI_BIST_USER_PAT_OFFSET+(32-1)),(int)(PI_BIST_USER_PAT_OFFSET)));
	jtag_dll_pi_reg_write((PI_BIST_USER_PAT_ADDR + 2),WriteBitsToValue(pi_bist_user_pat_2,jtag_dll_pi_reg_read(PI_BIST_USER_PAT_ADDR + 2),(int)(PI_BIST_USER_PAT_OFFSET+(32-1)),(int)(PI_BIST_USER_PAT_OFFSET)));
	jtag_dll_pi_reg_write((PI_BIST_USER_PAT_ADDR + 3),WriteBitsToValue(pi_bist_user_pat_3,jtag_dll_pi_reg_read(PI_BIST_USER_PAT_ADDR + 3),(int)(PI_BIST_USER_PAT_OFFSET+(32-1)),(int)(PI_BIST_USER_PAT_OFFSET)));


	jtag_dll_pi_reg_write((PI_BIST_STAGE_0_ADDR),WriteBitsToValue(pi_bist_stage_0,jtag_dll_pi_reg_read(PI_BIST_STAGE_0_ADDR),(int)(PI_BIST_STAGE_0_OFFSET+(PI_BIST_STAGE_0_WIDTH-1)),(int)(PI_BIST_STAGE_0_OFFSET)));
	jtag_dll_pi_reg_write((PI_BIST_STAGE_1_ADDR),WriteBitsToValue(pi_bist_stage_1,jtag_dll_pi_reg_read(PI_BIST_STAGE_1_ADDR),(int)(PI_BIST_STAGE_1_OFFSET+(PI_BIST_STAGE_1_WIDTH-1)),(int)(PI_BIST_STAGE_1_OFFSET)));
	jtag_dll_pi_reg_write((PI_BIST_STAGE_2_ADDR),WriteBitsToValue(pi_bist_stage_2,jtag_dll_pi_reg_read(PI_BIST_STAGE_2_ADDR),(int)(PI_BIST_STAGE_2_OFFSET+(PI_BIST_STAGE_2_WIDTH-1)),(int)(PI_BIST_STAGE_2_OFFSET)));
	jtag_dll_pi_reg_write((PI_BIST_STAGE_3_ADDR),WriteBitsToValue(pi_bist_stage_3,jtag_dll_pi_reg_read(PI_BIST_STAGE_3_ADDR),(int)(PI_BIST_STAGE_3_OFFSET+(PI_BIST_STAGE_3_WIDTH-1)),(int)(PI_BIST_STAGE_3_OFFSET)));
	jtag_dll_pi_reg_write((PI_BIST_STAGE_4_ADDR),WriteBitsToValue(pi_bist_stage_4,jtag_dll_pi_reg_read(PI_BIST_STAGE_4_ADDR),(int)(PI_BIST_STAGE_4_OFFSET+(PI_BIST_STAGE_4_WIDTH-1)),(int)(PI_BIST_STAGE_4_OFFSET)));
	jtag_dll_pi_reg_write((PI_BIST_STAGE_5_ADDR),WriteBitsToValue(pi_bist_stage_5,jtag_dll_pi_reg_read(PI_BIST_STAGE_5_ADDR),(int)(PI_BIST_STAGE_5_OFFSET+(PI_BIST_STAGE_5_WIDTH-1)),(int)(PI_BIST_STAGE_5_OFFSET)));
	jtag_dll_pi_reg_write((PI_BIST_STAGE_6_ADDR),WriteBitsToValue(pi_bist_stage_6,jtag_dll_pi_reg_read(PI_BIST_STAGE_6_ADDR),(int)(PI_BIST_STAGE_6_OFFSET+(PI_BIST_STAGE_6_WIDTH-1)),(int)(PI_BIST_STAGE_6_OFFSET)));
	jtag_dll_pi_reg_write((PI_BIST_STAGE_7_ADDR),WriteBitsToValue(pi_bist_stage_7,jtag_dll_pi_reg_read(PI_BIST_STAGE_7_ADDR),(int)(PI_BIST_STAGE_7_OFFSET+(PI_BIST_STAGE_7_WIDTH-1)),(int)(PI_BIST_STAGE_7_OFFSET)));
	
	
}

void bist_parameters_read()
{
	pi_bist_addr_mode_0 = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_ADDR_MODE_ADDR),(int)(PI_BIST_ADDR_MODE_OFFSET+(PI_BIST_ADDR_MODE_WIDTH-1)),(int)(PI_BIST_ADDR_MODE_OFFSET));
	pi_bist_mode_0 		= (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_MODE_ADDR),(int)(PI_BIST_MODE_OFFSET+(PI_BIST_MODE_WIDTH-1)),(int)(PI_BIST_MODE_OFFSET));
	pi_bist_pat_num     = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_PAT_NUM_ADDR),(int)(PI_BIST_PAT_NUM_OFFSET+(PI_BIST_PAT_NUM_WIDTH-1)),(int)(PI_BIST_PAT_NUM_OFFSET));
	
	pi_bist_pat_mode_0 	= (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_PAT_MODE_ADDR),(int)(PI_BIST_PAT_MODE_OFFSET+(PI_BIST_PAT_MODE_WIDTH-1)),(int)(PI_BIST_PAT_MODE_OFFSET));
	pi_bist_user_pat_0 	= (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_USER_PAT_ADDR),(int)(PI_BIST_USER_PAT_OFFSET+(32-1)),(int)(PI_BIST_USER_PAT_OFFSET));
	pi_bist_user_pat_1 	= (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read((PI_BIST_USER_PAT_ADDR + 1)),(int)(PI_BIST_USER_PAT_OFFSET+(32-1)),(int)(PI_BIST_USER_PAT_OFFSET));
	pi_bist_user_pat_2 	= (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read((PI_BIST_USER_PAT_ADDR + 2)),(int)(PI_BIST_USER_PAT_OFFSET+(32-1)),(int)(PI_BIST_USER_PAT_OFFSET));
	pi_bist_user_pat_3 	= (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read((PI_BIST_USER_PAT_ADDR + 3)),(int)(PI_BIST_USER_PAT_OFFSET+(32-1)),(int)(PI_BIST_USER_PAT_OFFSET));


	pi_bist_stage_0     = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_STAGE_0_ADDR),(int)(PI_BIST_STAGE_0_OFFSET+(PI_BIST_STAGE_0_WIDTH-1)),(int)(PI_BIST_STAGE_0_OFFSET));
	pi_bist_stage_1     = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_STAGE_1_ADDR),(int)(PI_BIST_STAGE_0_OFFSET+(PI_BIST_STAGE_1_WIDTH-1)),(int)(PI_BIST_STAGE_0_OFFSET));
	pi_bist_stage_2     = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_STAGE_2_ADDR),(int)(PI_BIST_STAGE_0_OFFSET+(PI_BIST_STAGE_2_WIDTH-1)),(int)(PI_BIST_STAGE_0_OFFSET));
	pi_bist_stage_3     = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_STAGE_3_ADDR),(int)(PI_BIST_STAGE_0_OFFSET+(PI_BIST_STAGE_3_WIDTH-1)),(int)(PI_BIST_STAGE_0_OFFSET));
	pi_bist_stage_4     = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_STAGE_4_ADDR),(int)(PI_BIST_STAGE_0_OFFSET+(PI_BIST_STAGE_4_WIDTH-1)),(int)(PI_BIST_STAGE_0_OFFSET));
	pi_bist_stage_5     = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_STAGE_5_ADDR),(int)(PI_BIST_STAGE_0_OFFSET+(PI_BIST_STAGE_5_WIDTH-1)),(int)(PI_BIST_STAGE_0_OFFSET));
	pi_bist_stage_6     = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_STAGE_6_ADDR),(int)(PI_BIST_STAGE_0_OFFSET+(PI_BIST_STAGE_6_WIDTH-1)),(int)(PI_BIST_STAGE_0_OFFSET));
	pi_bist_stage_7     = (UInt32)GetBitsFromValue(jtag_dll_pi_reg_read(PI_BIST_STAGE_7_ADDR),(int)(PI_BIST_STAGE_0_OFFSET+(PI_BIST_STAGE_7_WIDTH-1)),(int)(PI_BIST_STAGE_0_OFFSET));
	
}

void restore_cs(ulong cs_map_orig_val)
{
	if(pi_bist ==1)
	jtag_dll_pi_reg_write(PI_CS_MAP_ADDR,WriteBitsToValue(cs_map_orig_val,jtag_dll_pi_reg_read(PI_CS_MAP_ADDR),(int)(PI_CS_MAP_OFFSET+(PI_CS_MAP_WIDTH-1)),(int)(PI_CS_MAP_OFFSET)));
	else
	jtag_dll_mc_reg_write(CS_MAP_ADDR,WriteBitsToValue(cs_map_orig_val,jtag_dll_mc_reg_read(CS_MAP_ADDR),(int)(CS_MAP_OFFSET+(CS_MAP_WIDTH-1)),(int)(CS_MAP_OFFSET)));
}
