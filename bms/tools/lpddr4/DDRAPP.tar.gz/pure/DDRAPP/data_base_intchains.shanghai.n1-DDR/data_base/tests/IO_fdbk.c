//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[3];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(1406,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(1407,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(1330,true);
}
void Group_read() {
    read_fn();

    tx_pcas_dis_0 = (UInt32)GetBitsFromValue(temp_reg[0],29+(1-1),29);
    tx_ncas_dis_0 = (UInt32)GetBitsFromValue(temp_reg[0],28+(1-1),28);
    rx_ctle_0 = (UInt32)GetBitsFromValue(temp_reg[0],25+(3-1),25);
    speed_0 = (UInt32)GetBitsFromValue(temp_reg[0],23+(2-1),23);
    tx120pulldwn_0 = (UInt32)GetBitsFromValue(temp_reg[0],21+(2-1),21);
    rx_dq_en_0 = (UInt32)GetBitsFromValue(temp_reg[0],20+(1-1),20);
    rpull_0 = (UInt32)GetBitsFromValue(temp_reg[0],19+(1-1),19);
    mode_0 = (UInt32)GetBitsFromValue(temp_reg[0],15+(4-1),15);
    tx_lowspeed_bypass_0 = (UInt32)GetBitsFromValue(temp_reg[0],14+(1-1),14);
    slewp_0 = (UInt32)GetBitsFromValue(temp_reg[0],11+(3-1),11);
    slewn_0 = (UInt32)GetBitsFromValue(temp_reg[0],8+(3-1),8);
    enslicep_0 = (UInt32)GetBitsFromValue(temp_reg[0],4+(4-1),4);
    enslicen_0 = (UInt32)GetBitsFromValue(temp_reg[0],0+(4-1),0);
    drv_tp_0 = (UInt32)GetBitsFromValue(temp_reg[1],18+(1-1),18);
    tx_ffe_0 = (UInt32)GetBitsFromValue(temp_reg[1],16+(2-1),16);
    boostp_0 = (UInt32)GetBitsFromValue(temp_reg[1],12+(4-1),12);
    boostn_0 = (UInt32)GetBitsFromValue(temp_reg[1],8+(4-1),8);
    enslicep_odt_0 = (UInt32)GetBitsFromValue(temp_reg[1],4+(4-1),4);
    enslicen_odt_0 = (UInt32)GetBitsFromValue(temp_reg[1],0+(4-1),0);
    tsel_0 = (UInt32)GetBitsFromValue(temp_reg[2],17+(1-1),17);
    pvtr_0 = (UInt32)GetBitsFromValue(temp_reg[2],12+(5-1),12);
    pvtn_0 = (UInt32)GetBitsFromValue(temp_reg[2],6+(6-1),6);
    pvtp_0 = (UInt32)GetBitsFromValue(temp_reg[2],0+(6-1),0);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(tx_pcas_dis_0, temp_reg[0] ,29+(1-1),29);
    temp_reg[0] = (UInt32)WriteBitsToValue(tx_ncas_dis_0, temp_reg[0] ,28+(1-1),28);
    temp_reg[0] = (UInt32)WriteBitsToValue(rx_ctle_0, temp_reg[0] ,25+(3-1),25);
    temp_reg[0] = (UInt32)WriteBitsToValue(speed_0, temp_reg[0] ,23+(2-1),23);
    temp_reg[0] = (UInt32)WriteBitsToValue(tx120pulldwn_0, temp_reg[0] ,21+(2-1),21);
    temp_reg[0] = (UInt32)WriteBitsToValue(rx_dq_en_0, temp_reg[0] ,20+(1-1),20);
    temp_reg[0] = (UInt32)WriteBitsToValue(rpull_0, temp_reg[0] ,19+(1-1),19);
    temp_reg[0] = (UInt32)WriteBitsToValue(mode_0, temp_reg[0] ,15+(4-1),15);
    temp_reg[0] = (UInt32)WriteBitsToValue(tx_lowspeed_bypass_0, temp_reg[0] ,14+(1-1),14);
    temp_reg[0] = (UInt32)WriteBitsToValue(slewp_0, temp_reg[0] ,11+(3-1),11);
    temp_reg[0] = (UInt32)WriteBitsToValue(slewn_0, temp_reg[0] ,8+(3-1),8);
    temp_reg[0] = (UInt32)WriteBitsToValue(enslicep_0, temp_reg[0] ,4+(4-1),4);
    temp_reg[0] = (UInt32)WriteBitsToValue(enslicen_0, temp_reg[0] ,0+(4-1),0);
    temp_reg[1] = (UInt32)WriteBitsToValue(drv_tp_0, temp_reg[1] ,18+(1-1),18);
    temp_reg[1] = (UInt32)WriteBitsToValue(tx_ffe_0, temp_reg[1] ,16+(2-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(boostp_0, temp_reg[1] ,12+(4-1),12);
    temp_reg[1] = (UInt32)WriteBitsToValue(boostn_0, temp_reg[1] ,8+(4-1),8);
    temp_reg[1] = (UInt32)WriteBitsToValue(enslicep_odt_0, temp_reg[1] ,4+(4-1),4);
    temp_reg[1] = (UInt32)WriteBitsToValue(enslicen_odt_0, temp_reg[1] ,0+(4-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(tsel_0, temp_reg[2] ,17+(1-1),17);
    temp_reg[2] = (UInt32)WriteBitsToValue(pvtr_0, temp_reg[2] ,12+(5-1),12);
    temp_reg[2] = (UInt32)WriteBitsToValue(pvtn_0, temp_reg[2] ,6+(6-1),6);
    temp_reg[2] = (UInt32)WriteBitsToValue(pvtp_0, temp_reg[2] ,0+(6-1),0);
    jtag_dll_mc_reg_write(1406, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(1407, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(1330, temp_reg[2] ,true);
}
