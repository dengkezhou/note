//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[12];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(1344,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(1345,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(1426,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(1346,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(1352,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(1353,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(1356,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(1357,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(1358,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(1347,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(1348,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(1355,true);
}
void Group_read() {
    read_fn();

    Init_disable_0 = (UInt32)GetBitsFromValue(temp_reg[0],0+(1-1),0);
    Auto_enable_0 = (UInt32)GetBitsFromValue(temp_reg[0],1+(1-1),1);
    Base_mode_0 = (UInt32)GetBitsFromValue(temp_reg[0],2+(2-1),2);
    Cal_polarity_0 = (UInt32)GetBitsFromValue(temp_reg[0],8+(1-1),8);
    Cal_mode_pass1_0 = (UInt32)GetBitsFromValue(temp_reg[0],4+(4-1),4);
    Cal_mode_pass2_0 = (UInt32)GetBitsFromValue(temp_reg[0],9+(4-1),9);
    PHY_CAL_INTERVAL_COUNT_0 = (UInt32)GetBitsFromValue(temp_reg[1],0+(32-1),0);
    PHY_CAL_CLK_SELECT_0 = (UInt32)GetBitsFromValue(temp_reg[2],0+(3-1),0);
    PHY_LP4_BOOT_CAL_CLK_SELECT_0 = (UInt32)GetBitsFromValue(temp_reg[3],8+(3-1),8);
    PHY_CAL_SAMPLE_WAIT_0 = (UInt32)GetBitsFromValue(temp_reg[3],0+(8-1),0);
    PHY_CAL_SETTLING_PRD_0 = (UInt32)GetBitsFromValue(temp_reg[2],24+(7-1),24);
    PHY_CAL_VREF_SWITCH_TIMER_0 = (UInt32)GetBitsFromValue(temp_reg[2],8+(16-1),8);
    PHY_CAL_CPTR_CNT_0 = (UInt32)GetBitsFromValue(temp_reg[4],24+(7-1),24);
    PHY_CAL_PD_FINE_ADJ_0 = (UInt32)GetBitsFromValue(temp_reg[5],8+(8-1),8);
    PHY_CAL_PU_FINE_ADJ_0 = (UInt32)GetBitsFromValue(temp_reg[5],0+(8-1),0);
    PHY_CAL_SLOPE_ADJ_0 = (UInt32)GetBitsFromValue(temp_reg[6],8+(20-1),8);
    PHY_CAL_SLOPE_ADJ_PASS2_0 = (UInt32)GetBitsFromValue(temp_reg[7],0+(20-1),0);
    PHY_ADRCTL_PVT_MAP_0 = (UInt32)GetBitsFromValue(temp_reg[6],0+(8-1),0);
    PHY_CAL_TWO_PASS_CFG_0 = (UInt32)GetBitsFromValue(temp_reg[8],0+(25-1),0);
    Pad_cal_done_0 = (UInt32)GetBitsFromValue(temp_reg[9],23+(1-1),23);
    Pvtr_0 = (UInt32)GetBitsFromValue(temp_reg[9],12+(5-1),12);
    Pulldown_0 = (UInt32)GetBitsFromValue(temp_reg[9],6+(6-1),6);
    PullUp_0 = (UInt32)GetBitsFromValue(temp_reg[9],0+(6-1),0);
    Pad_cal_done2_0 = (UInt32)GetBitsFromValue(temp_reg[10],23+(1-1),23);
    Pvtr2_0 = (UInt32)GetBitsFromValue(temp_reg[10],12+(5-1),12);
    Pulldown2_0 = (UInt32)GetBitsFromValue(temp_reg[10],6+(6-1),6);
    PullUp2_0 = (UInt32)GetBitsFromValue(temp_reg[10],0+(6-1),0);
    Pad_cal_state_0 = (UInt32)GetBitsFromValue(temp_reg[11],28+(4-1),28);
    Pad_cal_result_0 = (UInt32)GetBitsFromValue(temp_reg[11],26+(1-1),26);
    Cal_hard1_0 = (UInt32)GetBitsFromValue(temp_reg[11],25+(1-1),25);
    Cal_hard0_0 = (UInt32)GetBitsFromValue(temp_reg[11],24+(1-1),24);
    Last_hard1_0 = (UInt32)GetBitsFromValue(temp_reg[11],18+(6-1),18);
    First_hard0_0 = (UInt32)GetBitsFromValue(temp_reg[11],12+(6-1),12);
    Last_hard0_0 = (UInt32)GetBitsFromValue(temp_reg[11],6+(6-1),6);
    First_hard1_0 = (UInt32)GetBitsFromValue(temp_reg[11],0+(6-1),0);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(Init_disable_0, temp_reg[0] ,0+(1-1),0);
    temp_reg[0] = (UInt32)WriteBitsToValue(Auto_enable_0, temp_reg[0] ,1+(1-1),1);
    temp_reg[0] = (UInt32)WriteBitsToValue(Base_mode_0, temp_reg[0] ,2+(2-1),2);
    temp_reg[0] = (UInt32)WriteBitsToValue(Cal_polarity_0, temp_reg[0] ,8+(1-1),8);
    temp_reg[0] = (UInt32)WriteBitsToValue(Cal_mode_pass1_0, temp_reg[0] ,4+(4-1),4);
    temp_reg[0] = (UInt32)WriteBitsToValue(Cal_mode_pass2_0, temp_reg[0] ,9+(4-1),9);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_CAL_INTERVAL_COUNT_0, temp_reg[1] ,0+(32-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_CAL_CLK_SELECT_0, temp_reg[2] ,0+(3-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_LP4_BOOT_CAL_CLK_SELECT_0, temp_reg[3] ,8+(3-1),8);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_CAL_SAMPLE_WAIT_0, temp_reg[3] ,0+(8-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_CAL_SETTLING_PRD_0, temp_reg[2] ,24+(7-1),24);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_CAL_VREF_SWITCH_TIMER_0, temp_reg[2] ,8+(16-1),8);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_CAL_CPTR_CNT_0, temp_reg[4] ,24+(7-1),24);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_CAL_PD_FINE_ADJ_0, temp_reg[5] ,8+(8-1),8);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_CAL_PU_FINE_ADJ_0, temp_reg[5] ,0+(8-1),0);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_CAL_SLOPE_ADJ_0, temp_reg[6] ,8+(20-1),8);
    temp_reg[7] = (UInt32)WriteBitsToValue(PHY_CAL_SLOPE_ADJ_PASS2_0, temp_reg[7] ,0+(20-1),0);
    temp_reg[6] = (UInt32)WriteBitsToValue(PHY_ADRCTL_PVT_MAP_0, temp_reg[6] ,0+(8-1),0);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_CAL_TWO_PASS_CFG_0, temp_reg[8] ,0+(25-1),0);
    jtag_dll_mc_reg_write(1344, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(1345, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(1426, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(1346, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(1352, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(1353, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(1356, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(1357, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(1358, temp_reg[8] ,true);
}

void start_calibration()
{
	jtag_dll_mc_reg_write(PHY_CAL_CLEAR_0_ADDR,WriteBitsToValue(1,jtag_dll_mc_reg_read(PHY_CAL_CLEAR_0_ADDR,true),(int)((PHY_CAL_CLEAR_0_WIDTH - 1) + PHY_CAL_CLEAR_0_OFFSET),(int)PHY_CAL_CLEAR_0_OFFSET),true); // PHY_CAL_CLEAR
	jtag_dll_mc_reg_write(PHY_CAL_START_0_ADDR,WriteBitsToValue(1,jtag_dll_mc_reg_read(PHY_CAL_START_0_ADDR,true),(int)((PHY_CAL_START_0_WIDTH - 1) + PHY_CAL_START_0_OFFSET),(int)PHY_CAL_START_0_OFFSET),true); // PHY_CAL_START
	Thread.Sleep(500);
	Group_read();
}
