//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
public UInt32[] temp_reg = new UInt32[6];

void SC_PHY_MANUAL_UPDATE() {
    jtag_dll_mc_reg_write(1287,(UInt32)WriteBitsToValue(0x1,jtag_dll_mc_reg_read(1287, true),0 + 1 -1,0) ,true);
}

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(1065,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(1066,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(1067,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(1068,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(1069,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(1070,true);
}
void Group_read() {
    read_fn();

    PHY_ADR0_CLK_WR_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[0],16+(11-1),16);
    PHY_ADR1_CLK_WR_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[1],8+(11-1),8);
    PHY_ADR2_CLK_WR_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[2],0+(11-1),0);
    PHY_ADR3_CLK_WR_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[3],0+(11-1),0);
    PHY_ADR4_CLK_WR_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[4],0+(11-1),0);
    PHY_ADR5_CLK_WR_SLAVE_DELAY_0 = (UInt32)GetBitsFromValue(temp_reg[5],0+(11-1),0);
}
void Group_write() {
    temp_reg[0] = (UInt32)WriteBitsToValue(PHY_ADR0_CLK_WR_SLAVE_DELAY_0, temp_reg[0] ,16+(11-1),16);
    temp_reg[1] = (UInt32)WriteBitsToValue(PHY_ADR1_CLK_WR_SLAVE_DELAY_0, temp_reg[1] ,8+(11-1),8);
    temp_reg[2] = (UInt32)WriteBitsToValue(PHY_ADR2_CLK_WR_SLAVE_DELAY_0, temp_reg[2] ,0+(11-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(PHY_ADR3_CLK_WR_SLAVE_DELAY_0, temp_reg[3] ,0+(11-1),0);
    temp_reg[4] = (UInt32)WriteBitsToValue(PHY_ADR4_CLK_WR_SLAVE_DELAY_0, temp_reg[4] ,0+(11-1),0);
    temp_reg[5] = (UInt32)WriteBitsToValue(PHY_ADR5_CLK_WR_SLAVE_DELAY_0, temp_reg[5] ,0+(11-1),0);
    jtag_dll_mc_reg_write(1065, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(1066, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(1067, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(1068, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(1069, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(1070, temp_reg[5] ,true);

    SC_PHY_MANUAL_UPDATE();

}
