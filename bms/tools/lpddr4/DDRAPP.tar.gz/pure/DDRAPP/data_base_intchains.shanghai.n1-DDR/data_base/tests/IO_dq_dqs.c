//****************************************************************************************
//                       � 2024 Cadence Design Systems, Inc. 
//                         All rights reserved worldwide.  
// This file is the proprietary and confidential information of Cadence or its licensors,
// and may be distributed only by Cadence�s customer in accordance with a previously
// executed agreement between Cadence and that customer.  
// ALL MATERIALS FURNISHED HEREUNDER ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT, FITNESS FOR A 
// PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE LIABLE FOR ANY COSTS OF 
// PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS, INTERRUPTION OF BUSINESS, OR FOR ANY 
// OTHER SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR
// BREACH OF WARRANTY, CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
// ****************************************************************************************/
void UpdatePhyPerCSTrainingIdx(UInt32 csNum)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=(PHY_PER_CS_TRAINING_INDEX_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(csNum, jtag_dll_mc_reg_read(regaddr, true), (int)(PHY_PER_CS_TRAINING_INDEX_OFFSET + (PHY_PER_CS_TRAINING_INDEX_WIDTH-1)), (int)PHY_PER_CS_TRAINING_INDEX_OFFSET), true);
    }
}

void updateMulticast (UInt32 multicast_en)
{
    for (ulong slice_num = 0 ; slice_num < PHY_MEM_SLICE_COUNT ; slice_num++)
    {
        ulong regaddr=( PHY_PER_CS_TRAINING_MULTICAST_EN_ADDR + (HS_SLICE_REG_COUNT*slice_num));
        jtag_dll_mc_reg_write(regaddr, (UInt32)WriteBitsToValue(multicast_en, jtag_dll_mc_reg_read(regaddr, true), (int)( PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET + (PHY_PER_CS_TRAINING_MULTICAST_EN_WIDTH -1)), (int) PHY_PER_CS_TRAINING_MULTICAST_EN_OFFSET), true);
    }
}
public UInt32[] temp_reg = new UInt32[12];

void read_fn() {
    Array.Clear(temp_reg,0,temp_reg.Length);
    temp_reg[0] = (UInt32)jtag_dll_mc_reg_read(1408,true);
    temp_reg[1] = (UInt32)jtag_dll_mc_reg_read(1331,true);
    temp_reg[2] = (UInt32)jtag_dll_mc_reg_read(1410,true);
    temp_reg[3] = (UInt32)jtag_dll_mc_reg_read(1332,true);
    temp_reg[4] = (UInt32)jtag_dll_mc_reg_read(137,true);
    temp_reg[5] = (UInt32)jtag_dll_mc_reg_read(393,true);
    temp_reg[6] = (UInt32)jtag_dll_mc_reg_read(649,true);
    temp_reg[7] = (UInt32)jtag_dll_mc_reg_read(905,true);
    temp_reg[8] = (UInt32)jtag_dll_mc_reg_read(138,true);
    temp_reg[9] = (UInt32)jtag_dll_mc_reg_read(394,true);
    temp_reg[10] = (UInt32)jtag_dll_mc_reg_read(650,true);
    temp_reg[11] = (UInt32)jtag_dll_mc_reg_read(906,true);
}
void Group_read() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    read_fn();

    data_pad_TX_FFE_0 = (UInt32)GetBitsFromValue(temp_reg[0],28+(2-1),28);
    data_pad_tx_pcas_dis_0 = (UInt32)GetBitsFromValue(temp_reg[0],27+(1-1),27);
    data_pad_tx_ncas_dis_0 = (UInt32)GetBitsFromValue(temp_reg[0],26+(1-1),26);
    data_pad_tx120pulldwn_0 = (UInt32)GetBitsFromValue(temp_reg[0],21+(2-1),21);
    data_pad_tx_lowspeed_bypass_0 = (UInt32)GetBitsFromValue(temp_reg[0],12+(1-1),12);
    data_pad_speed_0 = (UInt32)GetBitsFromValue(temp_reg[0],10+(2-1),10);
    data_pad_mode_0 = (UInt32)GetBitsFromValue(temp_reg[0],6+(4-1),6);
    data_pad_slewp_0 = (UInt32)GetBitsFromValue(temp_reg[0],3+(3-1),3);
    data_pad_slewn_0 = (UInt32)GetBitsFromValue(temp_reg[0],0+(3-1),0);
    data_pad_pvtr_0 = (UInt32)GetBitsFromValue(temp_reg[1],12+(5-1),12);
    data_pad_pvtn_0 = (UInt32)GetBitsFromValue(temp_reg[1],6+(6-1),6);
    data_pad_pvtp_0 = (UInt32)GetBitsFromValue(temp_reg[1],0+(6-1),0);
    dqs_pad_TX_FFE_0 = (UInt32)GetBitsFromValue(temp_reg[2],30+(2-1),30);
    dqs_pad_tx_ncas_dis_0 = (UInt32)GetBitsFromValue(temp_reg[2],29+(1-1),29);
    dqs_pad_tx_pcas_dis_0 = (UInt32)GetBitsFromValue(temp_reg[2],28+(1-1),28);
    dqs_pad_tx_lowspeed_bypass_0 = (UInt32)GetBitsFromValue(temp_reg[2],24+(1-1),24);
    dqs_pad_rpull_0 = (UInt32)GetBitsFromValue(temp_reg[2],23+(1-1),23);
    dqs_pad_tx120pulldwn_0 = (UInt32)GetBitsFromValue(temp_reg[2],13+(2-1),13);
    dqs_pad_rxdqen_0 = (UInt32)GetBitsFromValue(temp_reg[2],12+(1-1),12);
    dqs_pad_speed_0 = (UInt32)GetBitsFromValue(temp_reg[2],10+(2-1),10);
    dqs_pad_mode_0 = (UInt32)GetBitsFromValue(temp_reg[2],6+(4-1),6);
    dqs_pad_slewp_0 = (UInt32)GetBitsFromValue(temp_reg[2],3+(3-1),3);
    dqs_pad_slewn_0 = (UInt32)GetBitsFromValue(temp_reg[2],0+(3-1),0);
    dqs_pad_pvtr_0 = (UInt32)GetBitsFromValue(temp_reg[3],12+(5-1),12);
    dqs_pad_pvtn_0 = (UInt32)GetBitsFromValue(temp_reg[3],6+(6-1),6);
    dqs_pad_pvtp_0 = (UInt32)GetBitsFromValue(temp_reg[3],0+(6-1),0);
    DQ_BOOSTN_0 = (UInt32)GetBitsFromValue(temp_reg[4],16+(4-1),16);
    DQ_BOOSTP_0 = (UInt32)GetBitsFromValue(temp_reg[4],20+(4-1),20);
    DQS_BOOSTN_0 = (UInt32)GetBitsFromValue(temp_reg[4],24+(4-1),24);
    DQS_BOOSTP_0 = (UInt32)GetBitsFromValue(temp_reg[4],28+(4-1),28);
    DQ_BOOSTN_1 = (UInt32)GetBitsFromValue(temp_reg[5],16+(4-1),16);
    DQ_BOOSTP_1 = (UInt32)GetBitsFromValue(temp_reg[5],20+(4-1),20);
    DQS_BOOSTN_1 = (UInt32)GetBitsFromValue(temp_reg[5],24+(4-1),24);
    DQS_BOOSTP_1 = (UInt32)GetBitsFromValue(temp_reg[5],28+(4-1),28);
    DQ_BOOSTN_2 = (UInt32)GetBitsFromValue(temp_reg[6],16+(4-1),16);
    DQ_BOOSTP_2 = (UInt32)GetBitsFromValue(temp_reg[6],20+(4-1),20);
    DQS_BOOSTN_2 = (UInt32)GetBitsFromValue(temp_reg[6],24+(4-1),24);
    DQS_BOOSTP_2 = (UInt32)GetBitsFromValue(temp_reg[6],28+(4-1),28);
    DQ_BOOSTN_3 = (UInt32)GetBitsFromValue(temp_reg[7],16+(4-1),16);
    DQ_BOOSTP_3 = (UInt32)GetBitsFromValue(temp_reg[7],20+(4-1),20);
    DQS_BOOSTN_3 = (UInt32)GetBitsFromValue(temp_reg[7],24+(4-1),24);
    DQS_BOOSTP_3 = (UInt32)GetBitsFromValue(temp_reg[7],28+(4-1),28);
    DQ_CTLE_0 = (UInt32)GetBitsFromValue(temp_reg[8],0+(3-1),0);
    DQS_CTLE_0 = (UInt32)GetBitsFromValue(temp_reg[8],3+(3-1),3);
    DQ_CTLE_1 = (UInt32)GetBitsFromValue(temp_reg[9],0+(3-1),0);
    DQS_CTLE_1 = (UInt32)GetBitsFromValue(temp_reg[9],3+(3-1),3);
    DQ_CTLE_2 = (UInt32)GetBitsFromValue(temp_reg[10],0+(3-1),0);
    DQS_CTLE_2 = (UInt32)GetBitsFromValue(temp_reg[10],3+(3-1),3);
    DQ_CTLE_3 = (UInt32)GetBitsFromValue(temp_reg[11],0+(3-1),0);
    DQS_CTLE_3 = (UInt32)GetBitsFromValue(temp_reg[11],3+(3-1),3);
    PHY_DQS_FFE_0 = (UInt32)GetBitsFromValue(temp_reg[8],16+(2-1),16);
    PHY_DQS_FFE_1 = (UInt32)GetBitsFromValue(temp_reg[9],16+(2-1),16);
    PHY_DQS_FFE_2 = (UInt32)GetBitsFromValue(temp_reg[10],16+(2-1),16);
    PHY_DQS_FFE_3 = (UInt32)GetBitsFromValue(temp_reg[11],16+(2-1),16);
    PHY_DQ_FFE_0 = (UInt32)GetBitsFromValue(temp_reg[8],8+(2-1),8);
    PHY_DQ_FFE_1 = (UInt32)GetBitsFromValue(temp_reg[9],8+(2-1),8);
    PHY_DQ_FFE_2 = (UInt32)GetBitsFromValue(temp_reg[10],8+(2-1),8);
    PHY_DQ_FFE_3 = (UInt32)GetBitsFromValue(temp_reg[11],8+(2-1),8);

    updateMulticast(1);
}
void Group_write() {

    updateMulticast(0);

    UpdatePhyPerCSTrainingIdx(ChipSelect);
    temp_reg[0] = (UInt32)WriteBitsToValue(data_pad_TX_FFE_0, temp_reg[0] ,28+(2-1),28);
    temp_reg[0] = (UInt32)WriteBitsToValue(data_pad_tx_pcas_dis_0, temp_reg[0] ,27+(1-1),27);
    temp_reg[0] = (UInt32)WriteBitsToValue(data_pad_tx_ncas_dis_0, temp_reg[0] ,26+(1-1),26);
    temp_reg[0] = (UInt32)WriteBitsToValue(data_pad_tx120pulldwn_0, temp_reg[0] ,21+(2-1),21);
    temp_reg[0] = (UInt32)WriteBitsToValue(data_pad_tx_lowspeed_bypass_0, temp_reg[0] ,12+(1-1),12);
    temp_reg[0] = (UInt32)WriteBitsToValue(data_pad_speed_0, temp_reg[0] ,10+(2-1),10);
    temp_reg[0] = (UInt32)WriteBitsToValue(data_pad_mode_0, temp_reg[0] ,6+(4-1),6);
    temp_reg[0] = (UInt32)WriteBitsToValue(data_pad_slewp_0, temp_reg[0] ,3+(3-1),3);
    temp_reg[0] = (UInt32)WriteBitsToValue(data_pad_slewn_0, temp_reg[0] ,0+(3-1),0);
    temp_reg[1] = (UInt32)WriteBitsToValue(data_pad_pvtr_0, temp_reg[1] ,12+(5-1),12);
    temp_reg[1] = (UInt32)WriteBitsToValue(data_pad_pvtn_0, temp_reg[1] ,6+(6-1),6);
    temp_reg[1] = (UInt32)WriteBitsToValue(data_pad_pvtp_0, temp_reg[1] ,0+(6-1),0);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_TX_FFE_0, temp_reg[2] ,30+(2-1),30);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_tx_ncas_dis_0, temp_reg[2] ,29+(1-1),29);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_tx_pcas_dis_0, temp_reg[2] ,28+(1-1),28);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_tx_lowspeed_bypass_0, temp_reg[2] ,24+(1-1),24);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_rpull_0, temp_reg[2] ,23+(1-1),23);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_tx120pulldwn_0, temp_reg[2] ,13+(2-1),13);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_rxdqen_0, temp_reg[2] ,12+(1-1),12);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_speed_0, temp_reg[2] ,10+(2-1),10);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_mode_0, temp_reg[2] ,6+(4-1),6);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_slewp_0, temp_reg[2] ,3+(3-1),3);
    temp_reg[2] = (UInt32)WriteBitsToValue(dqs_pad_slewn_0, temp_reg[2] ,0+(3-1),0);
    temp_reg[3] = (UInt32)WriteBitsToValue(dqs_pad_pvtr_0, temp_reg[3] ,12+(5-1),12);
    temp_reg[3] = (UInt32)WriteBitsToValue(dqs_pad_pvtn_0, temp_reg[3] ,6+(6-1),6);
    temp_reg[3] = (UInt32)WriteBitsToValue(dqs_pad_pvtp_0, temp_reg[3] ,0+(6-1),0);
    temp_reg[4] = (UInt32)WriteBitsToValue(DQ_BOOSTN_0, temp_reg[4] ,16+(4-1),16);
    temp_reg[4] = (UInt32)WriteBitsToValue(DQ_BOOSTP_0, temp_reg[4] ,20+(4-1),20);
    temp_reg[4] = (UInt32)WriteBitsToValue(DQS_BOOSTN_0, temp_reg[4] ,24+(4-1),24);
    temp_reg[4] = (UInt32)WriteBitsToValue(DQS_BOOSTP_0, temp_reg[4] ,28+(4-1),28);
    temp_reg[5] = (UInt32)WriteBitsToValue(DQ_BOOSTN_1, temp_reg[5] ,16+(4-1),16);
    temp_reg[5] = (UInt32)WriteBitsToValue(DQ_BOOSTP_1, temp_reg[5] ,20+(4-1),20);
    temp_reg[5] = (UInt32)WriteBitsToValue(DQS_BOOSTN_1, temp_reg[5] ,24+(4-1),24);
    temp_reg[5] = (UInt32)WriteBitsToValue(DQS_BOOSTP_1, temp_reg[5] ,28+(4-1),28);
    temp_reg[6] = (UInt32)WriteBitsToValue(DQ_BOOSTN_2, temp_reg[6] ,16+(4-1),16);
    temp_reg[6] = (UInt32)WriteBitsToValue(DQ_BOOSTP_2, temp_reg[6] ,20+(4-1),20);
    temp_reg[6] = (UInt32)WriteBitsToValue(DQS_BOOSTN_2, temp_reg[6] ,24+(4-1),24);
    temp_reg[6] = (UInt32)WriteBitsToValue(DQS_BOOSTP_2, temp_reg[6] ,28+(4-1),28);
    temp_reg[7] = (UInt32)WriteBitsToValue(DQ_BOOSTN_3, temp_reg[7] ,16+(4-1),16);
    temp_reg[7] = (UInt32)WriteBitsToValue(DQ_BOOSTP_3, temp_reg[7] ,20+(4-1),20);
    temp_reg[7] = (UInt32)WriteBitsToValue(DQS_BOOSTN_3, temp_reg[7] ,24+(4-1),24);
    temp_reg[7] = (UInt32)WriteBitsToValue(DQS_BOOSTP_3, temp_reg[7] ,28+(4-1),28);
    temp_reg[8] = (UInt32)WriteBitsToValue(DQ_CTLE_0, temp_reg[8] ,0+(3-1),0);
    temp_reg[8] = (UInt32)WriteBitsToValue(DQS_CTLE_0, temp_reg[8] ,3+(3-1),3);
    temp_reg[9] = (UInt32)WriteBitsToValue(DQ_CTLE_1, temp_reg[9] ,0+(3-1),0);
    temp_reg[9] = (UInt32)WriteBitsToValue(DQS_CTLE_1, temp_reg[9] ,3+(3-1),3);
    temp_reg[10] = (UInt32)WriteBitsToValue(DQ_CTLE_2, temp_reg[10] ,0+(3-1),0);
    temp_reg[10] = (UInt32)WriteBitsToValue(DQS_CTLE_2, temp_reg[10] ,3+(3-1),3);
    temp_reg[11] = (UInt32)WriteBitsToValue(DQ_CTLE_3, temp_reg[11] ,0+(3-1),0);
    temp_reg[11] = (UInt32)WriteBitsToValue(DQS_CTLE_3, temp_reg[11] ,3+(3-1),3);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_DQS_FFE_0, temp_reg[8] ,16+(2-1),16);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_DQS_FFE_1, temp_reg[9] ,16+(2-1),16);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_DQS_FFE_2, temp_reg[10] ,16+(2-1),16);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_DQS_FFE_3, temp_reg[11] ,16+(2-1),16);
    temp_reg[8] = (UInt32)WriteBitsToValue(PHY_DQ_FFE_0, temp_reg[8] ,8+(2-1),8);
    temp_reg[9] = (UInt32)WriteBitsToValue(PHY_DQ_FFE_1, temp_reg[9] ,8+(2-1),8);
    temp_reg[10] = (UInt32)WriteBitsToValue(PHY_DQ_FFE_2, temp_reg[10] ,8+(2-1),8);
    temp_reg[11] = (UInt32)WriteBitsToValue(PHY_DQ_FFE_3, temp_reg[11] ,8+(2-1),8);
    jtag_dll_mc_reg_write(1408, temp_reg[0] ,true);
    jtag_dll_mc_reg_write(1331, temp_reg[1] ,true);
    jtag_dll_mc_reg_write(1410, temp_reg[2] ,true);
    jtag_dll_mc_reg_write(1332, temp_reg[3] ,true);
    jtag_dll_mc_reg_write(137, temp_reg[4] ,true);
    jtag_dll_mc_reg_write(393, temp_reg[5] ,true);
    jtag_dll_mc_reg_write(649, temp_reg[6] ,true);
    jtag_dll_mc_reg_write(905, temp_reg[7] ,true);
    jtag_dll_mc_reg_write(138, temp_reg[8] ,true);
    jtag_dll_mc_reg_write(394, temp_reg[9] ,true);
    jtag_dll_mc_reg_write(650, temp_reg[10] ,true);
    jtag_dll_mc_reg_write(906, temp_reg[11] ,true);

    updateMulticast(1);
}
