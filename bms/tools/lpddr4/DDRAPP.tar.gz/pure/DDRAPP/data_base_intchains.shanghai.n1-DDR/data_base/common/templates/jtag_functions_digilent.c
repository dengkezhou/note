// base functions
// These will be called by individual tests and will become part of the execute engine

void update_ddr_base_address(UInt32 ctrl_base_addr, UInt32 pi_base_addr, UInt32 phy_base_addr, UInt32 from_file, string ctrl_path, string pi_path, string phy_path)
{
	DDR_CTRL_BASE_ADDRESS = (ulong)ctrl_base_addr;
	DDR_PI_BASE_ADDRESS = (ulong)pi_base_addr;
	DDR_PHY_BASE_ADDRESS = (ulong)phy_base_addr;


	if (from_file == 1)
	{
		from_regconfig_file = 1;

	}
	else
	{
		from_regconfig_file = 0;
	}
	
	gctrl_file_path = ctrl_path;
	gpi_file_path = pi_path;
	gphy_file_path = phy_path;
	
	print_message("Controller base address = 0x" +DDR_CTRL_BASE_ADDRESS.ToString("x") + "\nPI base address = 0x" +DDR_PI_BASE_ADDRESS.ToString("x") +  "\nPHY base address = 0x" +DDR_PHY_BASE_ADDRESS.ToString("x") + "\n");
	
	print_message("CTL regconfig file path: " + gctrl_file_path + "\n");
	print_message("PHY regconfig file path: " + gphy_file_path + "\n");
	print_message("PI regconfig file path: " + gpi_file_path + "\n");
	
}

void SleepIn_10_MiliSecounds(int milisecounds)
{
	int counter = milisecounds/10;
	while (counter > 0)
	{
	  Application.DoEvents();
	  Thread.Sleep(10);
	  counter--;
	}
}

ulong jtag_reg_read(ulong address)
{
	return (ulong)DLL_ReadMemory((UInt32) address);
}

void jtag_reg_write(ulong address, ulong data)
{
	Int32 status = DLL_WriteMemory((UInt32)address, (UInt32)data);

}

ulong jtag_dll_pi_reg_read(ulong address)
{
	String path;
	ulong data_out;
	path = gpi_file_path;

	if (from_regconfig_file == 0)
	{	
		address = address * 4;
		address = address + DDR_PI_BASE_ADDRESS;
		data_out = jtag_reg_read(address);
	}
	else
	{
		read_from_file(path, address);
		data_out = data_value_from_file;
	}
	
	return data_out;
}



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// DLL Memory controller register read
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
ulong jtag_dll_mc_reg_read(ulong address,bool phy=false)
{
	String path;
	ulong data_out;
	if (phy == false)
		path = gctrl_file_path;
	else
		path = gphy_file_path;
	
	if (from_regconfig_file == 0)
	{
		address = address * 4;
		if(phy == true)
			address = address + DDR_PHY_BASE_ADDRESS;
		else
			address = address + DDR_CTRL_BASE_ADDRESS;
		
		data_out = jtag_reg_read(address);
	}	
	else
	{
		read_from_file(path, address);
		data_out = data_value_from_file;
	}
	
	return data_out;
}

void read_from_file(string file, ulong addr_sel)
{
    StreamReader readFile = new StreamReader(file);

    String def_tag = "`define";
    String FileLine;

    // `define               DENALI_PHY_00_DATA 32'b00000100_00010010_00000100_00010010 // DEN_PHY_DQ_TIMING_REG_0:RW:0:32:=0x04120412
    while ((FileLine = readFile.ReadLine()) != null)
    {

		if (true == FileLine.StartsWith("//"))
            continue;
        // Got a line. Check if it contains key word #define
        if (false == FileLine.StartsWith(def_tag))
        {
            continue;
        }

        FileLine = FileLine.TrimStart('\t', ' ', '\n', '\b', '\r', '\t');
        FileLine = FileLine.TrimEnd('\t', ' ', '\n', '\b', '\r', '\t');

        // If there is comment in the line discard the same
        Int32 idx = FileLine.IndexOf("//");

        FileLine = FileLine.Substring(0, (idx - 1));

        // `define               DENALI_PHY_00_DATA 32'b00000100_00010010_00000100_00010010

        string[] stringSeparators = new string[] {" ", "\t", "\n", "\b" };
        string[] splitStrings = FileLine.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);
        if (splitStrings.Length != 3)
        {
            MessageBox.Show("Incorrect verilog register init file ");
			readFile.Close();
            return;
        }

        // DENALI_PHY_00_DATA
        // If the string contains PHY, it for PHY register space and the base address needs to be added to it

        // extract the address from string
        string num = string.Join(null, System.Text.RegularExpressions.Regex.Split(splitStrings[1], "[^\\d]"));
        if (num == "")
            continue;
        ulong addr = Convert.ToUInt64(num,10);
		
		if (addr_sel != addr) 
			continue;

        // Form the data from string
        //32'b00000100_00010010_00000100_00010010
        idx = splitStrings[2].IndexOf("b");
        Int32 shift_idx = 0;
        data_value_from_file = 0;
        string value = splitStrings[2].Substring(idx+1);
//		print_message("value = " + value + "\n");
        for (int i = (value.Length -1); i >= 0; i--)
        {
            if (value[i] == '\n' || value[i] == '_')
                continue;
            if (value[i] == '1')
            {
                data_value_from_file += (ulong)(0x1 << shift_idx);
            }

            shift_idx++;
        }
		
		break;
    }
	readFile.Close();
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// DLL Memory controller register write
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// DLL Memory controller register write
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
void jtag_dll_mc_reg_write(ulong address, ulong data, bool phy=false, bool pi_reg = false)
{
	String path;
	if (phy == true)
		path = gphy_file_path;
	else if (pi_reg == true)
		path = gpi_file_path;
	else
		path = gctrl_file_path;
	
	if (from_regconfig_file == 0)
	{	
		address = address * 4;
		if(phy == true)
			address = address + DDR_PHY_BASE_ADDRESS;
		else if(pi_reg == true)
			address = address + DDR_PI_BASE_ADDRESS;
		else
			address = address + DDR_CTRL_BASE_ADDRESS;
		
		jtag_reg_write(address, data);
	}	
	else
	{
		write_to_file(path, address, (UInt32)data);
	}
	
}

void write_to_file(string path, ulong address, UInt32 data_value)
{
	string def_tag = "`define";
	string[] delimiters = new string[] {" ", "\t", "//"};
	string[] stringSeparators = new string[] {" ", "\t", "\n", "\b" };
	string fileline = "";
	string[] lines = File.ReadAllLines(path);
	int line_index = 0;
	foreach (string line in lines)
	{		
		line_index++;
		if (true == line.StartsWith("//"))
            continue;
        // Got a line. Check if it contains key word #define
        if (false == line.StartsWith(def_tag))
        {
            continue;
        }
		
		Int32 idx = line.IndexOf("//");
        fileline = line.Substring(0, (idx - 1));		
		
		
		string[] splitStrings = fileline.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);
		if (splitStrings.Length != 3)
		{
			print_message("Incorrect verilog register init file \n");
			return;
		}

		// extract the address from string
		string num = string.Join(null, System.Text.RegularExpressions.Regex.Split(splitStrings[1], "[^\\d]"));
		if (num == "")
			continue;
		
		ulong addr = Convert.ToUInt64(num,10);
			
		if (address != addr) 
			continue;
		
        int commentIdx = line.IndexOf("//");
        string commentDescriptor = line.Substring(commentIdx-1);
		string string1 = line.Substring(0, commentIdx-36);       // `define               DENALI_PHY_00_DATA 32'b
		
		UInt32 num0 = data_value & 0xFF;
		UInt32 num1 = (data_value >> 8) & 0xFF;
		UInt32 num2 = (data_value >> 16) & 0xFF;
		UInt32 num3 = (data_value >> 24) & 0xFF;
		
        if (address == addr)
		{
			lines[line_index-1] = string1 + Convert.ToString(num3, 2).PadLeft(8,'0') + "_" + Convert.ToString(num2, 2).PadLeft(8,'0') + "_" + Convert.ToString(num1, 2).PadLeft(8,'0') + "_" + Convert.ToString(num0, 2).PadLeft(8,'0') + commentDescriptor;
			break;
		}  
	}

	File.WriteAllLines(path, lines);
}

void jtag_dll_pi_reg_write(ulong address, ulong data)
{
	//address = address * 4;
    //address = address + DDR_PI_BASE_ADDRESS;
    //jtag_reg_write(address, data);
	
	jtag_dll_mc_reg_write(address, data, false, true);
}


void InitRegistersFromFile(String file, Boolean splitFile, ulong strtReg, ulong endReg)
{

    StreamReader readFile = new StreamReader(file);

	StreamWriter writeFile = new StreamWriter(file + "txt");
    // Read the file till the tag  //> defined function start
    String def_tag = "`define";
    String FileLine;

	Boolean strtFound = false;
	Boolean endFound  = false;

    // `define               DENALI_PHY_00_DATA 32'b00000100_00010010_00000100_00010010 // DEN_PHY_DQ_TIMING_REG_0:RW:0:32:=0x04120412
    while ((FileLine = readFile.ReadLine()) != null)
    {

        if(splitFile == true && endFound == true)
			break;

		if (true == FileLine.StartsWith("//"))
            continue;
        // Got a line. Check if it contains key word #define
        if (false == FileLine.StartsWith(def_tag))
        {
            continue;
        }

        FileLine = FileLine.TrimStart('\t', ' ', '\n', '\b', '\r', '\t');
        FileLine = FileLine.TrimEnd('\t', ' ', '\n', '\b', '\r', '\t');

        // If there is comment in the line discard the same
        Int32 idx = FileLine.IndexOf("//");

        FileLine = FileLine.Substring(0, (idx - 1));

        // `define               DENALI_PHY_00_DATA 32'b00000100_00010010_00000100_00010010

        string[] stringSeparators = new string[] {" ", "\t", "\n", "\b" };
        string[] splitStrings = FileLine.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);
        if (splitStrings.Length != 3)
        {
            MessageBox.Show("Incorrect verilog register init file ");
            return;
        }

        // DENALI_PHY_00_DATA
        // If the string contains PHY, it for PHY register space and the base address needs to be added to it

        // extract the address from string
        string num = string.Join(null, System.Text.RegularExpressions.Regex.Split(splitStrings[1], "[^\\d]"));
        if (num == "")
            continue;
        ulong addr = Convert.ToUInt64(num,10);

		if(splitFile == true )
		{
			if(strtFound == false)
			{
				if(addr == strtReg )
				{
					strtFound = true;
				}
				else
				{
					continue;
				}
			}
			else
			{
				if(addr == endReg)
					endFound = true;
			}
		}
        Boolean phy_reg = false;
		Boolean pi_reg = false;
		if (splitStrings[1].Contains("PHY"))
        {
            phy_reg = true;
        }
		else if (splitStrings[1].Contains("PI"))
        {
            pi_reg = true;
        }

        // Form the data from string
        //32'b00000100_00010010_00000100_00010010
        idx = splitStrings[2].IndexOf("b");
        Int32 shift_idx = 0;
        ulong data_value = 0;
        string value = splitStrings[2].Substring(idx+1);
        for (int i = (value.Length -1); i >= 0; i--)
        {
            if (value[i] == '\n' || value[i] == '_')
                continue;
            if (value[i] == '1')
            {
                data_value += (ulong)(0x1 << shift_idx);
            }

            shift_idx++;
        }


        {
            // DLL PHY
            //ulong base_addr = DLL_PHY_BASE_ADDR;
			// Call Memory ctrl function of DLL Phy here
			//if (phy_reg)
			//{
			//	addr += base_addr;
			//}
			jtag_dll_mc_reg_write(addr, data_value,phy_reg,pi_reg);
			writeFile.WriteLine("address = " + addr.ToString("x") + "  data = " + data_value.ToString("x"));

        }

    }

	writeFile.Close();
	readFile.Close();
}

Int32 GetRegister(string defRegValuetoken, out UInt32 regvalue)
{
	Int32 regIdx = -1;
	regvalue = 0;
	string[] tokens = defRegValuetoken.Split((char[])null, StringSplitOptions.RemoveEmptyEntries);

	if (tokens.Length != 3) goto GetRegister_EXIT;
	string[] regIdxTokens = tokens[1].Trim().Split('_');

	if (regIdxTokens.Length != 4) goto GetRegister_EXIT;
	if (Int32.TryParse(regIdxTokens[2], out regIdx) == false) goto GetRegister_EXIT;

	string[] regValueTokens = tokens[2].Trim().Split('b');
	if (regValueTokens.Length != 2) goto GetRegister_EXIT;

	//String regvalueString = regValueTokens[1].Replace("_","");
	regvalue = Convert.ToUInt32(regValueTokens[1].Replace("_", ""), 2);
GetRegister_EXIT:
	return regIdx;
}

UInt32 GetRegistersFromFile(String file, out UInt32[] registers, out String[] comments)
{
	//UInt32 nextRegisterIndex = 0;
	int regIdx = 0;
	List<UInt32> regValues = new List<UInt32>();
	List<String> regDescription = new List<String>();
	try
	{
		StreamReader readFile = new StreamReader(file);
		String fileLine;
		String defTag = @"`define";
		while ((fileLine = readFile.ReadLine()) != null)
		{
			string[] commentDelimiter = new String[] { @"//" };
			if (fileLine.Trim().StartsWith(defTag) == false) continue;
			string[] tokens = fileLine.Trim().Split(commentDelimiter, StringSplitOptions.None);

			string defRegValuetoken = tokens[0].Trim();
			UInt32 regValue = 0;
			regIdx = GetRegister(defRegValuetoken, out regValue);
			//`define               DENALI_CTL_18_DATA 32'b00000000_01000001_00010001_11001001
			//if (regIdx != nextRegisterIndex) goto GetRegistersFromFile_EXIT;
			regValues.Add(regValue);
			//nextRegisterIndex++;

			if (tokens.Length > 1) regDescription.Add(tokens[1]);
			else regDescription.Add(" ");
		}
	}
	catch (Exception ex)
	{
		print_message(ex.ToString() + "\n");
		goto GetRegistersFromFile_EXIT;
	}

GetRegistersFromFile_EXIT:
	registers = regValues.ToArray();
	comments = regDescription.ToArray();
	return (UInt32)regIdx;
}

void WriteHeader(StreamWriter writeFile, Int32 ctrlRegCount, Int32 piRegCount, Int32 phyRegCount)
{
	writeFile.WriteLine(@"// Auto-generated using DDR Utility");
	writeFile.WriteLine("");
	writeFile.WriteLine(@"#include " + '"' + "../includes/stdafx.h" + '"');
	writeFile.WriteLine("");
}

void WriteRegisterArray(StreamWriter writeFile, string arrayDecl,
						UInt32[] regValue, String[] regComments, Int32 regCount, String file)
{
	int regIdx = 0;
	UInt32 regValueOut = 0;
	StreamReader readFile = new StreamReader(file);
	String fileLine;
	String defTag = @"`define";
		
	writeFile.WriteLine("");
	writeFile.WriteLine(arrayDecl + " = ");
	writeFile.WriteLine(@"{");
	
	string[] commentDelimiter = new String[] { @"//" };
	fileLine = readFile.ReadLine();
	while (fileLine.Trim().StartsWith(defTag) == false)
	{
		fileLine = readFile.ReadLine();
	}

		
	for (int regIndex = 0; regIndex < regCount; regIndex++)
	{
		string regString = String.Format("0x{0,8:X}", regValue[regIndex]).Replace(' ', '0');
		
		//if (fileLine.Trim().StartsWith(defTag) == false) continue;
		string[] tokens = fileLine.Trim().Split(commentDelimiter, StringSplitOptions.None);
		string defRegValuetoken = tokens[0].Trim();
		regIdx = GetRegister(defRegValuetoken, out regValueOut);		
		
		string regIdxString = String.Format("{0,4:D}", regIdx);
		if (regComments != null)
		{
			if (regIndex != (regCount - 1))
			{
				regString += ",";
				regString += "   // " + regIdxString + ":" + regComments[regIndex];
			}
			else
			{
				regString += "    // " + regIdxString + ":" + regComments[regIndex];
			}
		}
		else
		{
			if (regIndex != (regCount - 1))
			{
				regString += ",";
				regString += "   // " + regIdxString;
			}
			else
			{
				regString += "    // " + regIdxString;
			}
		}
		writeFile.WriteLine("\t" + regString);
		fileLine = readFile.ReadLine();
	}
	writeFile.WriteLine(@"};");
	writeFile.WriteLine("");
}

Int32 DumpRegistersToFile(String fileName, UInt32[] ctrlRegisters, String[] ctrlRegComments,
	UInt32[] piRegisters, String[] piRegComments, UInt32[] phyRegisters, String[] phyRegComments, String ctrlRegconfig, String piRegconfig, String phyRegconfig )
{
	StreamWriter writeFile = new StreamWriter(fileName);
	Int32 ctrlRegCount = ctrlRegisters.Length;
	Int32 piRegCount = piRegisters.Length;
	Int32 phyRegCount = phyRegisters.Length;

	WriteHeader(writeFile, ctrlRegCount, piRegCount, phyRegCount);
	if (ctrlRegCount != 0) WriteRegisterArray(writeFile, @"UINT32 CtrlRegisters[CTRL_REG_COUNT]", ctrlRegisters, ctrlRegComments, ctrlRegCount, ctrlRegconfig);
	if (piRegCount != 0) WriteRegisterArray(writeFile, @"UINT32 PIRegisters[PI_REG_COUNT]", piRegisters, piRegComments, piRegCount, piRegconfig);
	if (phyRegCount != 0) WriteRegisterArray(writeFile, @"UINT32 PhyRegisters[PHY_REG_COUNT]", phyRegisters, phyRegComments, phyRegCount, phyRegconfig);
	writeFile.Close();
	return 0;
}

void DumpRegconfigFilestoCpp(string ctrlRegconfig, string piRegconfig, string phyRegconfig, string cppRegconfig)
{
	UInt32[] ctrlRegisters;
	String[] ctrlRegComments;
	UInt32[] piRegisters;
	String[] piRegComments;
	UInt32[] phyRegisters;
	String[] phyRegComments;
	GetRegistersFromFile(ctrlRegconfig, out ctrlRegisters, out ctrlRegComments);
	GetRegistersFromFile(piRegconfig, out piRegisters, out piRegComments);
	GetRegistersFromFile(phyRegconfig, out phyRegisters, out phyRegComments);

	DumpRegistersToFile(cppRegconfig, ctrlRegisters, ctrlRegComments, piRegisters, piRegComments, phyRegisters, phyRegComments, ctrlRegconfig, piRegconfig, phyRegconfig);
}

void DumpCurrentRegConfigToCpp(string cppRegconfig , string ctrlRegconfig, string piRegconfig, string phyRegconfig)
{
	
	UInt32[] ctrlRegisters = new UInt32[CTLR_REG_LEN];
	String[] ctrlRegComments;
	UInt32[] piRegisters = new UInt32[PI_REG_LEN];
	String[] piRegComments;
	UInt32[] phyRegisters = new UInt32[PHY_REG_LEN];
	String[] phyRegComments;
	
	int  regindex;
	UInt32 regIdx;
	UInt32 regValueOut = 0;
	StreamReader readFile;
	String fileLine;
	String defTag = @"`define";
	string[] commentDelimiter = new String[] { @"//" };
	
	GetRegistersFromFile(ctrlRegconfig, out ctrlRegisters, out ctrlRegComments);
	GetRegistersFromFile(piRegconfig, out piRegisters, out piRegComments);
	GetRegistersFromFile(phyRegconfig, out phyRegisters, out phyRegComments);	
	
	
	
	
	
	print_message("Saving Controller registers\n");
	readFile = new StreamReader(ctrlRegconfig);
	fileLine = readFile.ReadLine();
	while (fileLine.Trim().StartsWith(defTag) == false)
	{
		fileLine = readFile.ReadLine();
	}
		
	for (regIdx = 0; regIdx < ctrlRegisters.Length; regIdx++ ) 
	{
		
		string[] tokens = fileLine.Trim().Split(commentDelimiter, StringSplitOptions.None);
		string defRegValuetoken = tokens[0].Trim();
		regindex = GetRegister(defRegValuetoken, out regValueOut);


		ctrlRegisters[regIdx] = (UInt32)jtag_dll_mc_reg_read((ulong)regindex, false);
		
		fileLine = readFile.ReadLine();
		if (fileLine == null)
			break;
	}
	readFile.Close();
	print_message("Saving PHY registers\n");
	readFile = new StreamReader(phyRegconfig);
	fileLine = readFile.ReadLine();
	while (fileLine.Trim().StartsWith(defTag) == false)
	{
		fileLine = readFile.ReadLine();
	}
	
	for (regIdx = 0; regIdx < phyRegisters.Length; regIdx++ ) 
	{

		string[] tokens = fileLine.Trim().Split(commentDelimiter, StringSplitOptions.None);
		string defRegValuetoken = tokens[0].Trim();
		regindex = GetRegister(defRegValuetoken, out regValueOut);
		
		phyRegisters[regIdx] = (UInt32)jtag_dll_mc_reg_read((ulong)regindex, true);
		
		fileLine = readFile.ReadLine();
		if (fileLine == null)
			break;		
	}
	readFile.Close();
	print_message("Saving PI registers\n");
	readFile = new StreamReader(piRegconfig);
	fileLine = readFile.ReadLine();
	while (fileLine.Trim().StartsWith(defTag) == false)
	{
		fileLine = readFile.ReadLine();
	}
	
	for (regIdx = 0; regIdx < piRegisters.Length; regIdx++ ) 
	{
		string[] tokens = fileLine.Trim().Split(commentDelimiter, StringSplitOptions.None);
		string defRegValuetoken = tokens[0].Trim();
		regindex = GetRegister(defRegValuetoken, out regValueOut);
		
		piRegisters[regIdx] = (UInt32)jtag_dll_pi_reg_read((ulong)regindex);
		
		fileLine = readFile.ReadLine();
		if (fileLine == null)
			break;			
	}
	readFile.Close();
	print_message("Dumping cpp file\n");
	DumpRegistersToFile(cppRegconfig, ctrlRegisters, ctrlRegComments, piRegisters, piRegComments, phyRegisters, phyRegComments, ctrlRegconfig, piRegconfig, phyRegconfig);	
}

// Utility function to extract bits from value passed.
// This function will extract bit from pos "msb" to pos "lsb"
ulong GetBitsFromValue(ulong value, int msb, int lsb)
{

    ulong result;
    result = (ulong)(value << (63 - msb));
    result >>= (63 - msb);
    result = (ulong)(result >> lsb);

    return result;

}

// Replaces MSB to LSb of the orig value with the value "value" passed as argment.
// If value has more bits than the msb to lsb then higher order bits will be truncated.
ulong WriteBitsToValue(ulong value, ulong orig, int msb, int lsb)
{
    // clear the bits msb to lsb from the orgnal value
    ulong val = 0xFFFFFFFFFFFFFFFF;
    val = (val >>lsb) << lsb;
    val = (val << (63-msb)) >> (63-msb);
    val = ~val; // all bits are one except for msb to lasb
    orig &= val;
    // get only the correct bits from the value to be assigned
    // if there are more bits then exclude them
    int NoOfBits = (msb -lsb);

    value = (value << (63 - NoOfBits)) >> (63 - NoOfBits);
    value = (value << lsb);
    return (orig | value);
}

// Gets the address, offset, width of string parameter passes
// Uses the defines data structure to get the value.
// definesList holds all the difnes as string,value list
//
Boolean PhyGetAddrOffsetWidth(string prefix,string name, ref int msb, ref int lsb, ref ulong addr)
{
    String defName = prefix + "_" +name;
	String defAddrName = defName + "_ADDR";
	String defOffsetName = defName + "_OFFSET";
	String defWidthName = defName + "_WIDTH";
	ulong data = 0;
	if(false == definesList.GetDefineValue(defAddrName,ref data))
		return false;

	addr = data;

	if(false == definesList.GetDefineValue(defOffsetName,ref data))
		return false;

	lsb = (Int32)data;


	if(false == definesList.GetDefineValue(defWidthName,ref data))
		return false;


    msb = lsb + ((Int32)data-1);

	return true;
}

byte ReverseBitsInByte(Byte inByte, int msb)
{
    byte result = 0x00;
    byte mask = 0x00;
    for (mask = (byte)(1 << msb); Convert.ToInt32(mask) > 0; mask >>= 1)
    {
        result >>= 1;
        byte tempbyte = (byte)(inByte & mask);
        if (tempbyte != 0x00)
            result |= (byte)(1 << msb);
    }
    return (result);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// DLL Memory controller register read
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
ulong jtag_sideband_reg_read(ulong address){
	ulong data_out;
	address = address + DDR_SIDEBAND_ADDRESS;
	data_out = jtag_reg_read(address);

	return data_out;
}

ulong jtag_phy_reg_read(ulong address){
	ulong data_out;
	address = address * 4 + DDR_PHY_ADDRESS;
	data_out = jtag_reg_read(address);

	return data_out;
}

ulong jtag_clock_reg_read(ulong address){
	ulong data_out;
	address = address + DDR_CLKGEN_BASE;
	data_out = jtag_reg_read(address);

	return data_out;
}

void jtag_clock_reg_write(ulong address, ulong data){
	address = address + DDR_CLKGEN_BASE;
	jtag_reg_write(address, data);
}

void jtag_sideband_reg_write(ulong address, ulong data){
	address = address + DDR_SIDEBAND_ADDRESS;
	jtag_reg_write(address, data);
}

