Driver info:

1. Doc: This contains DDRAPP user guide "DDR APP user guide_v1.0.1.pdf". Customer can use this as a reference for using DDRSW to bring up DDR memory subsystem.

2. Installer: This contains the executable for installing DDRAPP. Install DDR_APP.msi to get testcase files and regconfigs. Following DDRAPP directory structure will
   be created at installed location.  

3. DDRAPP Directory info:
	data_base                         // This is the database which gets created when DDRAPP is launched.

	data_base_intchains.shanghai.n1-DDR
		--data_base                   // This contains database for DDRAPP
			--common
				--defines             // This contains the defines used by DDRAPP.
				--globals             // This contains the global defines used by multiple tabs.
				--libFuncs            // This contains the library functions.
				--templates           // This contains functions and API's for interfacing with hardware
			--regconfig               // This contains the regconfigs for loading register configuration.
				  --LPDDR4            // This folder contains the patched regconfigs.

4. RTL Release information:
   The bring up suite is developed using the following release.
   intchains.shanghai.n1-DDR__20231121_INTERNAL.zip

5. Please update the following functions in Init_start testcase.
	ddr_handle_phy_freq_change_request();
	set_ddr_reset();
	set_ddr_pll();
	startup_routines();
	UpdateFreqSelBasedParameters();
	
6. If required, Update the base address for Controller, PI and PHY using Jtag_init tab in DDRAPP.

7. For DDRAPP installation procedure, please refer to "DDR APP user guide_v1.0.1.pdf"

8. This release is with patched regconfigs for memory part MT53E2G32D4DE-046, MT53E512M32D1ZW-046 with datarates as per pre-requisite doc.
   All the regconfigs files are present in DDRAPP\data_base_intchains.shanghai.n1-DDR\data_base\regconfig\LPDDR4 folder.

9. To use different regconfigs, Just change the file path in Jtag_Init tab in DDRAPP GUI.